// used as prefix header in PPC release builds with Carbon IO detection

#define q4_INLINE 1
#define q4_CARBON 1
