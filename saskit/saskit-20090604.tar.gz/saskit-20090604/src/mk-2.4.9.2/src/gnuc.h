// gnuc.h --
// $Id: gnuc.h,v 1.4 2001/11/03 23:40:00 wcvs Exp $
// This is part of MetaKit, the homepage is http://www.equi4.com/metakit/

/** @file
 * Configuration header for GNU C++
 */

#define q4_GNUC 1

#if !defined (q4_BOOL)
#define q4_BOOL 1
#endif
