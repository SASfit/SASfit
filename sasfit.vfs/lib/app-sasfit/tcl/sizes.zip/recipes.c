/* recipes.c

    Routines from Numerical Recipes
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double  *vector(int nl, int nh);
void    free_vector (double *v, int nl, int nh);
int     *ivector(int nl, int nh);
void    free_ivector (int *v, int nl, int nh);
double  **matrix(int nrl, int nrh, int ncl, int nch);
void    free_matrix (double **m, int nrl, int nrh, int ncl, int nch);
void    hunt(double xx[], int n, double x, int *jlo);
void    nrerror (char error_text[]);


double *vector(int nl, int nh)  /* allocate a vector double[nl..nh] */
{
    double *v;
    v = (double *) malloc ((unsigned long) (nh-nl+1)*sizeof(double));
    if (!v) nrerror ("memory allocation failure in vector()");
    return v-nl;
}

void free_vector (double *v, int nl, int nh)
{
    free ((char*) (v+nl));
}

int *ivector(int nl, int nh)    /* allocate a vector int[nl..nh] */
{
    int *v;
    v = (int *) malloc ((unsigned long) (nh-nl+1)*sizeof(int));
    if (!v) nrerror ("memory allocation failure in ivector()");
    return v-nl;
}

void free_ivector (int *v, int nl, int nh)
{
    free ((char*) (v+nl));
}

double **matrix(int nrl, int nrh, int ncl, int nch)
{
    int i, qty;
    double **m;
    m = (double **) malloc ((unsigned long) (nrh-nrl+1)*sizeof(double*));
    if (!m) nrerror ("memory allocation failure #1 in matrix()");
    m -= nrl;
    qty = nch-ncl+1;
    for (i=nrl;i<=nrh;i++) {
        m[i] = (double *) malloc ((unsigned long) (qty)*sizeof(double));
        if (!m[i]) nrerror ("memory allocation failure #2 in matrix()");
        m[i] -= ncl;
    }
    return m;
}

void free_matrix (double **m, int nrl, int nrh, int ncl, int nch)
{
    int i;
    for (i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
    free((char*) (m+nrl));
}

/************
 *** hunt ***       Numerical Recipes routine
 ************
    Find xx[j] < x <= xx[j+1] where 1 <= jlo <= n.  
      If x <= xx[1], jlo = 1.
      If x > xx[n], jlo = n + 1.
      Returns the value of jlo.
    x: value to search
    xx: array of table values, numbered 1 to n
    jlo: returned index (also used as an input)
*/
void hunt(double xx[], int n, double x, int *jlo)
{
    int jm,jhi,inc,ascnd;
    ascnd=(xx[n] > xx[1]);
    if (*jlo <= 0 || *jlo > n) {
        *jlo = 0;
        jhi = n+1;
    } else {
        inc = 1;
        if (x >= xx[*jlo] == ascnd) {
            if (*jlo == n) return;
            jhi = (*jlo)+1;
            while (x >= xx[jhi] == ascnd) {
                *jlo = jhi;
                inc += inc;
                jhi = (*jlo)+inc;
                if (jhi > n) {
                    jhi = n+1;
                    break;
                }
            }
        } else {
            if (*jlo ==1) {
                *jlo = 0;
                return;
            }
            jhi = (*jlo);
            *jlo -= 1;
            while (x < xx[*jlo] == ascnd) {
                jhi = (*jlo);
                inc += inc;
                *jlo = jhi - inc;
                if (*jlo < 1) {
                    *jlo = 0;
                    break;
                }
            }
        }
    }
    while (jhi-(*jlo) != 1) {
        jm = (jhi+(*jlo)) >> 1;
        if (x > xx[jm] == ascnd)
            *jlo = jm;
        else
            jhi = jm;
    }
}

void nrerror (char error_text[])        /* NR standard error handler */
{
    fprintf (stderr, "Numerical Recipes run-time error...\n");
    fprintf (stderr, "%s\n", error_text);
    fprintf (stderr, "... now exiting to system ...\n");
    /*  WaitMouseClick ();  */
    exit (1);   /* return a non-zero value */
}
