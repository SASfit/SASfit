#ifndef _HDC_TCL_H
#define _HDC_TCL_H
#include <tcl.h>

#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************
** hdc.h
**
** RCS Version $Revision: 1.1 $
** RCS Last Change Date: $Date: 1998/05/18 04:07:44 $
** Original Author: Michael I. Schwartz, mschwart@nyx.net
**
** Note: This is a work in progress. Please coordinate changes with
** the original author.
**
** RCS Change Summaries:
**   $Log: hdc.h $
** Revision 1.1  1998/05/18  04:07:44  Michael_Schwartz
** Initial revision
**
**
** Interface to a TCL object for managing display context
** handles.
**
** A type field is added in case we wish to have many kinds of
** these handles, with routines to check if the type is valid
** for the operation performed.
**
** For Windows- and Mac-type OS, this will encapsulate the hDC; 
** for X the Drawable; and perhaps it will replace the current
** image type in the GD extension.
**
** Operations:
** Creation from *ANY* pointer for compatibility returning object
** Return the pointer
** Check validity of given object (by lookup in hash table)
** Deletion of object
** Copying of object
****************************************************************/
#if defined(__WIN32__) || defined (__WIN32S__) || defined (WIN32S) || defined(_MSC_VER) || defined(__BORLANDC__)
  #include <windows.h>
  # ifndef STATIC_BUILD
  #   if defined(_MSC_VER)
  #     define EXPORT(a,b) __declspec(dllexport) a b
  #     define DllEntryPoint DllMain
  #   else
  #     if defined(__BORLANDC__)
  #         define EXPORT(a,b) a _export b
  #     else
  #         define EXPORT(a,b) a b
  #     endif
  #   endif
  # else
  #   define EXPORT(a,b) a b
  # endif
#elif defined(unix)
  #   define EXPORT(a,b) a b
#endif

/* New macros for tcl8.0.3 and later */
#if defined(TCL_STORAGE_CLASS)
#  undef TCL_STORAGE_CLASS
#endif

#ifndef BUILD_hdc
#  define TCL_STORAGE_CLASS DLLIMPORT
#else
#  define TCL_STORAGE_CLASS DLLEXPORT
#endif

#if ! defined(EXTERN)
#  define EXTERN
#endif

/**************** Known Types ****************/
#define WINDOWS_HDC 1
#define MAC_HDC     2
#define X_HDC       3
#define GD_HDC      4

/**************** Public Procedures ****************/
EXTERN EXPORT(int,Hdc_Init) (Tcl_Interp *interp);

EXTERN EXPORT(const char *,Hdc_Create) (Tcl_Interp *interp, void *ptr, int type);
EXTERN EXPORT(int,Hdc_Valid) (Tcl_Interp *interp, const char *hdcname, int type);
EXTERN EXPORT(int,Hdc_Delete) (Tcl_Interp *interp, const char *hdcname);
EXTERN EXPORT(void *,Hdc_Get) (Tcl_Interp *interp, const char *hdcname);
EXTERN EXPORT(int,Hdc_TypeOf) (Tcl_Interp *interp, const char *hdcname);
EXTERN EXPORT(const char *,Hdc_PrefixOf) (Tcl_Interp *interp, int type, const char *newprefix);
EXTERN EXPORT(int,Hdc_List) (Tcl_Interp *interp, int type, const char *out[], int *poutlen);

#ifdef __cplusplus
}
#endif

#endif
