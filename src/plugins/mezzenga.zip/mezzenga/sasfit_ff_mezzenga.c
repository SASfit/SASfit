/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

#include "include/private.h"
#include <sasfit_error_ff.h>

// define shortcuts for local parameters/variables
#define R_CORE	param->p[0]
#define DR	param->p[1]
#define ETA_CORE	param->p[2]
#define ETA_SH      param->p[3]
#define X_IN_SOL	param->p[4]
#define X_OU_SOL	param->p[5]
#define ALPHA	param->p[6]
#define L_BLOBS	param->p[7]
#define R_BLOBS	param->p[8]
#define N_BLOBS	param->p[9]

scalar sasfit_ff_mezzenga(scalar q, sasfit_param * param)
{
    scalar R, L,mu,sigma,V,pi_mu,G1,G2,omega,Sum;
    R=R_BLOBS;L=L_BLOBS;
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	SASFIT_CHECK_COND1((q < 0.0), param, "q(%lg) < 0",q);
	SASFIT_CHECK_COND1((R_CORE < 0.0), param, "R_core(%lg) < 0",R_CORE); // modify condition to your needs
	SASFIT_CHECK_COND1((DR < 0.0), param, "dR(%lg) < 0",DR); // modify condition to your needs
	SASFIT_CHECK_COND1((X_IN_SOL < 0.0), param, "x_in_sol(%lg) < 0",X_IN_SOL); // modify condition to your needs
	SASFIT_CHECK_COND1((X_OU_SOL < 0.0), param, "x_ou_sol(%lg) < 0",X_OU_SOL); // modify condition to your needs
	SASFIT_CHECK_COND1((R_BLOBS < 0.0), param, "R_blobs(%lg) < 0",R_BLOBS); // modify condition to your needs
	SASFIT_CHECK_COND1((N_BLOBS < 1.0), param, "N_blobs(%lg) < 1",N_BLOBS); // modify condition to your needs

	if (R == 0.0) return 0.0;
	if (L == 0.0) return 0.0;

	mu = L*q;
	sigma = 2.0*R*q;
	V = M_PI*R*R*L;

	if (R==0 || L==0) return 0;
	if (q==0) return 0.0;

	pi_mu = gsl_sf_Si(mu)+cos(mu)/mu+sin(mu)/mu/mu;
	G1 = 2.0/(0.5*sigma) *  gsl_sf_bessel_J1(0.5*sigma);
	G2 = 8.0/sigma/sigma * gsl_sf_bessel_Jn(2,sigma);
//	I_sp = 3.0 * (sin(sigma*0.5)-0.5*sigma*cos(0.5*sigma)) / pow(sigma/2.0,3);
//	I_sp = I_sp*I_sp;
	omega = 8/gsl_pow_2(sigma)*(3*gsl_sf_bessel_Jn(2,sigma)+gsl_sf_bessel_J0(sigma)-1);

//	Sum = 2.0/mu * (pi_mu*G1*G1 - 1.0/mu*(2.0*G2-I_sp) - sin(mu)/mu/mu);
	Sum = 2.0/mu * (pi_mu*G1*G1 - omega/mu - sin(mu)/mu/mu);
    
    Sum = 1/gsl_pow_2(1+gsl_pow_2(q*R_BLOBS));
	// insert your code here
    if (N_BLOBS==1) return sasfit_ff_boucher_sphere(q,param);
    if ((q*R_BLOBS) == 0) {
        return sasfit_ff_boucher_sphere(q,param)
              +sasfit_ff_boucher_sphere(0,param)/(N_BLOBS-1);
    } else {
        return sasfit_ff_boucher_sphere(q,param)
              +sasfit_ff_boucher_sphere(0,param)/(N_BLOBS-1) 
              *Sum;
    }
}

scalar sasfit_ff_mezzenga_f(scalar q, sasfit_param * param)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

scalar sasfit_ff_mezzenga_v(scalar q, sasfit_param * param, int dist)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

