/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

#ifndef SASFIT_PLUGIN_MEZZENGA_H
#define SASFIT_PLUGIN_MEZZENGA_H

#include <sasfit_common_shared_exports.h>

/**
 * \file sasfit_mezzenga.h
 * Public available functions and descriptions of the mezzenga plugin.
 */

/**
 * \def sasfit_mezzenga_DLLEXP
 * \copydoc sasfit_common_DLLEXP
 */

// adjust the project name below
// *_EXPORTS is set by cmake if build as shared library
#if defined(sasfit_mezzenga_EXPORTS)
	#ifdef sasfit_mezzenga_DLLEXP
	#undef sasfit_mezzenga_DLLEXP
	#endif
	#define sasfit_mezzenga_DLLEXP SASFIT_LIB_EXPORT
#elif !defined(sasfit_mezzenga_DLLEXP)
	// is set somewhere else for export as non-plugin
	#define sasfit_mezzenga_DLLEXP SASFIT_LIB_IMPORT
#endif

// general information about the form factor here
// & info used in the GUI:
// - group definition & uplevel group this one is in
// - brief description
// - description of parameters in HTML table-style

/* ################ start ff_mezzenga ################ */
/** 
 * \defgroup ff_mezzenga mezzenga
 * \ingroup form_fac
 *
 * \brief \<some brief description of mezzenga function\>
 *
 * <more detailed documentation, see 'doxygen' docs>
 *
 * \note Default (Size) Distribution: \ref delta
 *
 * \par Required parameters:
 *      <table border="0"><tr>
 *       <td>\b R_core</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b dR</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b eta_core</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b eta_sh</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b x_in_solv</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b x_ou_solv</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b alpha</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b eta_solv</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b R_blobs</td>
 *       <td></td>
 *      </tr><tr>
 *       <td>\b N_blobs</td>
 *       <td></td>
 *      </tr></table>
 */

/**
 * \ingroup ff_mezzenga
 *
 * \sa sasfit_mezzenga.h, form_fac
 */
sasfit_mezzenga_DLLEXP scalar sasfit_ff_mezzenga(scalar q, sasfit_param * p);

/**
 * \ingroup ff_mezzenga
 *
 * \sa sasfit_mezzenga.h, form_fac
 */
sasfit_mezzenga_DLLEXP scalar sasfit_ff_mezzenga_f(scalar q, sasfit_param * p);

/**
 * \ingroup ff_mezzenga
 *
 * \sa sasfit_mezzenga.h, form_fac
 */
sasfit_mezzenga_DLLEXP scalar sasfit_ff_mezzenga_v(scalar q, sasfit_param * p, int dist);
/* ################ stop ff_mezzenga ################ */


#endif // this file

