/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

#ifndef MEZZENGA_PRIVATE_H
#define MEZZENGA_PRIVATE_H

/*
 * Header file for the implementation of the form factor itself.
 */

// optional, depends on form factor implementation
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf.h>

// mandatory, no adjustments necessary
#include <sasfit_common.h>

// mandatory, no adjustments necessary
#ifdef MAKE_SASFIT_PLUGIN
  // mandatory, no adjustments necessary
  #include <sasfit_plugin.h>

  SASFIT_PLUGIN_INFO_DECL;

  // use lookup table for ff_expshell(q, param)
  #define sasfit_ff_expshell(q,p) imp_ptr->functions[0].func((q),(p))
  #define sasfit_ff_expshell_f(q,p) imp_ptr->functions[0].func_f((q),(p))
  #define sasfit_ff_expshell_v(q,p,d) imp_ptr->functions[0].func_v((q),(p),(d))
  #define sasfit_ff_boucher_sphere(q,p) imp_ptr->functions[1].func((q),(p))
  #define sasfit_ff_boucher_sphere_f(q,p) imp_ptr->functions[1].func_f((q),(p))
  #define sasfit_ff_boucher_sphere_v(q,p,d) imp_ptr->functions[1].func_v((q),(p),(d))

#else

  #include <sasfit_fuzzysphere.h>

#endif

// adjust according to the plugins name
#include "sasfit_mezzenga.h"

//
// add local defines here:
// #define P0 param->p[0]
//

#endif // end of file

