/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

#include "include/private.h"
#include <sasfit_error_ff.h>

// define shortcuts for local parameters/variables
#define SIGMA	param->p[0]
#define ETA	param->p[1]

scalar sasfit_ff_c_r_(scalar r, sasfit_param * param)
{
    scalar x;
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	SASFIT_CHECK_COND1((r < 0.0), param, "r(%lg) < 0",r);
	SASFIT_CHECK_COND1((SIGMA < 0.0), param, "sigma(%lg) < 0",SIGMA); // modify condition to your needs
	SASFIT_CHECK_COND1((ETA < 0.0), param, "eta(%lg) < 0",ETA); // modify condition to your needs
	SASFIT_CHECK_COND1((ETA > 1.0), param, "eta(%lg) >= 1",ETA); // modify condition to your needs

	// insert your code here
    x=r/SIGMA;
    if (x>1) return 0.0;
	return -(gsl_pow_2(1.+2.*ETA)-6*ETA*gsl_pow_2(1.+0.5*ETA)*x+ETA*gsl_pow_2(1+2*ETA)*0.5*gsl_pow_3(x))/gsl_pow_4(1.0-ETA);
}

scalar sasfit_ff_c_r__f(scalar q, sasfit_param * param)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

scalar sasfit_ff_c_r__v(scalar q, sasfit_param * param, int dist)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

