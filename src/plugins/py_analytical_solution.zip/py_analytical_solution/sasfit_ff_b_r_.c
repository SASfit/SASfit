/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

#include "include/private.h"
#include <sasfit_error_ff.h>

// define shortcuts for local parameters/variables
#define SIGMA	param->p[0]
#define ETA	param->p[1]

scalar sasfit_ff_b_r_(scalar r, sasfit_param * param)
{
    scalar cr, gr, br;
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	SASFIT_CHECK_COND1((r < 0.0), param, "r(%lg) < 0",r);
	SASFIT_CHECK_COND1((SIGMA < 0.0), param, "sigma(%lg) < 0",SIGMA); // modify condition to your needs
	SASFIT_CHECK_COND1((ETA < 0.0), param, "eta(%lg) < 0",ETA); // modify condition to your needs
	SASFIT_CHECK_COND1((ETA > 1.0), param, "eta(%lg) >= 1",ETA); // modify condition to your needs

	// insert your code here
    if (r<SIGMA) {
        cr = sasfit_ff_c_r_(r,param);
        br = -cr-1-log(-cr);
    } else if (r>SIGMA) {
        gr = sasfit_ff_g_r_(r,param);
        br = gr-1-log(gr);
    } else {
        cr = sasfit_ff_c_r_(SIGMA*(1-1./1000.),param);
        gr = sasfit_ff_g_r_(SIGMA*(1+1./1000.),param);
        br = (gr-cr)/2.-1-log((gr-cr)/2.);
    }
    return -br;
}

scalar sasfit_ff_b_r__f(scalar q, sasfit_param * param)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

scalar sasfit_ff_b_r__v(scalar q, sasfit_param * param, int dist)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

