/*
 * Author(s) of this file:
 *   <your name> (<email address>)
 */

/*
@Article{Trokhymchuk2005,
  author    = {Andrij Trokhymchuk and Ivo Nezbeda and Jan Jirs{\'{a}}k and Douglas Henderson},
  title     = {Hard-sphere radial distribution function again},
  journal   = {The Journal of Chemical Physics},
  year      = {2005},
  volume    = {123},
  number    = {2},
  eid       = {024501},
  month     = {jul},
  pages     = {024501},
  doi       = {10.1063/1.1979488},
  publisher = {{AIP} Publishing},
}

@Article{Trokhymchuk2006,
  author    = {Andrij Trokhymchuk and Ivo Nezbeda and Jan Jirs{\'{a}}k and Douglas Henderson},
  title     = {Erratum: {\textquotedblleft}Hard sphere radial distribution function again{\textquotedblright} [J. Chem. Phys. 123, 024501 (2005)]},
  journal   = {The Journal of Chemical Physics},
  year      = {2006},
  volume    = {124},
  number    = {14},
  eid       = {149902},
  month     = {apr},
  pages     = {149902},
  doi       = {10.1063/1.2188941},
  publisher = {{AIP} Publishing},
}
*/

#include "include/private.h"
#include <sasfit_error_ff.h>

// define shortcuts for local parameters/variables
#define SIGMA	param->p[0]
#define ETA	param->p[1]

scalar sasfit_ff_g_r_(scalar r, sasfit_param * param)
{
    scalar d, g0, mu0, a0, b0, a, b, rstar, gm, A, B, delta, C, gexpt, omega, kappa;
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	SASFIT_CHECK_COND1((r < 0.0), param, "r(%lg) < 0",r);
	SASFIT_CHECK_COND1((SIGMA < 0.0), param, "sigma(%lg) < 0",SIGMA); // modify condition to your needs
	SASFIT_CHECK_COND1((ETA < 0.0), param, "eta(%lg) < 0",ETA); // modify condition to your needs

	// insert your code here
	if (r<SIGMA) return 0.0;
    if (ETA<0.02) return 1;
    d=2*ETA*(
            ETA*ETA-3.*ETA-3+
            sqrt(3*(gsl_pow_4(ETA)-2*gsl_pow_3(ETA)+ETA*ETA+6*ETA+3))
            );
    d=pow(d,1./3.);
    mu0=(2*ETA/(1-ETA)*(-1.-d/(2.*ETA)+ETA/d))/SIGMA;
    a0=2*ETA/(1.-ETA)*(-1+d/(4.*ETA)-ETA/(2.*d))/SIGMA;
    b0=2*ETA/(1.-ETA)*sqrt(3)*(-d/(4.*ETA)-ETA/(2.*d))/SIGMA;
    g0=atan(-(SIGMA*(a0*(a0*a0+b0*b0)-mu0*(a0*a0-b0*b0)
                     )*(1+ETA/2.)
               +(a0*a0+b0*b0-mu0*a0)*(1+2.*ETA)
               )/
              (b0*( SIGMA*(a0*a0+b0*b0-2*mu0*a0)*(1+ETA/2.)
                     -mu0*(1+2*ETA)
                  )
              )
            );
    omega=-0.682*exp(-24.697*ETA)+4.720+4.450*ETA;
    omega=omega/SIGMA;
    kappa=4.674*exp(-3.935*ETA)+3.536*exp(-56.270*ETA);
    kappa=kappa/SIGMA;
    a=44.554+79.868*ETA+116.432*ETA*ETA-44.652*exp(2*ETA);
    a=a/SIGMA;
    b=-5.022+5.857*ETA+5.089*exp(-4.*ETA);
    b=b/SIGMA;
    rstar=2.0116-1.0647*ETA+0.0538*ETA*ETA;
    rstar=rstar*SIGMA;
    gm =  1.0286-0.6095*ETA + 3.5781*ETA*ETA-21.3651*gsl_pow_3(ETA)
        + 42.6344*gsl_pow_4(ETA)-33.8485*gsl_pow_5(ETA);
    gexpt=((1+ETA+ETA*ETA-2./3*(gsl_pow_3(ETA)+gsl_pow_4(ETA)))/gsl_pow_3(1-ETA)-1)/(4*ETA);
    delta=-omega*rstar-atan((kappa*rstar+1)/(omega*rstar));
    C=rstar*(gm-1)*exp(kappa*rstar)/cos(omega*rstar+delta);
    B=gm-(SIGMA*gexpt/rstar)*exp(mu0*(rstar-SIGMA));
    B=B/(cos(b*(rstar-SIGMA)+g0)*exp(a*(rstar-SIGMA))-cos(g0)*exp(mu0*(rstar-SIGMA)));
    B=B*rstar;
    A=SIGMA*gexpt-B*cos(g0);
    if (r<=rstar) return A/r*exp(mu0*(r-SIGMA))+B/r*cos(b*(r-SIGMA)+g0)*exp(a*(r-SIGMA));
    return 1+C/r*cos(omega*r+delta)*exp(-kappa*r);
}

scalar sasfit_ff_g_r__f(scalar q, sasfit_param * param)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

scalar sasfit_ff_g_r__v(scalar q, sasfit_param * param, int dist)
{
	SASFIT_ASSERT_PTR(param); // assert pointer param is valid

	// insert your code here
	return 0.0;
}

