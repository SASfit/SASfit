//------------------------------------------------------------------------------
/// \file  Vector_types.hpp
/// \brief Type aliases for vectors and matrices, plus conversion functions.
//
// Author(s): Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_VECTOR_TYPES_HPP
#define BESTLIME_VECTOR_TYPES_HPP

#include "bestlime/Eigen_core.hpp"

#include <vector>
#include <cstddef>

namespace bestlime
{

/// \name Aliases for index types
///@{

/// Index type for STL containers, including `vector_d` and `index_vector`.
using size_t = std::size_t;

/**
 * \brief Index type for `grid_vector` and `grid_matrix` objects.
 *
 * Both the indices and the sizes of these objects have this type.
 *
 * Equal to `std::ptrdiff_t`.
 */
using index_t = Eigen::Index;
///@}


/// \name Aliases for vectors and matrices
///@{

/**
 * \brief Vector for interpolation grids and related quantities.
 *
 * The `k`th index of the vector refers to the `k`th point on the grid.
 *
 * The `Eigen` library provides non-trivial algebra and other operations on
 * this type, see https://eigen.tuxfamily.org.
 *
 * Vectors of this type appear in particular as arguments of the integration
 * calls in the `Bessel_integrator` class.  End users are not required to be
 * familiar with the details of the type, which can be initialized by the
 * methods `Bessel_integrator.discretize()` or `convert_to_grid_vector()`.
 * See basic_work_flow.cpp for an example.
 */
using grid_vector = Eigen::VectorXd;

/**
 * \brief Matrix related with interpolation grids.
 *
 * The indices of the matrix refer to the grid points.
 *
 * The `Eigen` library provides non-trivial algebra and other operations on
 * this type, see https://eigen.tuxfamily.org.
 */
using grid_matrix = Eigen::MatrixXd;

/**
 * \brief Generic vector of `double` variables.
 *
 * Used in particular to specify constructor arguments of the classes
 * `Bessel_integrator` and `Grid_1d`.
 */
using vector_d = std::vector<double>;

/**
 * \brief Vector of `index_t` objects.
 *
 * Used in particular to specify constructor arguments of the classes
 * `Bessel_integrator` and `Grid_1d`.
 */
using index_vector = std::vector<index_t>;

///@}


/// \name Conversion between vector types
///@{

/// Converts a vector from STL to Eigen format.
grid_vector convert_to_grid_vector(const vector_d& vec);

/// Converts a vector from Eigen to STL format.
vector_d convert_to_vector_d(const Eigen::Ref<const grid_vector>& vec);

///@}

} // namespace bestlime

#endif // BESTLIME_VECTOR_TYPES_HPP
