//------------------------------------------------------------------------------
/// \file  Linear_solver.hpp
/// \brief Interface of class Linear_solver.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_LINEAR_SOLVER_HPP
#define BESTLIME_LINEAR_SOLVER_HPP

#include "bestlime/Vector_types.hpp"
#include "bestlime/Eigen_solvers.hpp"

#include <memory>

namespace bestlime
{

/**
 * \brief Solves a linear equation system with a square matrix.
 *
 * Solves the linear system
 *         \f[
 *           A \vec{x} = \vec{b}
 *         \f]
 * with a square matrix A, using either the LU or the truncated SV decomposition.
 *
 * The appropriate decomposition of A is computed and stored at construction and
 * can thus be used for solving the system with different values of b.  The SV
 * decomposition takes longer to compute but allows for numerically stable
 * solutions if A is ill conditioned (i.e. singular or near singular).
 *
 * The decomposition used by the class is controlled by the constructor
 * parameters \p{r_LU_max} and \p{r_SV_max}.
 *
 * \par LU decomposition:
 *
 * A is decomposed as `A = P L U`, where P is a permutation matrix, L a lower
 * diagonal matrix with diagonal elements equal to 1, and U an upper diagonal
 * matrix.  Solving `A x = b` requires the inverse diagonal elements `1/U_ii`
 * of U.  This is impossible or numerically instable if A is ill conditioned.
 *
 * As an indicator for an ill conditioned A, the class uses the minimum U_min
 * and the maximum U_max of the absolute values |U_ii|.
 * If `U_min` <= \p{r_LU_max} * `U_max`, the SV decomposition is used for
 * solving the linear system.
 *
 * \par SV decomposition:
 *
 * A is decomposed as `A = U S V^T`, where U and V are orthogonal and is S
 * diagonal and positive semidefinite.  Solving `A x = b` requires the inverse
 * singular values `1/S_ii`.  For zero singular values, `1/S_ii` is replaced by
 * zero in the inversion, which yields the solution vector x that minimizes
 * `|A x - b|`.
 *
 * For an ill conditioned matrix A, the numerically stability of the solution
 * is improved by truncating the SV decomposition, replacing `1/S_ii` by zero in
 * the inversion if `S_ii` < \p{r_SV_max} * `S_max`, where `S_max` is the
 * largest singular value.
 *
 * For more information on these decompositions, see chapters 2.3 and 2.6 in
 *
 *        W. H. Press, S. A. Teukolsky, W. T. Vetterling, B. T. Flannery,
 *        Numerical Recipes: The Art of Scientific Computing
 *        Cambridge University Press
 *
 * \note The implementation uses the methods PartialPivLU and BDCSVD of the
 *       Eigen library.
 */
class Linear_solver
{
   public:
      /// \name Constructor
      ///@{
      /**
      * \brief Computes and stores the decomposition of the matrix \p{A}.
      *
      * \param A         The square matrix defining the linear system.
      * \param r_LU_max  Control parameter for choosing the decomposition:
      *                  SV is used if `U_min <= r_LU_max * U_max`.
      *                  Setting this parameter to 1 enforces the use of the SV
      *                  decomposition.  Setting it to 0 enforces the use of the
      *                  LU decomposition unless A is singular.
      * \param r_SV_max  Control parameter for truncating the SV decomposition:
      *                  an inverse singular value `1/S_ii` is replaced by zero
      *                  if `S_ii < r_SV_max * S_max`.
      *                  This parameter should be much smaller than 1 but not
      *                  too close to zero.
      *
      * First computes the LU decomposition, then determines whether to compute
      * and use the SV decomposition instead.
      *
      * \throws std::invalid_argument under any of the following conditions:
      *     - A has size 0 or is not square,
      *     - \p{r_LU_max} is outside its allowed range `0 <= r_LU_max <= 1`,
      *     - \p{r_SV_max} is outside its allowed range `0 < r_SV_max < 1`.
      */
      Linear_solver(const Eigen::Ref<const grid_matrix>& A,
                    double r_LU_max = 1e-12,
                    double r_SV_max = 1e-12);

      /**
       * \brief Default constructor.
       *
       * Initializes with `A` equal to the one-dimensional unit matrix.
       */
      Linear_solver()
         : Linear_solver(grid_matrix::Identity(1, 1))
      {}
      ///@}

      /// \name Solve the linear system
      ///@{

      /**
       * \brief Solves the system `A x = b` and returns the solution vector `x`.
       *
       * \throws std::invalid_argument if the dimensions of \p{b} and `A`
       *                               do not match.
       */
      grid_vector solve(const Eigen::Ref<const grid_vector>& b) const;
      ///@}

      /// \name Accessors and diagnostics
      ///@{

      /// Returns the dimension of the matrix A.
      Eigen::Index dimension() const { return _dim; }

      /// Returns the parameter `r_LU_max` specified at class construction.
      double r_LU_max() const { return _r_LU_max; }

      /// Returns the parameter `r_SV_max` specified at class construction.
      double r_SV_max() const { return _r_SV_max; }

      /**
       * \brief Returns the ratio `U_min / U_max` for the matrix U in the LU
       *        decomposition of A.
       *
       * \note Returns 0 if U_max = 0.
       */
      double LU_ratio() const { return _ratio_LU; }

      /// Returns `true` is the SV decomposition is used and `false` otherwise.
      bool SV_is_used() const { return _use_SV; }

      /**
       * \brief Returns in decreasing order the values `S_ii / S_max` that are
       *        < r_SV_max.
       *
       * The corresponding inverse singular values `1/S_ii` are set to zero
       * before solving the system `A x = b`.
       *
       * \note Returns a zero vector of length dimension() if S_max = 0.
       * \note Returns an empty vector if the SV is not used.
       */
      vector_d small_SV_ratios() const;

      /**
       * \brief Returns the diagonal elements U_ii of the LU decomposition if
       * LU is used, and the singular values S_ii if SV is used.
       */
      vector_d diagonal() const;
      //@}

   private:
      // dimension of the matrix A
      Eigen::Index _dim;

      // constructor arguments
      double _r_LU_max;
      double _r_SV_max;

      Eigen::PartialPivLU<grid_matrix> _lu_dec;
      Eigen::BDCSVD<grid_matrix> _sv_dec;

      // computed parameters
      double _ratio_LU;
      bool _use_SV;

      double _compute_ratio_LU() const;
};

} // namespace bestlime

#endif //BESTLIME_LINEAR_SOLVER_HPP
