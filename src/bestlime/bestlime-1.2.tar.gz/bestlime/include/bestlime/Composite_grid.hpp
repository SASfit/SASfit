//------------------------------------------------------------------------------
/// \file  Composite_grid.hpp
/// \brief Interface of classes Subint_info and Composite_grid.
//
// Author(s): Riccardo Nagar
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_COMPOSITE_GRID_HPP
#define BESTLIME_COMPOSITE_GRID_HPP

#include "bestlime/Vector_types.hpp"
#include "bestlime/Cheb_grid.hpp"

#include <map>
#include <vector>

namespace bestlime
{

//------------------------------------------------------------------------------
/**
 * \brief Manages the subinterval information for a Composite_grid.
 *
 * The class member functions return the following information:
 *
 * - `grid_size`   Total number of points on the composite grid.
 * - `n_intervals` Number of subintervals.
 * - `n_points`    Vector of size `n_intervals` with the number of points per
 *                 subinterval (including the interval limits).
 * - `interval_limits`  Vector of size `n_intervals` + 1 containing the
 *                      values of the subinterval limits.
 * - `int_lim_indices`  Vector of size `n_intervals` + 1 containing the
 *                      indices of the subinterval limits on the composite grid.
 *                      The first element has value 0, and the last element
 *                      has value `grid_size` - 1.
 */
//------------------------------------------------------------------------------
class Subint_info
{
   public:
      /// \name Constructor
      ///@{

      /// Constructs an empty object.
      Subint_info() {};

      /**
       * \brief Computes and stores information on the subinterval structure.
       * \param n_points        Vector with the number of points in each
       *                        subinterval.
       * \param interval_limits Vector with the subinterval limits.
       *
       * \throws std::logic_error if one of the following requirements is not
       *         satisfied:
       *         - each subinterval must have at least 3 points (otherwise,
       *           interpolation without end points does not work),
       *         - \p{n_points} must have at least one component,
       *         - \p{interval_limits} must have exactly one component more
       *           than \p{n_points},
       *         - the values in \p{interval_limits} must be strictly increasing.
       */
      Subint_info(const index_vector& n_points,
                  const vector_d& interval_limits);
      ///@}

      /// \name Accessors
      ///@{

      /// Total number of grid points.
      index_t grid_size() const               { return _grid_size; }

      /// Number of subintervals.
      size_t n_intervals() const              { return _n_points.size(); }

      /// Number of grid points per subinterval.
      const index_vector& n_points() const    { return _n_points; }

      /// Short form for `n_points()[k]`.
      index_t n_points(size_t k) const        { return _n_points[k]; }

      /// Subinterval limits.
      const vector_d& interval_limits() const { return _interval_limits; }

      /// Short form for `interval_limits()[k]`.
      double interval_limits(size_t k) const  { return _interval_limits[k]; }

      /// Index values of grid points that are subinterval limits.
      const index_vector& int_lim_indices() const
      {
         return _int_lim_indices;
      }

      /// Short form for `int_lim_indices()[k]`.
      index_t int_lim_indices(size_t k) const  { return _int_lim_indices[k]; }

      /// Prints selected information about the object to the standard output.
      void print() const;
      ///@}

   private:
      index_vector _n_points;
      index_vector _int_lim_indices;
      index_t _grid_size;

      vector_d _interval_limits;

      // Compute _int_lim_indices given _n_points
      index_vector _make_int_lim_indices(const index_vector& npts) const;
};

//------------------------------------------------------------------------------
/**
 * \brief Manages composite Chebyshev grids.
 *
 * A composite Chebyshev grid consists of n subgrids in a variale u, which cover
 * adjacent intervals \f$ [u_0, u_1] \f$, \f$ [u_1, u_2] \f$, ...,
 * \f$ [u_n, u_{n+1}] \f$.  On each subgrid, a linear transformation maps u to
 * the interval [-1, 1], on which a standard Chebyshev grid is defined.  The
 * advantage of using composite Chebyshev grids is discussed in
 *
 *     [1] M. Diehl, R. Nagar and F. J. Tackmann
 *         ChiliPDF: Chebyshev Interpolation for Parton Distributions
 *         Eur. Phys. J. C 82 (2022) 257 [arXiv:2112.09703].
 *
 * Routines for interpolation and integration for composite grids are managed by
 * the Barycentric class.  Standard Chebyshev grids on the interval [-1, 1] are
 * managed by the class Cheb_grid and are called 'basic grids' in the present
 * class.
 *
 * The Composite_grid class contains the vector of grid points in u.  It has
 * member functions that compute the weights for Clenshaw-Curtis integration on
 * the composite grid.
 *
 * The subinterval structure of the composite grid is determined by the
 * subinterval limits \f$ u_0, u_1, \ldots, u_{n+1} \f$ and the number of
 * grid points for each subinterval.  This is stored in the class `Subint_info`,
 * which provides a number of derived quantities as well, in particular the
 * total number `grid_size` of points on the composite grid.
 *
 * Subintervals have an index k ranging from 0 to n, and points on the
 * composite grid have an index i ranging from 0 to `grid_size` - 1.  A number
 * of Composite_grid member functions specify the relation between a value of
 * the grid variable u or the index i of a grid point with the index k of the
 * associated subinterval.
 */
//------------------------------------------------------------------------------
class Composite_grid
{
   public:
      /// \name Constructors
      ///@{

      /// Empty constructor.
      Composite_grid() {};

      /**
       * \brief Constructs a composite grid.
       * \param n_points        Vector with the number of points for each
       *                        subinterval.
       * \param interval_limits Vector with the limits of the subintervals.
       *
       * See the constructor of Subint_info for the conditions on the
       * arguments.
       */
      Composite_grid(const index_vector& n_points,
                     const vector_d& interval_limits);

      /**
       * \brief Constructs the composite grid with the subinterval structure
       * specified by \p{info}.
       */
      Composite_grid(const Subint_info& info);

      /**
       * \brief Constructs the composite grid with the subinterval structure
       * specified by \p{info}.
       *
       * Where possible, basic Chebyshev grids contained in \p{input_grid} are
       * copied and not re-computed.
       */
      Composite_grid(const Subint_info& info,
                     const Composite_grid& input_grid);
      ///@}

      /// \name Queries and accessors
      ///@{

      /**
       * \brief Returns the \p{i}-th element of the grid vector.
       *
       * No range checking is performed.
       */
      double operator[](index_t i) const { return _grid[i]; }

      /// Returns the composite grid.
      const grid_vector& values() const  { return _grid; }

      /**
       * \brief Returns the total number of grid points.
       *
       * This is equivalent to `info().grid_size()`.
       */
      index_t size() const               { return _grid.size(); }

      /// Returns the object specifying the subinterval structure.
      const Subint_info& info() const    { return _info; }

      /// Returns the basic Chebyshev grid for subinterval number \p{k}.
      const Cheb_grid& basic_grid(size_t k) const;

      /**
       * \brief Access to the internal map of basic Chebyshev grids.
       *
       * The map index is equal to the number of points of the basic grid.
       */
      const std::map<index_t, Cheb_grid>& basic_grid_map() const
      {
         return _basic_grids;
      }
      ///@}

      /// \name Subinterval queries
      ///@{

      /**
       * \brief Determines whether a grid point belongs to the specified
       *        subinterval.
       * \param index       Index of the grid point.
       * \param subinterval Index of the subinterval.
       * \returns `true` if the grid point belongs to the specified subinterval.
       *          Returns `false` if it does not belong to the subinterval,
       *          or if \p{index} is too large to be a valid grid point index.
       */
      bool index_in_subinterval(index_t index, size_t subinterval) const;
      ///@}

      /// \name Integration weights
      ///@{

      /**
       * \brief Weights for Clenshaw-Curtis integration on the composite grid.
       *
       * This function takes the Clenshaw-Curtis weights for each subinterval
       * from clenshaw_weights(size_t) and merges all weights together.
       *
       * The integral of a function discretized on the composite grid is
       * given by the scalar product of the discretized function vector
       * with the integration weight vector.
       *
       * \note In the common point of two subintervals the Clenshaw-Curtis
       * weight is the sum of the two weights for each adjacent interval.
       */
      grid_vector clenshaw_weights() const;

      /**
       * \brief Returns the Clenshaw-Curtis weights for subinterval number \p{k}.
       *
       * This function takes the Clenshaw-Curtis weights for each subinterval
       * from the Cheb_grid class and multiplies them by
       * \f$ (u_{k+1} - u_k) / 2 \f$.
       */
      grid_vector clenshaw_weights(size_t k) const;
      ///@}

      /// \name Output
      ///@{

      /**
       * \brief Prints the grid and the integration weights to the standard
       *        output.
       *
       * Prints the elements of the composite Chebyshev grid and of the
       * Clenshaw-Curtis weights in columns.
       */
      void print() const;
      ///@}

   private:
      Subint_info _info;          // info on the subintervals

      // Stores the basic grids, which are Cheb_grid objects.
      // The map index is equal to the number of points on the grid, so that
      // each basic grid of a given size is stored only once.
      std::map<index_t, Cheb_grid> _basic_grids;

      grid_vector _grid;             // vector of values on the composite grid

      // Creates the internal map of basic grids corresponding to _info.
      std::map<index_t, Cheb_grid> _make_basic_grids() const;

      // Does the same, but re-uses basic grids from input_grid where possible.
      std::map<index_t, Cheb_grid> _make_basic_grids(
         const Composite_grid& input_grid) const;

      // Computes _grid from _info.
      grid_vector _make_global_grid() const;
};

//------------------------------------------------------------------------------
// Inline definitions of nonmember functions
//------------------------------------------------------------------------------

/// \name Comparison
///@{
//------------------------------------------------------------------------------
/**
 * \relates Subint_info
 * \brief   Equality comparison operator for Subint_info.
 * \returns `true` if \p{lhs} equals \p{rhs}, `false` otherwise.
 *
 * Two `Subint_info` objects are considered equal if they have been initialized
 * with identical values of \p{n_pts} and \p{interv_limits}.
 */
inline bool operator==(const Subint_info& lhs, const Subint_info& rhs)
{
   return (lhs.n_points() == rhs.n_points())
          && (lhs.interval_limits() == rhs.interval_limits());
}

//------------------------------------------------------------------------------
/**
 * \relates Subint_info
 * \brief   Inequality comparison operator for Subint_info.
 * \returns `true` if \p{lhs} is not equal to \p{rhs}, `false` otherwise.
 *
 * This is equivalent to `!(lhs == rhs)`.
 */
inline bool operator!=(const Subint_info& lhs, const Subint_info& rhs)
{
   return ! (lhs == rhs);
}
///@}

} // namespace bestlime

#endif // BESTLIME_COMPOSITE_GRID_HPP
