//------------------------------------------------------------------------------
/// \file  Bessel_integrator.hpp
/// \brief Interface of class Bessel_integrator.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_INTEGRATOR_HPP
#define BESTLIME_INTEGRATOR_HPP

#include "bestlime/Bessel_integrator_impl.hpp"
#include "bestlime/Vector_types.hpp"
#include "bestlime/Grid_types.hpp"

#include <iostream>

//------------------------------------------------------------------------------
/**
 * \namespace bestlime
 * \brief Namespace containing the Bessel integrator class.
 *
 * Contains the main class `Bessel_integrator` along with the classes it
 * requires to work.
 *
 * The namespace introduces a number of aliases for the manipulation of indices,
 * vectors and matrices.  See Vector_types.hpp for details.
 */
//------------------------------------------------------------------------------
namespace bestlime
{

/**
 * \brief Computes integrals weighted with Bessel functions of the first kind.
 *
 * \tparam Grid_type  Specifies the variable transform used for the
 *                    interpolation grid (see below).
 *
 * This class provides the user interface for computing integrals of the form
 *
 * \f[
 *    \int_{z_a}^{z_b} dz \: J_{\rho} (qz) \, f(z)
 * \f]
 * and
 * \f[
 *    \int_{z_a}^{z_b} dz \: J_{\rho} (qz) \,
 *       \left( \frac{1+z}{z} \right)^{\rho} f(z)
 * \f]
 *
 * where \f$ J_\rho\f$ is a Bessel function of the first kind.  The conditions
 * on the parmeters are \f$ \rho \ge 0, q > 0 \f$, and \f$ z_b > z_a \ge 0 \f$.
 * The upper limit \f$ z_b \f$ may be infinite, and \f$ \rho \f$ need not be
 * integer.  The function \f$ f(z) \f$ must be finite at the integration
 * boundaries but is not required to vanish when z goes to infinity.
 *
 * The class Bessel_integrator_special can handle cases in which \f$ f(z) \f$
 * diverges at the upper integration limit \f$ z_b = \infty \f$.
 *
 * \par Usage and mathematical background.
 *
 * A class instance is characterized by a fixed interpolation grid from
 * \p{z_a} to \p{z_b} and by a parameter \p{nu} => 1.  It provides integration
 * calls for Bessel functions of order nu-1, nu, and nu+1.  In particular,
 * integrals with J_0 are obtained by setting \p{nu} = 1 and using the call for
 * order n-1.
 *
 * Note that the interpolation grid does _not_ depend on the parameter \p{q} in
 * the Bessel functions. Clients must make sure that the grid is suited for an
 * accurate interpolation of the functions `f(z)` in the integration calls.
 *
 * The integration is performed using Levin's method
 *
 *       [1] David Levin
 *           Fast integration of rapidly oscillatory functions
 *           Journal of Computational and Applied Mathematics 67 (1996) 95
 *           https://doi.org/10.1016/0377-0427(94)00118-9
 *
 * with the adaptations for the Fourier-Bessel transform described in
 *
 *       [2] Markus Diehl and Oskar Grocholski
 *           Efficient computation of Fourier-Bessel transforms
 *           for transverse-momentum dependent parton distributions
 *           and other functions
 *           arXiv:2405.08616 [hep-ph]
 *
 * The integration is rewritten in terms of an ordinary differential equation
 * (ODE) in z, which is discretized on the interpolation grid and solved using
 * linear algebra methods.  Details of the latter are controlled by the two
 * parameters \p{r_LU_max} and \p{r_SV_max} of the constuctor.
 *
 * The ODE is solved separately on each subgrid of the global interpolation grid.
 * If all values of (q z) on a subgrid are smaller than the first zero of the
 * Bessel function J_nu(q z), then by default Clenshaw-Curtis quadrature and not
 * the Levin method is used on that subgrid.  This behavior can be changed by
 * setting \p{use_quadrature} to `false` in the constructor.
 *
 * \par Specifying the interpolation grid
 *
 * An interpolation grid in z is specified by the following input:
 *
 * - a division of the full integration interval `[z_a, z_b]` into k
 *   subintervals [z_0, z_1], [z_1, z_2], ..., [z_{k-1}, z_k] with
 *   z_0 = z_a and z_k = z_b.  The subinterval limits z_0, z_1, ..., z_k are
 *   specified in the constructor argument \p{z_limits}.  The case k=1 (i.e. a
 *   single interval) is allowed.  For integrals up to infinity, the constant
 *   `Grid_1d::infinity` for the value of z_b should be used.
 *
 * - the number n_0, n_1, ..., n_{k-1} of grid points on each subinterval,
 *   specified in the constructor argument \p{n_points}.
 *
 * - a transformation from z to the variable u that is used for polynomial
 *   interpolation in the algorithm.  The functional form of the transformation
 *   is specified by the template argument \p{Grid_type}, which must be a
 *   class derived from `Grid_1d`.  The parameters on which the transform depends
 *   are specified in the constructor argument \p{grid_params}.
 *
 * Several transformations are provided:
 *
 * Grid_type          | Transform u(z)                          | parameters
 * -------------------|-----------------------------------------|-------------
 * Linear_grid        | \f$ z \f$                               | {}
 * Log_grid           | \f$ \log z \f$                          | {}
 * Power_law_grid     | \f$ z^{p} \f$                           | {p}
 * Inv_power_law_grid | \f$ - (z + z_0)^{-p} \f$                | {p, z_0}
 * Log_pow_grid       | \f$ - \log^p((z+z_{hi})/(z+z_{lo})) \f$ | {p, z_lo, z_hi}
 * Exp_grid           | \f$ - \exp(-m z/4) \f$                  | {m}
 * Exp_sqrt_grid      | \f$ - \exp[ 1 - \sqrt{1 + m z/2} ] \f$  | {m}
 * Gauss_grid         | \f$ - \exp [ -(m^2 z^2 + m z) / 4 ] \f$ | {m}
 *
 * In all cases, the grid parameters must satisfy p > 0 and m > 0.  The first
 * two grid types are suitable for finite integration intervals, and the remaing
 * four for integration up to infinity.  For more information, see the
 * documentation of the individual \p{Grid_type} classes.
 *
 * Users may implement additional variable transforms in derived classes of
 * `Grid_1d` and use these with the present class.  The constructor of the grid
 * class must have the same signature as the base class constructor.  An example
 * is given in custom_transform.cpp.
 *
 * \par Performance considerations
 *
 * The matrix characterizing the ODE of Levin's method depends on the parameter
 * \p{q}.  It is stored and only updated if a function depending on \p{q} is
 * called with a value that differs from the one in the previous call.  This
 * update involves an LU or SV decomposition of the matrix and takes
 * significantly longer than the solution of the ODE for a specific discretized
 * function `f(z)`.
 *
 * Therefore, subsequent calls with the same \p{q} but different `f(z)` or
 * different orders (nu-1, nu, nu+1) are faster than subsequent calls with
 * different \p{q}.
 *
 * A workflow may require integrals for different \p{q} at some stage, and
 * integrals for the same values of \p{q} at a later stage.  To avoid the cost
 * of updating \p{q} to previously used values, the class provides functions to
 * compute integration weights for a given \p{q}.  These functions invoke the
 * basic integration calls for a set of N_pts basis functions, where N_pts is
 * the number of points of the interpolation grid.  The integral for a given
 * function is then obtained as the scalar product of the vector of its
 * discretized values with the vector of weights.  Computing this product is
 * much faster than an integration call that solves the ODE of Levin's method.
 *
 * The class contains integration calls that take a vector of N_fct discretized
 * functions as argument.  These calls integrate each function in turn if
 * N_fct < N_pts, and the computation time roughly grows linearly with N_fct in
 * that regime.  For N_fct => N_pts, the calls compute the relevant integration
 * weights and use them to evaluate the integral of each discretized function
 * as a scalar product.  In this regime, the computation time grows very slowly
 * with N_fct.
 *
 * The preceding points are illustrated in the code timing.cpp.
 *
 * \see Vector_types.hpp for the definition and documentation of the different
 * vector types used in the present class: `vector_d`, `index_vector`, and
 * `grid_vector`.
 */
template <class Grid_type>
class Bessel_integrator
{
   public:
      /// \name Constructors
      ///@{

      /**
      * \brief Standard constructor.
      *
      * \param n_points     The number of points in each subinterval.
      * \param z_limits     The boundaries of the subintervals in `z`.
      * \param grid_params  The parameters of the grid variable transform.
      * \param nu           The class contains calls for Bessel functions of
      *                     order nu-1, nu, and nu+1.
      *                     Only values \p{nu} => 1 are accepted.
      *
      * \throws std::invalid_argument if \p{nu} < 1 or if the lowest z value on
      * the interpolation grid is negative.
      */
      Bessel_integrator(const index_vector& n_points,
                        const vector_d& z_limits,
                        const vector_d& grid_params,
                        double nu = 1)
         : Bessel_integrator(n_points, z_limits, grid_params, nu, true)
      {}

      /**
      * \brief Constructor with control over the integration method.
      *
      * \param n_points        The number of points in each subinterval.
      * \param z_limits        The boundaries of the subintervals in `z`.
      * \param grid_params     The parameters of the grid variable transform.
      * \param nu              The class contains calls for Bessel functions of
      *                        order nu-1, nu, and nu+1.
      *                        Only values \p{nu} => 1 are accepted.
      * \param use_quadrature  Determines whether Clenshaw-Curtis quadrature can
      *                        be used.
      * \param r_LU_max        Optional parameter for selecting the method
      *                        (LU or SV decomposition) when solving the ODE.
      * \param r_SV_max        Optional parameter for trucating the SV
      *                        decomposition when solving the ODE.
      *
      * If \p{use_quadrature} = `true`, Clenshaw-Curtis quadrature is used in
      * subintervals [z0, z1] for which q z1 <= j_nu, where j_nu is the first
      * zero of the Bessel function J_nu(x).  This is the setting of the
      * standard constructor.
      *
      * If \p{use_quadrature} = `false`, Clenshaw-Curtis quadrature is never
      * used.
      *
      * \see Linear_solver for information about the parameters
      * \p{r_LU_max} and \p{r_SV_max}.
      *
      * \throws std::invalid_argument if \p{nu} < 1, or if the lowest z value on
      * the interpolation grid is negative, or if \p{r_LU_max} or \p{r_SV_max}
      * are outside their allowed ranges.
      */
      Bessel_integrator(const index_vector& n_points,
                        const vector_d& z_limits,
                        const vector_d& grid_params,
                        double nu,
                        bool use_quadrature,
                        double r_LU_max = 1e-12,
                        double r_SV_max = 1e-12)
         : _grid{Grid_type(n_points, z_limits, grid_params)},
           _integrator{_grid, nu, use_quadrature, r_LU_max, r_SV_max}
      {}
      ///@}

      /// \name Destructor etc.
      ///@{
      ~Bessel_integrator() = default;
      Bessel_integrator(const Bessel_integrator&) = default;
      Bessel_integrator(Bessel_integrator&& other);
      Bessel_integrator& operator=(const Bessel_integrator&) = default;
      Bessel_integrator& operator=(Bessel_integrator&& other) = default;
      ///@}

      /// \name Integration calls for discretized functions
      ///@{
      /**
      * \brief Computes the integral of `J_nu(q z) ftilde(z)`.
      *
      * \returns The integral
      * \f[
      *    \int_{z_a}^{z_b} dz \: J_{\nu} (qz) \, \tilde{f}(z)
      * \f]
      * using the discretized values \p{f_values} of the function ftilde(z).
      *
      * For \p{verbose} > 0, diagnostic information is printed to the standard
      * output for each subinterval in which the Levin method is used.  This
      * includes the input and output vectors of the discretized differential
      * equation.  Output is given in gnuplot format for \p{verbose} = 1 and
      * as C++ code for \p{verbose} = 2.
      *
      * \throws std::invalid_argument if \p{q} <= 0 or if the size of
      * \p{f_values} does not match the interpolation grid.
      *
      * \note This call requires ftilde(z) to be finite at the lower integration
      *       limit.  If z_a = 0 and ftilde(z) diverges at most like z^(-nu) at
      *       that point, one can use the call weighted_int_J_nu().
      */
      double int_J_nu(const grid_vector& f_values, double q, int verbose = 0)
      {
         return _integrator.int_J_nu(f_values, q, verbose);
      }

      /// The same as int_J_nu() with `J_{nu+1}` instead of `J_{nu}`.
      double int_J_nu_plus_1(const grid_vector& f_values, double q,
                             int verbose = 0)
      {
         return _integrator.int_J_nu_plus_1(f_values, q, verbose);
      }

      /// The same as int_J_nu() with `J_{nu-1}` instead of `J_{nu}`.
      double int_J_nu_minus_1(const grid_vector& f_values, double q,
                              int verbose = 0)
      {
         return _integrator.int_J_nu_minus_1(f_values, q, verbose);
      }

      /**
      * \brief Computes a weighted integral of `J_nu(q z) f(z)`.
      *
      * \returns The integral
      * \f[
      *    \int_{z_a}^{z_b} dz \: J_{\nu} (qz) \,
      *       \left( \frac{1+z}{z} \right)^{\nu} \, f(z)
      * \f]
      * using the discretized values \p{f_values} of the function f(z).
      *
      * The effect of the parameter \p{verbose} is the same as for int_J_nu().
      *
      * \throws std::invalid_argument if \p{q} <= 0 or if the size of
      * \p{f_values} does not match the interpolation grid..
      */
      double weighted_int_J_nu(const grid_vector& f_values, double q,
                               int verbose = 0)
      {
         return _integrator.weighted_int_J_nu(f_values, q, verbose);
      }

      /**
      * \brief Computes a weighted integral of `J_{nu+1}(q z) f(z)`.
      *
      * \returns The integral
      * \f[
      *    \int_{z_a}^{z_b} dz \: J_{\nu+1} (qz) \,
      *       \left( \frac{1+z}{z} \right)^{\nu} \, f(z)
      * \f]
      * using the discretized values \p{f_values} of the function f(z).  Notice
      * that the power of (1+z)/z is nu and not nu+1.
      *
      * The effect of the parameter \p{verbose} is the same as for int_J_nu().
      */
      double weighted_int_J_nu_plus_1(const grid_vector& f_values, double q,
                                      int verbose = 0)
      {
         return _integrator.weighted_int_J_nu_plus_1(f_values, q, verbose);
      }

      /**
      * \brief Computes a weighted integral of `J_{nu-1}(q z) f(z)`.
      * \returns The integral
      * \f[
      *    \int_{z_a}^{z_b} dz \: J_{\nu-1} (qz) \,
      *       \left( \frac{1+z}{z} \right)^{\nu-1} \, f(z)
      * \f]
      * using the discretized values \p{f_values} of the function f(z).
      *
      * The effect of the parameter \p{verbose} is the same as for int_J_nu().
      */
      double weighted_int_J_nu_minus_1(const grid_vector& f_values, double q,
                                       int verbose = 0)
      {
         return _integrator.weighted_int_J_nu_minus_1(f_values, q, verbose);
      }
      ///@}

      /// \name Integration calls for several discretized functions at once
      ///@{

      /**
       * \brief As int_J_nu(const grid_vector&, double, int) but for several
       *        functions.
       *
       * \returns A vector whose i'th component is the integral corresponding to
       *          the discretized function values in the i'th component of the
       *          vector \p{f_values}.
       *
       * \note This and the following calls do not offer verbose output, i.e.
       *       they correspond to setting \p{verbose} = 0 in the calls for
       *       single functions.
       */
      vector_d int_J_nu(const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.int_J_nu(f_values, q);
      }

      /// As int_J_nu_plus_1(const grid_vector&, double, int) but for several functions.
      vector_d int_J_nu_plus_1(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.int_J_nu_plus_1(f_values, q);
      }

      /// As int_J_nu_minus_1(const grid_vector&, double, int) but for several functions.
      vector_d int_J_nu_minus_1(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.int_J_nu_minus_1(f_values, q);
      }

      /// As weighted_int_J_nu(const grid_vector&, double, int) but for several functions.
      vector_d weighted_int_J_nu(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.weighted_int_J_nu(f_values, q);
      }

      /// As weighted_int_J_nu_plus_1(const grid_vector&, double, int) but for several functions.
      vector_d weighted_int_J_nu_plus_1(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.weighted_int_J_nu_plus_1(f_values, q);
      }

      /// As weighted_int_J_nu_minus_1(const grid_vector&, double, int) but for several functions.
      vector_d weighted_int_J_nu_minus_1(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.weighted_int_J_nu_minus_1(f_values, q);
      }
      ///@}

      /// \name Integration weights
      ///@{

      /**
       * \brief Computes integration weights for the specified value of \p{q}.
       *
       * The computed weights correspond to the integral computed by
       * int_J_nu() if \p{weighted} = `false` and to the one computed by
       * weighted_int_J_nu() if \p{weighted} = `true`.  The corresponding
       * integral is then obtained as
       *
       *       sum_i weights[i] * f_values[i]
       *
       * where `f_values` is the vector of discretized function values.
       * Using the syntax of Eigen for the scalar product of two vectors, this
       * can be simplify written as `f_values.dot(weights)`.  See
       * the code in integration_weights.cpp for more examples.
       */
      grid_vector weights_J_nu(double q, bool weighted = false)
      {
         return _integrator.weights_J_nu(q, weighted);
      }

      /// As weights_J_nu() but for the integrals computed by int_J_nu_plus_1() and weighted_int_J_nu_plus_1().
      grid_vector weights_J_nu_plus_1(double q, bool weighted = false)
      {
         return _integrator.weights_J_nu_plus_1(q, weighted);
      }

      /// As weights_J_nu() but for the integrals computed by int_J_nu_minus_1() and weighted_int_J_nu_minus_1().
      grid_vector weights_J_nu_minus_1(double q, bool weighted = false)
      {
         return _integrator.weights_J_nu_minus_1(q, weighted);
      }
      ///@}


      /// \name Function discretization
      ///@{

      /**
       * \brief   Discretizes a function of `z` and (optional) additional
       *          arguments on the interpolation grid.
       *
       * \param   funct      A function with first argument `z` and (optional)
       *                     additional arguments.
       * \param   arguments  The additional arguments.
       *
       * \returns The vector of function values \p{funct}(z_i, \p{arguments}),
       *          where `z_i` are the points on the discretization grid.
       */
      template <typename... Args>
      grid_vector discretize(std::function<double(double, Args...)>& funct,
                             Args... arguments) const
      {
         return _integrator.discretize<Args...>(funct, arguments...);
      }
      ///@}

      /// \name Accessors
      ///@{

      /// Returns the `z` values on the interpolation grid.
      const grid_vector& z_values() const
      {
         return _integrator.z_values();
      }

      /// Returns the boundaries of the subintervals in `z`.
      const vector_d& z_limits() const
      {
         return _grid.info().interval_limits();
      }

      /// Returns the number of points in each subinterval.
      const index_vector& n_points() const
      {
         return _grid.info().n_points();
      }

      /**
       * \brief Returns the parameters of the grid variable transform.
       *
       * Is empty if the transform does not depend on any parameter.
       */
      const vector_d& grid_params() const
      {
         return _grid.parameters();
      }

      /// Returns the value of `nu` specified at construction.
      double nu() const
      {
         return _integrator.nu();
      }

      /// Returns the current value of `q`.
      double current_q() const
      {
         return _integrator.current_q();
      }

      /**
       * \brief Prints info about the interpolation grid to the standard output.
       *
       * The information is given in the form `[z_limits]_(n_points)`, see
       * z_limits() and n_points().
       *
       * The output does _not_ end with a newline character.
       *
       * \note The total number of grid points is readily obtained by calling
       *       z_values().size().
       */
      void print_grid_info() const { std::cout << "grid in z: " << _grid; }
      ///@}

      /// \name Information about the integration method
      ///@{

      /// Returns the quadature setting specified at construction.
      bool quadrature_is_used() const
      {
         return _integrator.quadrature_is_used();
      }

      /**
       * \brief Returns the first zero of `J_nu(x)` for `nu` specified at
       *        construction.
       *
       * This value is used to determine whether quadrature or the Levin method
       * is used in a given subinterval.
       */
      double first_bessel_zero() const
      {
         return _integrator.first_bessel_zero();
      }

      /**
       * \brief Prints info about the integration method to the standard output.
       *
       * Part of the information depends on the value of \p{q}.
       *
       * The output contains
       * - basic information,
       * - the method used in each subinterval,
       *   with information from the linear solver if applicable.
       *
       * Abbreviations used are:
       * - j_nu = the first zero of the Bessel function `J_nu(x)`
       * - CC = Clenshaw-Curtis quadrature
       * - LU = Levin method with LU decomposition
       * - SV = Levin method with SV decompsition
       *
       * \see Linear_solver for information about the numbers
       *      `LU_ratio` and `small_SV_ratios` in the output.
       */
      void print_info(double q)
      {
         _integrator.print_info(q);
      }
      ///@}

   private:
      Grid_type _grid;
      Bessel_integrator_impl _integrator;
};

//------------------------------------------------------------------------------
// Definititions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
template <class Grid_type>
Bessel_integrator<Grid_type>::Bessel_integrator(Bessel_integrator&& other)
   : _grid{other._grid},
     _integrator{other._grid, other.nu(), other.quadrature_is_used(),
         other._integrator.r_LU_max(), other._integrator.r_SV_max()}
{}

} // namespace bestlime

#endif // BESTLIME_INTEGRATOR_HPP
