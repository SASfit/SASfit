//------------------------------------------------------------------------------
/// \file  Grid_types.hpp
/// \brief Interface of classed derived from Grid_1d.
//
// Author(s): Riccardo Nagar and Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_GRID_TYPES_HPP
#define BESTLIME_GRID_TYPES_HPP

#include "bestlime/Grid_1d.hpp"
#include "bestlime/Vector_types.hpp"

#include <cmath>
#include <cassert>

namespace bestlime
{

//------------------------------------------------------------------------------
/**
 * \brief Manages a linear grid.
 *
 * The associated variable transformation is u = z.
 * The interval limits must be finite.
 */
//------------------------------------------------------------------------------
class Linear_grid : public Grid_1d
{
   public:
      /// \name Constructors
      ///@{
      /**
       * \brief Constructs the base grid.
       * \param n_pts         Number of points per subinterval.
       * \param interv_limits Separation points of the subintervals in the
       *                      physical variable.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Linear_grid(const index_vector& n_pts, const vector_d& interv_limits);

      /// Equivalent constructor with base class signature.
      Linear_grid(const index_vector& n_pts, const vector_d& interv_limits,
                  const vector_d&)
         : Linear_grid(n_pts, interv_limits)
      {}
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation u = z.
      double variable_transform(double z) const override { return z; }

      /// Inverse variable transformation z = u.
      double inverse_transform(double u) const override  { return u; }

      /// Jacobian as a function of u.
      double jacobian(double) const override             { return 1.0; }

      /// Hessian as a function of u.
      double hessian(double) const override              { return 0.0; }
      ///@}
};


//------------------------------------------------------------------------------
/**
 * \brief Manages a logarithmic grid.
 *
 * The associated variable transformation is u = log z.
 * Allowed values for z are  0 < z < `infinity`.
 */
//------------------------------------------------------------------------------
class Log_grid : public Grid_1d
{
   public:
      /// \name Constructors
      ///@{
      /**
       * \brief Constructs the base grid.
       * \param n_pts         Number of points per subinterval.
       * \param interv_limits Separation points of the subintervals in the
       *                      physical variable.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Log_grid(const index_vector& n_pts, const vector_d& interv_limits);

      /// Equivalent constructor with base class signature.
      Log_grid(const index_vector& n_pts, const vector_d& interv_limits,
                  const vector_d&)
         : Log_grid(n_pts, interv_limits)
      {}
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation u = log z.
      double variable_transform(double z) const override
      {
         assert(z > 0.);
         return std::log(z);
      }

      /// Inverse variable transformation z = exp u.
      double inverse_transform(double u) const override
      {
         return std::exp(u);
      }

      /// Jacobian du/dz = 1/z as a function of u.
      double jacobian(double u) const override
      {
         return std::exp(-u);
      }

      /// Hessian \f$ d^2 u / dz^2  = 1/z^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         return - std::exp(-2.*u);
      }
      ///@}
};


//------------------------------------------------------------------------------
/**
 * \brief Manages a power-law grid.
 *
 * The associated variable transformation is \f$ u = z^{p} \f$ with p > 0.
 * The allowed limits for z are 0 < z < `infinity`.
 *
 * For p = 1.0, one obtains the trivial transformation u = z.
 */
//------------------------------------------------------------------------------
class Power_law_grid : public Grid_1d
{
   public:
      /// \name Constructors
      ///@{
      /**
       * \brief Constructs the base grid.
       * \param n_pts         Number of points per subinterval.
       * \param interv_limits Separation points of the subintervals in the
       *                      physical variable.
       * \param p             Power in the variable transformation.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Power_law_grid(const index_vector& n_pts, const vector_d& interv_limits,
                     double p = 1.0)
         : Power_law_grid(n_pts, interv_limits, vector_d({p}))
      {}

      /**
       * \brief Equivalent constructor with the same signature as for the base
       *        class.
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 1.
       */
      Power_law_grid(const index_vector& n_pts, const vector_d& interv_limits,
                     const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation \f$ u = z^{p} \f$.
      double variable_transform(double z) const override
      {
         assert(z > 0.);
         return std::pow(z, _p);
      }

      /// Inverse variable transformation \f$ z = u^{1/p} \f$.
      double inverse_transform(double u) const override
      {
         assert(u > 0.);
         return std::pow(u, _inv_p);
      }

      /// Jacobian \f$ du/dz = p \, z^{p-1} \f$ as a function of u.
      double jacobian(double u) const override
      {
         assert(u > 0.);
         return _p * std::pow(u, 1. - _inv_p);
      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         assert(u > 0.);
         return _p * (_p - 1.) * std::pow(u, 1. - 2.*_inv_p);
      }
      ///@}

   private:
      double _p;                 // power in the variable transformation
      double _inv_p;             // inverse of that power
};


//------------------------------------------------------------------------------
/**
 * \brief Manages an inverse power-law grid.
 *
 * The associated variable transformation is \f$ u = - (z + z_0)^{-p} \f$ with
 * p > 0.
 *
 * The allowed limits for z are - z0 < z <= `infinity`.
 * The transformation maps z in [1 - z0, `infinity`] onto u in [-1, 0].
 */
//------------------------------------------------------------------------------
class Inv_power_law_grid : public Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief  Constructs the base grid.
       * \param  n_pts         Number of points per subinterval.
       * \param  interv_limits Separation points of the subintervals in the
       *                       physical variable.
       * \param  p             Power in the variable transformation.
       * \param  z0            Offset in the variable transformation (with
       *                       default value zero).
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Inv_power_law_grid(const index_vector& n_pts,
                         const vector_d& interv_limits,
                         double p, double z0 = 0.)
         : Inv_power_law_grid(n_pts, interv_limits, vector_d({p, z0}))
      {}

      /**
       * \brief Equivalent constructor with base class signature.
       *
       * The order of entries in the vector \p{parameters} is {p, z0}.
       *
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 2.
       */
      Inv_power_law_grid(const index_vector& n_pts,
                         const vector_d& interv_limits,
                         const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation \f$ u = - (z + z_0)^{-p} \f$.
      double variable_transform(double z) const override
      {
         assert(z > -_z0);
         if (z == infinity) return 0.;

         return - std::pow(z + _z0, -_p);
      }

      /// Inverse variable transformation \f$ z = (-u)^{-1/p} - z_0 \f$.
      double inverse_transform(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return infinity;

         return std::pow(-u, -_inv_p) - _z0;
      }

      /// Jacobian \f$ du/dz = p \, (z + z_0)^{-p-1} \f$ as a function of u.
      double jacobian(double u) const override
      {
         assert(u <= 0.);
         return _p * std::pow(-u, 1. + _inv_p);
      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         assert(u <= 0.);
         return - _p * (_p + 1.) * std::pow(-u, 1. + 2.*_inv_p);
      }


      ///@}

   private:
      double _p;                 // power in the variable transformation
      double _z0;                // offset in the variable transformation
      double _inv_p;             // inverse of the power
};


//------------------------------------------------------------------------------
/**
 * \brief Manages a grid involving the power of a logarithm.
 *
 * The associated variable transformation is
 * \f[
 *    u = - \left[ \log \frac{z + z_{hi}}{z + z_{lo}} \right]^p
 * \f]
 * with p > 0 and z_lo < z_hi.
 *
 * Allowed values of z are  -z_lo < z <= `infinity`.
 *
 * Behaves like u ~ - [ log(z_hi / z) ]^p for z_lo << z << z_hi
 * and like u ~ - const * z^(-p) for z >> z_hi.  This transform is in
 * particular useful for functions that depend on high powers of log(z).
 */
//------------------------------------------------------------------------------
class Log_pow_grid : public Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief  Constructs the base grid.
       * \param  n_pts         Number of points per subinterval.
       * \param  interv_limits Separation points of the subintervals in the
       *                       physical variable..
       * \param  p             Power in the variable transformation.
       * \param  z_lo          Offset in the denominator of the logarithm.
       *                       Must be smaller than \p{z_hi}.
       * \param  z_hi          Offset in the numerator of the logarithm.
       *
       * \throws std::logic_error if the interval limits are inconsistent,
       *                          if \p{p} <= 0, or if \p{z_lo} => \p{z_hi}.
       */
      Log_pow_grid(const index_vector& n_pts, const vector_d& interv_limits,
                   double p, double z_lo, double z_hi)
         : Log_pow_grid(n_pts, interv_limits, vector_d({p, z_lo, z_hi}))
      {}

      /**
       * \brief Equivalent constructor with base class signature.
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 3.
       */
      Log_pow_grid(const index_vector& n_pts, const vector_d& interv_limits,
                   const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /**
       * \brief Variable transformation
       * \f$ u = - \big[ \log ((z + z_{hi}) / (z + z_{lo})) \big]^p \f$.
       */
      double variable_transform(double z) const override
      {
         if (z == infinity) return 0.;

         const double arg = (z + _z_hi) / (z + _z_lo);

         if (arg > 1.3)
            return - std::pow(std::log(arg), _p);
         else {
            const double arg_minus_1 = (_z_hi - _z_lo) / (z + _z_lo);
            return - std::pow(std::log1p(arg_minus_1), _p);
         }
      }

      /**
       * \brief Inverse variable transformation
       * \f$ z = [z_{hi} - z_{lo} \exp((-u)^{1/p})] / [\exp((-u)^{1/p}) - 1] \f$.
       */
      double inverse_transform(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return infinity;

         const double exp_arg = std::pow(-u, _1_p);
         const double exp = std::exp(exp_arg);

         if (exp_arg > 0.3)
            return (_z_hi - exp *_z_lo) / (exp - 1.);
         else
            return (_z_hi - exp *_z_lo) / std::expm1(exp_arg);
      }

      /**
       * \brief Jacobian \f$ du/dz = p \, (-u)^{1-1/p}\,
       *        (z_{hi} - z_{lo}) / ((z + z_{hi})(z + z_{lo})) \f$
       *        as a function of u.
       */
      double jacobian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         const double z = inverse_transform(u);
         const double ratio = (_z_hi - _z_lo) / ((z + _z_hi) * (z + _z_lo));

         return _p * ratio * std::pow(-u, 1. - _1_p);

      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         const double z = inverse_transform(u);
         const double ratio = (_z_hi - _z_lo) / ((z + _z_hi) * (z + _z_lo));

         return - _p * ratio * std::pow(-u, 1. - 2. *_1_p) *
            ((1./(z + _z_hi) + 1./(z + _z_lo)) * std::pow(-u, _1_p)
             + (_p - 1.) * ratio);
      }
      ///@}

   private:
      double _p;                    // parameter p in the transformation
      double _1_p;                  // inverse of p
      double _z_lo;
      double _z_hi;
};


//------------------------------------------------------------------------------
/**
 * \brief Manages an exponential grid.
 *
 * The associated transformation is \f$ u = - \exp(-m z/4) \f$ with m > 0.
 *
 * Allowed values of z are z <= `infinity`.
 * The transformation maps z in [0, `infinity`] onto u in [-1, 0].
 */
//------------------------------------------------------------------------------
class Exp_grid : public Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief  Constructs the base grid.
       * \param  n_pts         Number of points per subinterval.
       * \param  interv_limits Separation points of the subintervals in the
       *                       physical variable.
       * \param  m             Mass parameter in the variable transformation.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Exp_grid(const index_vector& n_pts, const vector_d& interv_limits,
               double m)
         : Exp_grid(n_pts, interv_limits, vector_d({m}))
      {}

      /**
       * \brief Equivalent constructor with base class signature.
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 1.
       */
      Exp_grid(const index_vector& n_pts, const vector_d& interv_limits,
               const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation \f$ u = - \exp(-m z/4) \f$.
      double variable_transform(double z) const override
      {
         if (z == infinity) return 0.;
         return - std::exp(- _m_over_4 * z);
      }

      /// Inverse variable transformation \f$ z = - (4/m) \log(-u) \f$.
      double inverse_transform(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return infinity;

         return - std::log(-u) / _m_over_4;
      }

      /// Jacobian \f$ du/dz = (m/4) \exp(-m z/4) \f$ as a function of u.
      double jacobian(double u) const override
      {
         assert(u <= 0.);
         return - _m_over_4 * u;
      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         return _m_over_4 * _m_over_4 * u;
      }
      ///@}

   private:
      double _m_over_4;             // parameter m/4 in the transformation
};


//------------------------------------------------------------------------------
/**
 * \brief Manages a grid with a special exponential variable transformation.
 *
 * The associated transformation is
 * \f[
 *    u = - \exp \left[ 1 - \sqrt{1 + m z/2} \,\right]
 * \f]
 * with m > 0.
 *
 * Allowed values of z are  -2/m < z <= `infinity`.
 * At z = -2/m, the Jacobian du/dz of the transformation is infinite.
 *
 * The transformation maps z in [0, `infinity`] onto u in [-1, 0].
 */
//------------------------------------------------------------------------------
class Exp_sqrt_grid : public Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief  Constructs the base grid.
       * \param  n_pts         Number of points per subinterval.
       * \param  interv_limits Separation points of the subintervals in the
       *                       physical variable.
       * \param  m             Mass parameter in the variable transformation.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Exp_sqrt_grid(const index_vector& n_pts, const vector_d& interv_limits,
                    double m)
         : Exp_sqrt_grid(n_pts, interv_limits, vector_d({m}))
      {}

      /**
       * \brief Equivalent constructor with base class signature.
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 1.
       */
      Exp_sqrt_grid(const index_vector& n_pts, const vector_d& interv_limits,
                    const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation \f$ u = - \exp[ 1 - \sqrt{1 + m z/2} ] \f$.
      double variable_transform(double z) const override
      {
         if (z == infinity) return 0.;

         const double root = std::sqrt(1. + _m_over_2 * z);
         return - std::exp(1. - root);
      }

      /**
       * \brief Inverse variable transformation
       *        \f$ z = (2/m) \times [ \log^2(-u) - 2 \log(-u) ] \f$.
       */
      double inverse_transform(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return infinity;

         const double logu = - std::log(-u);
         return logu * (logu + 2.) / _m_over_2;
      }

      /// Jacobian \f$ du/dz = (m/4) \times (-u) / (1 - log(-u)) \f$ as a function of u.
      double jacobian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         return _m_over_4 * u / (std::log(-u) - 1.);
      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         const double aux = 1. - std::log(-u);
         return _m_over_4 * _m_over_4 * u * (1. + aux) / (aux*aux*aux);
      }
      ///@}

   private:
      double _m_over_2;             // parameter m/2 in the transformation
      double _m_over_4;
};


//------------------------------------------------------------------------------
/**
 * \brief Manages a grid in a Gaussian variable.
 *
 * The associated variable transformation is
 * \f[
 *    u = - \exp [ -(m^2 z^2 + m z) / 4 ]
 * \f]
 * with m > 0.
 *
 * Allowed values of z are  -1/(2 m) < z <= `infinity`.
 * At z = -1/(2 m), the inverse Jacobian dz/du is infinite.
 *
 * The transformation maps z in [0, `infinity`] onto u in [-1, 0].
 *
 * The term `(m z)/4` in the exponent is subleading at large z, but ensures a
 * finite inverse Jacobian at z = 0.
 */
//------------------------------------------------------------------------------
class Gauss_grid : public Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief  Constructs the base grid.
       * \param  n_pts         Number of points per subinterval.
       * \param  interv_limits Separation points of the subintervals in the
       *                       physical variable..
       * \param  m             Mass parameter in the variable transformation.
       * \throws std::logic_error if the interval limits are inconsistent.
       */
      Gauss_grid(const index_vector& n_pts, const vector_d& interv_limits,
                 double m)
         : Gauss_grid(n_pts, interv_limits, vector_d({m}))
      {}

      /**
       * \brief Equivalent constructor with base class signature.
       * \throws std::logic_error if the interval limits are inconsistent or
       *                          if the size of \p{parameters} differs from 1.
       */
      Gauss_grid(const index_vector& n_pts, const vector_d& interv_limits,
                 const vector_d& parameters);
      ///@}

      /// \name Variable transformation
      ///@{

      /// Variable transformation \f$ u = - \exp [ -(m^2 z^2 + m z) / 4 ] \f$.
      double variable_transform(double z) const override
      {
         if (z == infinity) return 0.;

         const double arg = _m_over_2 * z;
         return - std::exp(- arg * (arg + 0.5));
      }

      /**
       * \brief Inverse variable transformation
       *        \f$ z = [ \sqrt{1 - 16 \log(-u)} - 1 ] / (2 m) \f$.
       */
      double inverse_transform(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return infinity;

         const double root = std::sqrt(0.25 - 4.*std::log(-u));
         return (root - 0.5) / _m;
      }

      /// Jacobian \f$ du/dz = (m/4) \, (2 m z + 1) \, |u(z)| \f$ as a function of u.
      double jacobian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         const double root = std::sqrt(0.25 - 4.*std::log(-u));
         return - _m_over_2 * root * u;
      }

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      double hessian(double u) const override
      {
         assert(u <= 0.);
         if (u == 0.) return 0.;

         const double root = std::sqrt(0.25 - 4.*std::log(-u));
         return _m_over_2 * _m_over_2 * (root * root - 2.) * u;
      }
      ///@}

   private:
      double _m;                    // parameter m in the transformation
      double _m_over_2;
};

} // namespace bestlime

#endif // BESTLIME_GRID_TYPES_HPP
