//------------------------------------------------------------------------------
/// \file  Grid_1d.hpp
/// \brief Interface of class Grid_1d.
//
// Author(s): Riccardo Nagar and Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_GRID_1D_HPP
#define BESTLIME_GRID_1D_HPP

#include "bestlime/Composite_grid.hpp"
#include "bestlime/Vector_types.hpp"

#include <ostream>
#include <limits>

namespace bestlime
{

//------------------------------------------------------------------------------
/**
 * \brief Abstract base class for one-dimensional grids in 'physical variables'.
 *
 * The classes derived from this class provide the main interface for
 * discretizing functions of 'physical' variables.  In the class member
 * functions, this variable is generically named z.
 *
 * Each derived class of Grid_1d implements a specific variable transformation
 * between the physical variable and a variable u, which is used for defining
 * a composite Chebyshev grid named Grid_1d::_base_grid.  More specifically, an
 * interval in z is divided into several subintervals, and on each of the
 * corresponding subintervals in u, a Chebyshev grid is defined by a linear
 * transformation of u to the interval [-1,1].  The case in which z is the
 * momentum fraction x of a %PDF is documented in
 *
 *     [1] M. Diehl, R. Nagar and F. J. Tackmann
 *         ChiliPDF: Chebyshev Interpolation for Parton Distributions
 *         Eur. Phys. J. C 82 (2022) 257 [arXiv:2112.09703].
 *
 * and the corresponding grid class is X_grid.
 *
 * In some derived grid classes, the upper interval limit may be infinite.
 * For this case, the variable `Grid_1d::infinity` should be used, as it
 * guarantees a controlled handling of the variable transformation at that
 * point.
 *
 * It is required (but not enforced by the base class) that transformations
 * defined in derived classes have the following properties:
 * - du/dz > 0 in the allowed range of z, except at z = `Grid_1d::infinity`.
 * - if the value z = `Grid_1d::infinity` is in the allowed range, then
 *   du/dz = 0 at this point.
 *
 * \par Requirements for derived classes
 *
 * A derived class of Grid_1d must
 * - implement the virtual functions variable_transform(), inverse_transform(),
 *   and jacobian().  The function jacobian() must satisfy the conditions stated
 *   above.
 * - at construction time initialize the variable Grid_1d::_base_grid.
 *   It is recommended to first check that the grid boundaries in z are in
 *   their allowed range.
 */
//------------------------------------------------------------------------------
class Grid_1d
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief Stores grid and parameter info.
       * \param n_pts         Number of points per subinterval.
       * \param interv_limits Vector of separation points of the subintervals
       *                      in the physical variable.
       * \param parameters    Parameters of the variable transformation.
       *                      Empty if the transformation has no parameters.
       *
       * Creates a `Subint_info` object for the grid in the physical variable
       * and stores the parameters of variable transformation.
       *
       * \p{interv_limits} must have at least two entries, and the separation
       * points must be strictly ascending.
       *
       * \throws std::logic_error if the conditions on \p{interv_limits} are not
       *         satisfied.
       */
      Grid_1d(const index_vector& n_pts,
              const vector_d& interv_limits, const vector_d& parameters)
         : _original_info{Subint_info(n_pts, interv_limits)},
           _parameters{parameters}

      {
         _check_limits_ascending(interv_limits);
      }
      ///@}

      /**
       * \name Transformation between the variables z and u
       *
       * z is the physical variable, and u is the variable in which a composite
       * Chebyshev grid is created.
       *
       * By convention, the value z = Grid_1d::infinity is mapped onto u = 0.
       */
      ///@{

      /// Variable transformation u(z).
      virtual double variable_transform(double z) const = 0;

      /// Inverse transformation z(u).
      virtual double inverse_transform(double u) const = 0;

      /// Jacobian du/dz as a function of u.
      virtual double jacobian(double z) const = 0;

      /// Hessian \f$ d^2 u / dz^2 \f$ as a function of u.
      virtual double hessian(double z) const = 0;
      ///@}

      /// \name Accessors & queries
      ///@{

      /// Returns the \p{i}-th grid element in the physical variable.
      double operator[](index_t i) const;

      /// Returns the first grid element in the physical variable.
      double front() const
      {
         return _original_info.interval_limits().front();
      }

      /// Returns the last grid element in the physical variable.
      double back() const
      {
         return _original_info.interval_limits().back();
      }

      /// Computes and returns the full grid in the physical variable.
      grid_vector values() const
      {
         return _grid_values(_base_grid, _original_info);
      }

      /// Returns the size of the grid.
      index_t size() const { return _base_grid.size(); }

      /// Returns the Subint_info object in the physical variable.
      const Subint_info& info() const { return _original_info; }

      /**
       * \brief Returns the base grid, i.e. the Composite_grid object used for
       *        Chebyshev interpolation.
       */
      const Composite_grid& base_grid() const { return _base_grid; }

      /**
       * \brief Returns the parameters of the variable transformation between
       *        z and u.
       */
      const vector_d& parameters() const { return _parameters; }

      /**
       * \brief Returns `true` if \p{z} is contained in the grid and `false`
       *        otherwise.
       */
      bool contains(double z) const
      {
         return (front() <= z && z <= back());
      }

      /**
       * \brief Writes the number of points and the interval limits in the
       *        physical variable to the standard output.
       *
       * \note The value Grid_1d::infinity is printed as literal 'infinity'.
       */
      void print_info() const;

      /**
       * \brief Writes the grid values of z, u, and derived quantities to the
       *        standard ouput.
       *
       * Includes diagnostics for the numerical precision of the variable
       * transformation and its inverse.
       *
       * \note Prints the internal value of Grid_1d::infinity.
       */
      void print_grid() const;
      ///@}

      /// \name Differentiation with respect to z
      ///@{

      /**
       * \brief Computes the differentiation matrix in subinterval number k.
       *
       * Returns the differentiation matrix D_ij for the specified subinterval.
       * The derivative of a function f is approximately given by
       *
       * \f[
       *    \frac{d f(z_i)}{d z} \approx \sum_{j} D_{ij} \, f(z_j) ,
       * \f]
       *
       * where z_i and z_j are the grid points on the subinterval.
       *
       * The differentiation formula is exact if f(z) is a polynomial of degree
       * n-1 in u(z), where n is the number of points on the subgrid.
       *
       * \note The number of the subinterval for a given z is given by the
       * functions which_subinterval_right() and which_subinterval_left().
       */
      grid_matrix diff_matrix(size_t k) const;

      /**
       * \brief Computes the matrices for the first and second derivative in
       *        subinterval number k.
       *
       * \returns  A pair `(D_1, D_2)` of differentiation matrices for the
       *           specified subinterval.
       *
       * `D_1` is identical to the matrix returned by diff_matrix(), and `D_2`
       * is its analog for the second derivative.  The second derivative of a
       * function f is approximately given by
       *
       * \f[
       *    \frac{d^2 f(z_i)}{d z^2} \approx \sum_{j} (D_2)_{ij} \, f(z_j) ,
       * \f]
       *
       * where z_i and z_j are the grid points on the subinterval.
       *
       * The differentiation formula is exact if f(z) is a polynomial of degree
       * n-1 in u(z), where n is the number of points on the subgrid.
       */
      std::pair<grid_matrix, grid_matrix> diff_matrices(size_t k) const;
      ///@}

      /// Constant to be used for an infinite upper interval limit.
      static constexpr double infinity = std::numeric_limits<double>::max();

   protected:
      /**
       * \brief Grid in the transformed variable u.
       *
       * Must be initizialized by the constructors of derived classes.
       */
      Composite_grid _base_grid;

      /**
       * \brief Initializes the grid in the transformed variable u.
       * \param n_pts               Number of points per subinterval.
       * \param interv_limits_in_z  Vector of separation points of the
       *                            subintervals in the physical variable.
       *
       * Initializes the variable Grid_1d::_base_grid when called in a derived
       * class, where the variable transform is defined.
       */
      void _initialize_base_grid(const index_vector& n_pts,
         const vector_d& interv_limits_in_z);

   private:
      Subint_info _original_info;         // Info on grid in physical variable
      vector_d _parameters;

      grid_vector _grid_values(const Composite_grid& base_grid,
                            const Subint_info& orig_info) const;

      // Checks if the interval limits are strictly ascending.
      // Throws an exception if not.
      void _check_limits_ascending(const vector_d& limits) const;
};

//------------------------------------------------------------------------------
// Non-member functions
//------------------------------------------------------------------------------

/// \name Comparison
///@{
//------------------------------------------------------------------------------
/**
 * \relates Grid_1d
 * \brief   Equality comparison operator for Grid_1d.
 * \returns `true` if \p{lhs} equals \p{rhs}, `false` otherwise.
 *
 * Two Grid_1d objects are considered equal if they have the same `typeid()`
 * (i.e. both belong to the base class or to the same derived class) and
 * if they have been initialized with identical values of \p{n_pts},
 * \p{interv_limits}, and \p{parameters} in the constructor.
 */
bool operator==(const Grid_1d& lhs, const Grid_1d& rhs);

//------------------------------------------------------------------------------
/**
 * \relates Grid_1d
 * \brief   Inequality comparison operator for Grid_1d.
 * \returns `true` if \p{lhs} is not equal to \p{rhs}, `false` otherwise.
 *
 * This is equivalent to `!(lhs == rhs)`.
 */
inline bool operator!=(const Grid_1d& lhs, const Grid_1d& rhs)
{
   return ! (lhs == rhs);
}
///@}

/// \name Output
///@{
//------------------------------------------------------------------------------
/**
 * \brief Prints grid information in condensed form.
 *
 * Gives the subinterval limits `z_i` in the physical variable and the numbers
 * `n_i` of points per subgrid in the format
 *
 *       [z_0, z_1, ..., z_k]_(n_1, n_2, ..., n_k)
 *
 * Note that the total number of grid points is `(sum_i n_i) - (k-1)`.
*/
std::ostream& operator<<(std::ostream& ostream, const Grid_1d& grid);
///@}

} // namespace bestlime

#endif // BESTLIME_GRID_1D_HPP
