//------------------------------------------------------------------------------
/// \file  Cheb_grid.hpp
/// \brief Interface of class Cheb_grid.
//
// Author(s): Riccardo Nagar
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_CHEB_GRID_HPP
#define BESTLIME_CHEB_GRID_HPP

#include "bestlime/Vector_types.hpp"

namespace bestlime
{

//------------------------------------------------------------------------------
/**
 * \brief Computes and stores a Chebyshev grid and related quantities.
 *
 * Constructs a basic Chebyshev grid in the interval [-1, 1] and stores
 * the polynomial order N, the Chebyshev points, the sines of the Chebyshev
 * angles, as well as the integration weights for the Clenshaw-Curtis rule.
 *
 * Also provides routines for computing the differentiation matrix and the
 * matrix of \f$ \cos (i j \pi/N) \f$.  These matrices are not stored within
 * the class.
 */
//------------------------------------------------------------------------------
class Cheb_grid
{
   public:
      /// \name Constructor
      ///@{
      /**
       * \brief Constructs a standard Chebyshev grid on the interval [-1,1].
       * \param N Order of the Chebyshev polynomials.
       *
       * \p{N} must be > 1, and the size of the grid will be \p{N} + 1.
       *
       * (A grid must have at least 3 points for interpolation without end
       * points to work.)
       */
      Cheb_grid(index_t N);
      ///@}

      /// \name Queries and accessors
      ///@{
      /**
       * \brief Returns the \p{i}-th element of the grid, i.e.
       *        \f$ \cos(i \pi/N) \f$.
       *
       * The range of i is from 0 to N.
       * No range checking is performed.
       */
      double operator[](index_t i) const { return _cos_pi2N(2*i); }

      /// Returns the size of the grid.
      index_t size() const { return _n + 1; }

      /**
       * \brief Returns a vector with \f$ \sin^2 (i \pi/N) \f$ in the i-th
       *        element.
       *
       * The range of i is from 0 to N.
       * This vector is needed for interpolation without end points in
       * the Barycentric class.
       */
      const grid_vector& sin2_grid() const { return _sin2_grid; }

      /// Returns the Clenshaw-Curtis integration weights.
      const grid_vector& clenshaw_weights() const { return _clenshaw_weights; }
      ///@}

      /// \name Matrix computation
      ///@{

      /// Computes the differentiation matrix
      grid_matrix diff_matrix() const;

      /// Computes the square of the differentiation matrix
      grid_matrix diff_matrix_squared() const;

      /**
       * \brief Computes the matrix of Chebyshev coefficients
       * \f$ M_{ij} = \cos(i j \pi/N) \f$
       *
       * The range of i and j is from 0 to N.
       */
      grid_matrix cheb_matrix() const;
      ///@}

      /// \name Linear transformation
      ///@{
      /**
       * \brief Transforms the grid from the basic interval [1:-1] to the
       *        interval [\p{a}, \p{b}].
       * \returns The transformed grid values.
       *
       * \note Optimized for precision around the interval end points \p{a}
       *       and \p{b}.
       */
      grid_vector lin_transf_grid(double a, double b) const;
      ///@}

      /// \name Output
      ///@{
      /**
       * \brief Prints the grid to the standard output.
       *
       * Prints the elements \f$ \cos(i \pi/N) \f$ of the Chebyshev grid in a
       * column.
       */
      void print() const;
      ///@}

   private:
      index_t _n;                      // Order of the Chebyshev polynomial

      grid_vector _sin_pi2N_grid;      // sin (i pi /(2N))  for i = 0,...,N
      grid_vector _sin2_grid;          // sin^2 (i pi/N)    for i = 0,...,N

      grid_vector _clenshaw_weights;   // Clenshaw-Curtis weights

      // Compute grids
      grid_vector _make_sin_pi2N_grid() const;
      grid_vector _make_sin2_grid() const;
      grid_vector _make_clenshaw_weights() const;

      // Auxiliary functions

      // Evaluates cos(k pi/(2N)) and sin(k pi/(2N)) for non-negative integer k.
      double _cos_pi2N(index_t k) const;
      double _sin_pi2N(index_t k) const;

      // Evaluates difference z_i - z_j of Chebyshev points.
      double _grid_diff(index_t i, index_t j) const;
};

} // namespace bestlime

#endif // BESTLIME_CHEB_GRID_HPP
