//------------------------------------------------------------------------------
/// \file  Bessel_integrator_special.hpp
/// \brief Interface of class Bessel_integrator_special.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_BESSEL_INTEGRATOR_SPECIAL_HPP
#define BESTLIME_BESSEL_INTEGRATOR_SPECIAL_HPP

#include "bestlime/Bessel_integrator_special_impl.hpp"
#include "bestlime/Vector_types.hpp"
#include "bestlime/Grid_types.hpp"

#include <iostream>

//------------------------------------------------------------------------------
namespace bestlime
{

/**
 * \brief Computes the nonsingular part of Bessel integrals
 * that can only be defined in the sense of a distribution.
 *
 * \tparam Grid_type  Specifies the variable transform used for the
 *                    interpolation grid, see the documentation of
 *                    Bessel_integrator.
 *
 * This class provides the user interface for computing integrals of the form
 *
 * \f[
 *    \int_{0}^{\infty} dz \: J_{\nu}(q z) \,
 *       \left( \frac{1+z}{z} \right)^{\nu} \, f(z)
 * \f]
 *
 * where \f$ J_\nu \f$ is a Bessel function of the first kind.  Its order
 * \f$ \nu \f$ must be zero or positive, but need not be integer.
 *
 * If the function `f(z)` becomes infinite at large `z` and satisfies the
 * conditions stated below, then the above integral can be defined as a
 * distribution in `q`.  The integration calls of this class give the regular
 * part of this distribution at `q > 0`, rewritten as a convergent integral
 * over \f$ J_{\nu + 2}(q z) \f$ times a function derived from `f(z)`.  This
 * integral is evaluated using the class Bessel_integrator.
 *
 * The distributional value of the integral is defined as described in section
 * 6 and appendix D of
 *
 *       [1] Markus Diehl and Oskar Grocholski
 *           Efficient computation of Fourier-Bessel transforms
 *           for transverse-momentum dependent parton distributions
 *           and other functions
 *           arXiv:2405.08616 [hep-ph]
 *
 * provided that at the integration boundaries one has
 * \f[
 *    \left( z \frac{d}{dz} \right)^k f(z)
 *       \to \mbox{const} ~~~\mbox{at } z \to 0 ,
 *    \qquad
 *    z^{-3/2} \, \left( z \frac{d}{dz} \right)^k f(z)
 *       \to 0 ~~~\mbox{at } z \to \infty ,
 *    \qquad
 *    k = 0, 1, 2,
 * \f]
 * where `const` can be finite or zero.  These conditions are not checked by the
 * algorithm, and it is the responsibility of callers to ensure that they are
 * satisfied.
 *
 * In line with these conditions, the discretized value of `f(z)` at
 * z = `infinity` in the input of integration calls is ignored.  Technically,
 * f(z) / (1+z)^2 at z = `infinity` is set to 0 in the algorithm.
 *
 * The integration calls of this class yield the correct result if `f(z)`
 * remains finite for \f$ z \to \infty \f$, so that the integral is convergent
 * in the usual sense.
 *
 * The class contains also calls for evaluating the integral
 *
 * \f[
 *    \int_{0}^{\infty} dz \: J_{\nu}(q z) \, \tilde{f}(z)
 * \f]
 *
 * In this case, the conditions above must be satisfied for the function
 * \f$ f(z) = z^{\nu} (1+z)^{-\nu}  \tilde{f}(z) \f$.  Moreover,
 * \f$ \tilde{f}(0) \f$ must be finite.
 *
 * The performance considerations in the documentation of the class
 * Bessel_integrator apply to the present class as well.
 */
template <class Grid_type>
class Bessel_integrator_special
{
   public:
      /// \name Constructors
      ///@{

      /**
      * \brief Standard constructor.
      *
      * \param n_points     The number of points in each subinterval.
      * \param z_limits     The boundaries of the subintervals in `z`.
      * \param grid_params  The parameters of the grid variable transform.
      * \param nu           The class contains calls for Bessel functions of
      *                     order nu only, contrary to Bessel_integrator.
      *                     Only values \p{nu} => 0 are accepted.
      *
      * \throws std::invalid_argument if \p{nu} < 0 or if the \p{grid} does not
      * go from 0.0 to Grid_1d::infinity.
      */
      Bessel_integrator_special(const index_vector& n_points,
                  const vector_d& z_limits,
                  const vector_d& grid_params,
                  double nu = 0)
         : Bessel_integrator_special(n_points, z_limits, grid_params, nu, true)
      {}

      /**
      * \brief Constructor with control over the integration method.
      *
      * \param n_points        The number of points in each subinterval.
      * \param z_limits        The boundaries of the subintervals in `z`.
      * \param grid_params     The parameters of the grid variable transform.
      * \param nu              The class contains calls for Bessel functions of
      *                        order nu only, contrary to Bessel_integrator.
      *                        Only values \p{nu} => 0 are accepted.
      * \param use_quadrature  Determines whether Clenshaw-Curtis quadrature can
      *                        be used.
      * \param r_LU_max        Optional parameter for selecting the method
      *                        (LU or SV decomposition) when solving the ODE.
      * \param r_SV_max        Optional parameter for trucating the SV
      *                        decomposition when solving the ODE.
      *
      * \see Bessel_integrator for information about the parameter
      * \p{use_quadrature}.
      *
      * \see Linear_solver for information about the parameters
      * \p{r_LU_max} and \p{r_SV_max}.
      *
      * \throws std::invalid_argument if \p{nu} < 0, or if the \p{grid} does not
      * go from 0.0 to Grid_1d::infinity, or if \p{r_LU_max} or \p{r_SV_max}
      * are outside their allowed ranges.
      */
      Bessel_integrator_special(const index_vector& n_points,
                                const vector_d& z_limits,
                                const vector_d& grid_params,
                                double nu,
                                bool use_quadrature,
                                double r_LU_max = 1e-12,
                                double r_SV_max = 1e-12)
         : _grid{Grid_type(n_points, z_limits, grid_params)},
           _integrator{_grid, nu, use_quadrature, r_LU_max, r_SV_max}
      {}
      ///@}

      /// \name Destructor etc.
      ///@{
      ~Bessel_integrator_special() = default;
      Bessel_integrator_special(const Bessel_integrator_special&) = default;
      Bessel_integrator_special(Bessel_integrator_special&& other);
      Bessel_integrator_special& operator=(const Bessel_integrator_special&) = default;
      Bessel_integrator_special& operator=(Bessel_integrator_special&& other) = default;
      ///@}

      /// \name Integration calls for discretized functions
      ///@{
      /**
      * \brief Computes the integral of `J_nu(q z) ftilde(z)`.
      *
      * \returns The integral
      * \f[
      *    \int_{0}^{\infty} dz \: J_{\nu} (qz) \, \tilde{f}(z)
      * \f]
      * using the discretized values \p{f_values} of the function ftilde(z).
      *
      * The effect of the parameter \p{verbose} is the same as for
      * Bessel_integrator::int_J_nu().
      *
      * \throws std::invalid_argument if \p{q} <= 0 or if the size of
      * \p{f_values} does not match the interpolation grid..
      */
      double int_J_nu(const grid_vector& f_values, double q, int verbose = 0)
      {
         return _integrator.int_J_nu(f_values, q, verbose);
      }

      /**
       * \brief Computes a weighted integral of `J_nu(q z) f(z)`.
       *
       * \returns The integral
      * \f[
      *    \int_{0}^{\infty} dz \: J_{\nu} (qz) \,
      *       \left( \frac{1+z}{z} \right)^{\nu} \, f(z)
      * \f]
      * using the discretized values \p{f_values} of the function f(z).
      *
      * The effect of the parameter \p{verbose} is the same as for
      * Bessel_integrator::int_J_nu().
      *
      * \throws std::invalid_argument if \p{q} <= 0 or if the size of
      * \p{f_values} does not match the interpolation grid..
      */
      double weighted_int_J_nu(const grid_vector& f_values, double q,
                               int verbose = 0)
      {
         return _integrator.weighted_int_J_nu(f_values, q, verbose);
      }
      ///@}

      /// \name Integration calls for several discretized functions at once
      ///@{

      /**
       * \brief As int_J_nu(const grid_vector&, double, int) but for several
       *        functions.
       *
       * \returns A vector whose i'th component is the integral corresponding to
       *          the discretized function values in the i'th component of the
       *          vector \p{f_values}.
       *
       * \note Unlike the call for single functions, this call does not offer
       *       verbose output.
       */
      vector_d int_J_nu(const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.int_J_nu(f_values, q);
      }

      /// As weighted_int_J_nu(const grid_vector&, double, int) but for several functions.
      vector_d weighted_int_J_nu(
         const std::vector<grid_vector>& f_values, double q)
      {
         return _integrator.weighted_int_J_nu(f_values, q);
      }
      ///@}

      /// \name Integration weights
      ///@{

      /**
       * \brief Computes integration weights for the specified value of \p{q}.
       *
       * The computed weights correspond to the integral computed by
       * int_J_nu() if \p{weighted} = `false` and to the one computed by
       * weighted_int_J_nu() if \p{weighted} = `true`.  The corresponding
       * integral is then obtained as
       *
       *       sum_i weights[i] * f_values[i]
       *
       * where `f_values` is the vector of discretized function values.  See
       * Bessel_integrator::weights_J_nu() for more information.
       */
      grid_vector weights_J_nu(double q, bool weighted = false)
      {
         return _integrator.weights_J_nu(q, weighted);
      }
      ///@}

      /// \name Function discretization
      ///@{

      /**
       * \brief   Discretizes a function of `z` and (optional) additional
       *          arguments on the interpolation grid.
       *
       * \param   funct      A function with first argument `z` and (optional)
       *                     additional arguments.
       * \param   arguments  The additional arguments.
       *
       * \returns The vector of function values \p{funct}(z_i, \p{arguments}),
       *          where `z_i` are the points on the discretization grid.
       */
      template <typename... Args>
      grid_vector discretize(std::function<double(double, Args...)>& funct,
                             Args... arguments) const
      {
         return _integrator.discretize<Args...>(funct, arguments...);
      }
      ///@}

      /// \name Accessors
      ///@{

      /// Returns the `z` values on the interpolation grid.
      const grid_vector& z_values() const
      {
         return _integrator.z_values();
      }

      /// Returns the boundaries of the subintervals in `z`.
      const vector_d& z_limits() const
      {
         return _grid.info().interval_limits();
      }

      /// Returns the number of points in each subinterval.
      const index_vector& n_points() const
      {
         return _grid.info().n_points();
      }

      /**
       * \brief Returns the parameters of the grid variable transform.
       *
       * Is empty if the transform does not depend on any parameter.
       */
      const vector_d& grid_params() const
      {
         return _grid.parameters();
      }

      /// Returns the value of `nu` specified at construction.
      double nu() const
      {
         return _integrator.nu();
      }

      /// Returns the current value of `q`.
      double current_q() const
      {
         return _integrator.current_q();
      }

      /**
       * \brief Prints info about the interpolation grid to the standard output.
       *
       * The information is given in the form `[z_limits]_(n_points)`, see
       * z_limits() and n_points().
       *
       * The output does _not_ end with a newline character.
       *
       * \note The total number of grid points is readily obtained by calling
       *       z_values().size().
       */
      void print_grid_info() const { std::cout << "grid in z: " << _grid; }
      ///@}

      /// \name Information about the integration method
      ///@{

      /// Returns the quadature setting specified at construction.
      bool quadrature_is_used() const
      {
         return _integrator.basic_integrator().quadrature_is_used();
      }

      /**
       * \brief Returns the first zero of `J_{nu+2}(x)` for `nu` specified at
       *        construction.
       *
       * This value is used to determine whether quadrature or the Levin method
       * is used in a given subinterval.
       */
      double first_bessel_zero() const
      {
         return _integrator.basic_integrator().first_bessel_zero();
      }

      /**
       * \brief Prints info about the integration method to the standard output.
       *
       * Provides the same output as Bessel_integrator::print_info().
       */
      void print_info(double q) { _integrator.print_info(q); }
      ///@}

   private:
      Grid_type _grid;
      Bessel_integrator_special_impl _integrator;
};

//------------------------------------------------------------------------------
// Definititions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
template <class Grid_type>
Bessel_integrator_special<Grid_type>::Bessel_integrator_special(
   Bessel_integrator_special&& other)
   : _grid{other._grid},
     _integrator{other._grid, other.nu(), other.quadrature_is_used(),
                 other._integrator.basic_integrator().r_LU_max(),
                 other._integrator.basic_integrator().r_SV_max()}
{}

} // namespace bestlime

#endif // BESTLIME_BESSEL_INTEGRATOR_SPECIAL_HPP
