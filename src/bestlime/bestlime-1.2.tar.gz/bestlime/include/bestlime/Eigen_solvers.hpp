//------------------------------------------------------------------------------
/// \file  Eigen_solvers.hpp
/// \brief Includes the LU and SVD headers of Eigen, with certain warnings disabled.
//
// Author(s): Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_EIGEN_SOLVERS_HPP
#define BESTLIME_EIGEN_SOLVERS_HPP

// disable certain warnings while including Eigen headers
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#pragma GCC diagnostic ignored "-Wsign-conversion"

#include "bestlime/Eigen/LU"
#include "bestlime/Eigen/SVD"

#pragma GCC diagnostic pop

#endif // BESTLIME_EIGEN_SOLVERS_HPP
