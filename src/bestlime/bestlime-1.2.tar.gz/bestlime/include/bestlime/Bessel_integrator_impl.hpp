//------------------------------------------------------------------------------
/// \file  Bessel_integrator_impl.hpp
/// \brief Interface of class Bessel_integrator_impl.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_INTEGRATOR_IMPL_HPP
#define BESTLIME_INTEGRATOR_IMPL_HPP

#include "bestlime/Vector_types.hpp"
#include "bestlime/Linear_solver.hpp"
#include "bestlime/Eigen_core.hpp"
#include <functional>

namespace bestlime
{

class Grid_1d;

/**
 * \brief Implementation of the class Bessel_integrator.
 *
 * This class implements the methods of the class Bessel_integrator, where
 * further information can be found.
 *
 * The present class operates (via a `reference_wrapper`) on an external
 * Grid_1d object, which is specified in the constructor and must exist during
 * the lifetime of the class.
 */
class Bessel_integrator_impl
{
   friend class Bessel_integrator_special_impl;

   public:
      /// \name Constructors
      ///@{

      /**
      * \brief Standard constructor.
      *
      * \param grid        The interpolation grid for the integrand.
      * \param nu          The class contains calls for Bessel functions of
      *                    order nu-1, nu, and nu+1.
      *                    Only values \p{nu} => 1 are accepted.
      *
      * \throws std::invalid_argument if \p{nu} < 1 or if the lowest z value on
      * the interpolation grid is negative.
      */
      Bessel_integrator_impl(const Grid_1d& grid, double nu)
         : Bessel_integrator_impl(grid, nu, true)
      {};

      /**
      * \brief Constructor with control over the integration method.
      *
      * \see Bessel_integrator for more information about the last three
      *      arguments.
      *
      * \throws std::invalid_argument if \p{nu} < 1, or if the lowest z value on
      * the interpolation grid is negative, or if \p{r_LU_max} or \p{r_SV_max}
      * are outside their allowed ranges.
      */
      Bessel_integrator_impl(const Grid_1d& grid, double nu,
                             bool use_quadrature,
                             double r_LU_max = 1e-12,
                             double r_SV_max = 1e-12);
      ///@}

      /// \name Integration calls for discretized functions
      ///@{

      double int_J_nu(const grid_vector& f_grid, double q, int verbose = 0)
      {
         return _int_direct(f_grid, q, 0, false, verbose);
      }

      double int_J_nu_plus_1(const grid_vector& f_grid, double q, int verbose = 0)
      {
         return _int_direct(f_grid, q, 1, false, verbose);
      }

      double int_J_nu_minus_1(const grid_vector& f_grid, double q, int verbose = 0)
      {
         return _int_by_parts(f_grid, q, false, verbose);
      }

      double weighted_int_J_nu(const grid_vector& f_grid, double q,
                               int verbose = 0)
      {
         return _int_direct(f_grid, q, 0, true, verbose);
      }

      double weighted_int_J_nu_plus_1(const grid_vector& f_grid, double q,
                                      int verbose = 0)
      {
         return _int_direct(f_grid, q, 1, true, verbose);
      }

      double weighted_int_J_nu_minus_1(const grid_vector& f_grid, double q,
                                       int verbose = 0)
      {
         return _int_by_parts(f_grid, q, true, verbose);
      }
      ///@}

      /// \name Integration calls for vectors of discretized functions
      ///@{

      vector_d int_J_nu(const std::vector<grid_vector>& f_grids, double q)
      {
         return _int_direct(f_grids, q, 0, false);
      }

      vector_d int_J_nu_plus_1(const std::vector<grid_vector>& f_grids,
                               double q)
      {
         return _int_direct(f_grids, q, 1, false);
      }

      vector_d int_J_nu_minus_1(const std::vector<grid_vector>& f_grids,
                                double q)
      {
         return _int_by_parts(f_grids, q, false);
      }

      vector_d weighted_int_J_nu(const std::vector<grid_vector>& f_grids,
                                 double q)
      {
         return _int_direct(f_grids, q, 0, true);
      }

      vector_d weighted_int_J_nu_plus_1(const std::vector<grid_vector>& f_grids,
                                        double q)
      {
         return _int_direct(f_grids, q, 1, true);
      }

      vector_d weighted_int_J_nu_minus_1(const std::vector<grid_vector>& f_grids,
                                         double q)
      {
         return _int_by_parts(f_grids, q, true);
      }
      ///@}

      /// \name Integration weights
      ///@{

      grid_vector weights_J_nu(double q, bool weighted = false)
      {
         return _direct_int_weights(q, 0, weighted);
      };

      grid_vector weights_J_nu_plus_1(double q, bool weighted = false)
      {
         return _direct_int_weights(q, 1, weighted);
      };

      grid_vector weights_J_nu_minus_1(double q, bool weighted = false)
      {
         return _int_by_parts_weights(q, weighted);
      };
      ///@}

      /// \name Function discretization
      ///@{

      template <typename... Args>
      grid_vector discretize(std::function<double(double, Args...)>& funct,
                             Args... arguments) const;
      ///@}

      /// \name Accessors
      ///@{

      /**
       * \brief    Returns the interpolation grid.
       * \returns  The interpolation grid object, which is an instance of a
       *           class derived from Grid_1d.
       */
      const auto& grid() const            { return _gridref.get(); }

      const grid_vector& z_values() const { return _z_values; }

      double nu() const                   { return _nu; }

      double current_q() const            { return _q; }
      ///@}

      /// \name Information about the integration method
      ///@{

      bool quadrature_is_used() const     { return _use_quadrature; }

      double first_bessel_zero() const    { return _first_bessel_zero;}

      void print_info(double q);

      double r_LU_max() const             { return _r_LU_max; }

      double r_SV_max() const             { return _r_SV_max; }

      /// Returns the linear equation solver for subinterval \p{i}.
      const Linear_solver& linear_solver(size_t i) const
      {
         return _lin_eq_solver.at(i);
      }
      ///@}

   private:
      double _nu;            // fixed at class construction

      // current value of q, is updated
      // initial value enforces update at first integration call
      double _q {0.};

      // reference to the interpolation grid
      std::reference_wrapper<const Grid_1d> _gridref;

      bool _use_quadrature;

      // Linear_solver control parameters
      double _r_LU_max;
      double _r_SV_max;

      // values of z and r(z) = z/(1+z)
      grid_vector _z_values;
      grid_vector _r_values;

      // values of r^nu and r^(nu-1)
      grid_vector _weights_nu;
      grid_vector _weights_nu_m1;

      // values of the weighted Bessel functions at intervals limits
      vector_d _omega_1;
      vector_d _omega_2;

      // differentiation matrices for integration by parts (one per subgrid)
      // discretizes z^nu * d/dz [ z^(-nu) * r^(1-nu) * function(z) ]
      std::vector<grid_matrix> _ibp_diff_matrices;

      // matrices B for Levin method (one per subgrid)
      std::vector<grid_matrix> _B_matrices;

      // linear equation solver (one per subgrid)
      std::vector<Linear_solver> _lin_eq_solver;

      // outer index refers to subgrid, inner index to point on subgrid
      std::vector<grid_vector> _clenshaw_weights;
      std::vector<grid_vector> _integration_weights;

      double _first_bessel_zero;

      void _check_fgrid(const grid_vector& f_grid) const;

      double _int_direct(const grid_vector& f_grid, double q,
                         int mode, bool weighted, int verbose);
      vector_d _int_direct(const std::vector<grid_vector>& f_grids, double q,
                           int mode, bool weighted);

      double _int_by_parts(const grid_vector& f_grid, double q,
                           bool weighted, int verbose);
      vector_d _int_by_parts(const std::vector<grid_vector>& f_grids, double q,
                             bool weighted);

      grid_vector _direct_int_weights(double q, int mode, bool weighted);
      grid_vector _int_by_parts_weights(double q, bool weighted);

      double _upper_bdry_factor(bool weighted) const;
      double _lower_bdry_factor(bool weighted) const;

      double _integral(const std::vector<grid_vector>& F_vec,
                       int verbose = 0) const;

      // F_vec = {f1_grid, f2_grid} in Levin's method
      std::vector<grid_vector> _make_F_vec(
         const grid_vector& f_grid, int mode, bool weighted) const;

      // F_vec corresponding to basis functions of the interpolation grid:
      // f(z_i) = delta_{i, grid_point}
      std::vector<grid_vector> _make_F_basis_vec(
         index_t grid_point, int mode, bool weighted) const;

      // update all internal variables depending on q
      void _update_q(double q);

      // update vectors of weighted Bessel functions
      void _update_omega(double q);

      // compute initial matrices and Clenshaw-Curtis weights
      void _make_matrices();
      void _make_clenshaw_weights();

      // update B matrix and linear solver
      void _update_solver(size_t subint, double q);

      // set up Clenshaw-Curtis quadrature over a subinterval
      void _setup_quadrature(size_t subint, double q);

      // Bessel functions at i-th grid point, weighted by (1+z)^nu / z^nu
      double _weighted_bessel_nu(index_t i, double q) const;
      double _weighted_bessel_nu_p1(index_t i, double q) const;

      // auxiliary functions: z/(1+z) and 1/(1+z)
      double _z_1pz(double z) const;
      double _1_1pz(double z) const;

      void _print_basic_info() const;
      void _print_subgrid_info(size_t subint) const;
      void _print_method_info(size_t subint) const;

      using vector_arg = Eigen::Ref<const grid_vector>;

      void _print_levin_info(size_t i,
                             const vector_arg& F, const vector_arg& P) const;
      void _print_levin_code(size_t i,
                             const vector_arg& F, const vector_arg& P) const;
};

//------------------------------------------------------------------------------
// Member function definition
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
template <typename... Args>
grid_vector Bessel_integrator_impl::discretize(
   std::function<double(double, Args...)>& funct, Args... arguments) const
{
   grid_vector result(z_values().size());

   for (index_t i = 0; i < z_values().size(); ++i) {
      result[i] = funct(z_values()[i], arguments...);
   }

   return result;
}

} // namespace bestlime

#endif //BESTLIME_INTEGRATOR_IMPL_HPP
