//------------------------------------------------------------------------------
/// \file  Bessel_integrator_special_impl.hpp
/// \brief Interface of class Bessel_integrator_special_impl.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#ifndef BESTLIME_BESSEL_INTEGRATOR_SPECIAL_IMPL_HPP
#define BESTLIME_BESSEL_INTEGRATOR_SPECIAL_IMPL_HPP

#include "bestlime/Vector_types.hpp"
#include "bestlime/Bessel_integrator_impl.hpp"
#include "bestlime/Grid_types.hpp"

#include <functional>

namespace bestlime
{

/**
 * \brief Implementation of the class Bessel_integrator_special.
 *
 * This class implements the methods of the class Bessel_integrator_special,
 * where further information can be found.
 *
 * The present class operates (via a `reference_wrapper`) on an external
 * Grid_1d object, which is specified in the constructor and must exist during
 * the lifetime of the class.
 */
class Bessel_integrator_special_impl
{
   public:
      /// \name Constructors
      ///@{

      /**
      * \brief Standard constructor.
      *
      * \param grid        The interpolation grid for the integrand.
      * \param nu          Order of the Bessel functions in the integral.
      *                    Only values \p{nu} => 0 are accepted.
      *
      * \throws std::invalid_argument if \p{nu} < 0 or if the \p{grid} does not
      * go from 0.0 to Grid_1d::infinty.
      */
      Bessel_integrator_special_impl(const Grid_1d& grid, double nu)
         : Bessel_integrator_special_impl(grid, nu, true)
      {}

      /**
      * \brief Constructor with control over the integration method.
      *
      * \throws std::invalid_argument if \p{nu} < 0, or if the \p{grid} does not
      * go from 0.0 to Grid_1d::infinty, or if \p{r_LU_max} or \p{r_SV_max}
      * are outside their allowed ranges.
      */
      Bessel_integrator_special_impl(const Grid_1d& grid,
                                     double nu,
                                     bool use_quadrature,
                                     double r_LU_max = 1e-12,
                                     double r_SV_max = 1e-12);
      ///@}

      /// \name Integration calls for discretized functions
      ///@{

      double int_J_nu(const grid_vector& f_grid, double q, int verbose = 0)
      {
         return _integrate(f_grid, q, false, verbose);
      }

      double weighted_int_J_nu(const grid_vector& f_grid,
                               double q, int verbose = 0)
      {
         return _integrate(f_grid, q, true, verbose);
      }

      ///@}

      /// \name Integration calls for vectors of discretized functions
      ///@{

      vector_d int_J_nu(const std::vector<grid_vector>& f_grids, double q)
      {
         return _integrate(f_grids, q, false);
      }

      vector_d weighted_int_J_nu(const std::vector<grid_vector>& f_grids,
                                 double q)
      {
         return _integrate(f_grids, q, true);
      }
      ///@}

      /// \name Integration weights
      ///@{

      grid_vector weights_J_nu(double q, bool weighted = false);
      ///@}

      /// \name Function discretization
      ///@{

      template <typename... Args>
      grid_vector discretize(std::function<double(double, Args...)>& funct,
                             Args... arguments) const;
      ///@}

      /// \name Accessors
      ///@{

      /**
       * \brief    Returns the interpolation grid.
       * \returns  The interpolation grid object, which is an instance of a
       *           class derived from Grid_1d.
       */
      const auto& grid() const            { return _integrator.grid(); }

      double nu() const                   { return _nu; }

      const grid_vector& z_values() const { return _integrator.z_values(); }

      double current_q() const            { return _integrator.current_q(); }

      /// Returns the internal Bessel integrator
      const Bessel_integrator_impl& basic_integrator() const
      {
         return _integrator;
      }
      ///@}

      /// \name Information about the integration method
      ///@{

      void print_info(double q) { _integrator.print_info(q); }
      ///@}

   private:
      double _nu;

      Bessel_integrator_impl _integrator;

      // weights [z/(1+z)]^nu
      grid_vector _weights_nu;

      // matrices that discretize operator M in f_1 = M * f
      // (one per subgrid)
      std::vector<grid_matrix> _M_matrices;

      void _check_fgrid(const grid_vector& f_grid) const;

      double _integrate(const grid_vector& f_grid, double q,
                        bool weighted, int verbose);
      vector_d _integrate(const std::vector<grid_vector>& f_grids, double q,
                          bool weighted);

      // Compute F_vec for the function f1 to be integrated with J_{nu+2}.
      std::vector<grid_vector> _make_F_vec(const grid_vector& f_grid,
                                           bool weighted) const;

      std::vector<grid_vector> _make_F_basis_vec(index_t grid_point,
                                                 bool weighted) const;

      void _make_M_matrices();

      // auxiliary functions
      double _D1_coeff(double z) const;
      double _D0_coeff(double z) const;
};

//------------------------------------------------------------------------------
// Member function definition
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
template <typename... Args>
grid_vector Bessel_integrator_special_impl::discretize(
   std::function<double(double, Args...)>& funct, Args... arguments) const
{
   grid_vector result(z_values().size());

   for (index_t i = 0; i < z_values().size(); ++i) {
      result[i] = funct(z_values()[i], arguments...);
   }

   return result;
}

} // namespace bestlime

#endif //BESTLIME_BESSEL_INTEGRATOR_SPECIAL_IMPL_HPP
