//------------------------------------------------------------------------------
/// \file timing.cpp
/// \brief Code example: Timing the integration calls of Bessel_integrator.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/config.hpp"

#include <chrono>
#include <iostream>
#include <iomanip>

// set 'verbose' to 'true' for detailed info on integration method used
constexpr bool verbose = false;

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

//------------------------------------------------------------------------------
namespace timing
{

using clock = std::chrono::high_resolution_clock;
using time_point = std::chrono::time_point<clock>;

inline time_point now() { return clock::now(); }

// values for template parameter `time_unit`
using nanoseconds  = std::chrono::nanoseconds;
using microseconds = std::chrono::microseconds;
using milliseconds = std::chrono::milliseconds;

// returns `(stop - start) / cycles` in units of `time_unit`
template <typename time_unit>
double runtime(const time_point& start, const time_point& stop,
               size_t cycles = 1)
{
   auto duration = std::chrono::duration_cast<time_unit>(stop - start);
   return static_cast<double>(duration.count()) / static_cast<double>(cycles);
}

} // timing

//------------------------------------------------------------------------------
// functions for the integrand
std::function<double(double)> test_func = [](double z) {
   if (z == 0. || z == Grid_1d::infinity)
      return 0.;
   else
      return z * exp(-z);
};

//------------------------------------------------------------------------------
// time integration calls with and without update of q
//------------------------------------------------------------------------------
template<class Grid_type>
void time_calls(
   Bessel_integrator<Grid_type>& integrator, double q_max)
{
   using namespace timing;

   const grid_vector f_values {integrator.discretize(test_func)};

   // make sure that condition number of matrices does not change too much
   // between q_min and q_max as this affects timing of q update
   constexpr double q_factor = 0.95;
   const double q_min = q_factor * q_max;

   cout << "   " << q_min << " < q < " << q_max << endl;

   if (verbose) {
      cout << endl;
      integrator.print_info(q_min);
      integrator.print_info(q_max);
      cout << endl;
   }

   cout << " timing of integration calls (single function):" << endl;

   {
      constexpr size_t cycles {2000};

      double q = q_min;
      // warm-up
      for (size_t i = 0; i < cycles; ++i)
      {
         q += (q_max - q_min) / static_cast<double>(cycles);
         integrator.int_J_nu_minus_1(f_values, q);
      }

      // measurement
      q = q_min;

      auto start = now();
      for (size_t i = 0; i < cycles; ++i) {
         q += (q_max - q_min) / static_cast<double>(cycles);
         integrator.int_J_nu_minus_1(f_values, q);
      }
      auto stop = now();

      cout << "   int_J_nu_minus_1() with q update: " << std::setw(7)
           << runtime<microseconds>(start, stop, cycles)
           << " microseconds" << endl;
   }

   double time_nu_m_1_ref;
   double time_nu_ref;

   {
      constexpr size_t cycles {300'000};
      const double q = q_max;

      // Warm-up.
      for (size_t i = 0; i < cycles; ++i) {
         integrator.int_J_nu_minus_1(f_values, q);
      }

      // Measurement.
      auto start = now();
      for (size_t i = 0; i < cycles; ++i) {
         integrator.int_J_nu_minus_1(f_values, q);
      }
      auto stop = now();

      time_nu_m_1_ref = runtime<microseconds>(start, stop, cycles);
      cout << "   int_J_nu_minus_1() w/o  q update: " << std::setw(7)
           << time_nu_m_1_ref << " microseconds" << endl;


      // Warm-up.
      for (size_t i = 0; i < cycles; ++i) {
         integrator.int_J_nu(f_values, q);
      }

      // Measurement.
      start = now();
      for (size_t i = 0; i < cycles; ++i) {
         integrator.int_J_nu(f_values, q);
      }
      stop = now();

      time_nu_ref = runtime<microseconds>(start, stop, cycles);
      cout << "   int_J_nu()         w/o  q update: " << std::setw(7)
           << time_nu_ref << " microseconds"
           << "  (factor " << time_nu_ref / time_nu_m_1_ref << ")"
           << endl;
   }


   const size_t N_pts = static_cast<size_t>(integrator.z_values().size());
   const double N_pts_d = static_cast<double>(integrator.z_values().size());
   const std::vector<size_t> N_vals = {(N_pts + 1)/2, N_pts, 2000};

   for (auto N_fcts : N_vals) {
      cout << " timing of integration calls (" << N_fcts << " functions):"
         << endl;

      const std::vector<grid_vector> f_values_mult(N_fcts, f_values);
      {
         const size_t cycles {300'000 / N_fcts};
         const double q = q_max;

         // Warm-up.
         for (size_t i = 0; i < cycles; ++i) {
            integrator.int_J_nu_minus_1(f_values_mult, q);
         }

         // Measurement.
         auto start = now();
         for (size_t i = 0; i < cycles; ++i) {
            integrator.int_J_nu_minus_1(f_values_mult, q);
         }
         auto stop = now();

         const double time_nu_m_1 = runtime<microseconds>(start, stop, cycles);
         cout << "   int_J_nu_minus_1() w/o  q update: " << std::setw(7)
            << time_nu_m_1 << " microseconds" << "  (factor " << N_pts << " * "
            << time_nu_m_1 / (N_pts_d * time_nu_m_1_ref) << ")"
            << endl;


         // Warm-up.
         for (size_t i = 0; i < cycles; ++i) {
            integrator.int_J_nu(f_values_mult, q);
         }

         // Measurement.
         start = now();
         for (size_t i = 0; i < cycles; ++i) {
            integrator.int_J_nu(f_values_mult, q);
         }
         stop = now();

         const double time_nu = runtime<microseconds>(start, stop, cycles);
         cout << "   int_J_nu()         w/o  q update: " << std::setw(7)
            << time_nu << " microseconds" << "  (factor " << N_pts << " * "
            << time_nu / (N_pts_d * time_nu_ref) << ")"
            << endl;
      }

      if (verbose) {
         cout << std::string(77, '-') << endl;
      }
   } // end loop over N_fcts

   cout << endl;
}

//------------------------------------------------------------------------------
// time class initialization
//------------------------------------------------------------------------------
template<class Grid_type>
void time_init(const index_vector& n_points, const vector_d z_limits,
               const vector_d& params)
{
   using namespace timing;

   cout << " time for class initialization:";

   {
      constexpr size_t cycles {1000};

      // warm-up
      for (size_t i = 0; i < cycles; ++i)
      {
         Bessel_integrator<Grid_type> {n_points, z_limits, params};
      }

      // measurement
      auto start = now();
      for (size_t i = 0; i < cycles; ++i) {
         Bessel_integrator<Grid_type> {n_points, z_limits, params};
      }
      auto stop = now();

      cout << std::string(9, ' ') << std::setw(7)
           << runtime<microseconds>(start, stop, cycles)
           << " microseconds" << endl;
   }
}

//------------------------------------------------------------------------------
int main(int, char**) {

   // grids for integration from 0 to infinity
   index_vector n_points_a {45};
   vector_d z_limits_a {0., Grid_1d::infinity};

   index_vector n_points_b {20, 25};
   vector_d z_limits_b {0., 1., Grid_1d::infinity};

   index_vector n_points_c {40, 50};
   vector_d z_limits_c = z_limits_b;

   const double alpha = 1.;
   const double z0 = 1.;


   cout << " Demonstration of BestLime (version " << bestlime_version
        << "): timing\n\n";

   cout << " the factor in the last column gives the timing relative to\n"
        << " - J_nu_minus_1() for single-function calls\n"
        << " - the corresponding single-function call for multi-function calls\n"
        << endl;

   cout << std::setprecision(4);

   Bessel_integrator<Inv_power_law_grid>
      int_a {n_points_a, z_limits_a, {alpha, z0}};

   cout << " *** first ";
   int_a.print_grid_info();
   cout << " ***\n\n";

   time_init<Inv_power_law_grid>(n_points_a, z_limits_a, {alpha, z0});
   cout << endl;

   cout << " using LU decomposition\n";
   const double small_q = 0.1;
   time_calls<Inv_power_law_grid>(int_a, small_q);
   cout << endl;


   Bessel_integrator<Inv_power_law_grid>
      int_b {n_points_b, z_limits_b, {alpha, z0}};

   cout << " *** second ";
   int_b.print_grid_info();
   cout << " ***\n\n";

   time_init<Inv_power_law_grid>(n_points_b, z_limits_b, {alpha, z0});
   cout << endl;

   cout << " using quadrature on first subgrid, LU decomposition on second\n";
   time_calls<Inv_power_law_grid>(int_b, small_q);

   cout << " using LU decomposition on both subgrids\n";
   const double medium_q = 15.0;
   time_calls<Inv_power_law_grid>(int_b, medium_q);
   cout << endl;


   Bessel_integrator<Inv_power_law_grid>
      int_c {n_points_c, z_limits_c, {alpha, z0}};

   cout << " *** third ";
   int_c.print_grid_info();
   cout << " ***\n\n";

   time_init<Inv_power_law_grid>(n_points_c, z_limits_c, {alpha, z0});
   cout << endl;

   cout << " using quadrature on first subgrid, LU decomposition on second\n";
   time_calls<Inv_power_law_grid>(int_c, small_q);

   cout << " using LU decomposition on both subgrids\n";
   const double large_q = 40.0;
   time_calls<Inv_power_law_grid>(int_c, large_q);

   cout << " using SV decomposition on first subgrid, LU decomposition on second\n";
   time_calls<Inv_power_law_grid>(int_c, medium_q);
} // main
/// \endcond
