//------------------------------------------------------------------------------
/// \file custom_transform.cpp
/// \brief Code example: Working with a user-provided variable transform.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/Grid_1d.hpp"
#include "bestlime/config.hpp"

#include <iostream>
#include <iomanip>
#include <stdexcept>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

//------------------------------------------------------------------------------

int main(int, char**) {

   // define functions for the integrand
   // Gaussian exp(- kappa^2 z^2) times z
   std::function<double(double, double)>
      f_gauss = [](double z, double kappa)
   {
      if (z == Grid_1d::infinity)
         return 0.;
      else {
         const double arg = kappa * z;
         return z * std::exp(- arg * arg);
      }
   };

   // int_0^infty f_gauss(z, kappa) J_0 (qz) dz
   std::function<double(double, double)>
      f_gauss_trf = [](double q, double kappa)
   {
      const double ratio = 0.5 * q / kappa;
      return ratio / (q * kappa) * std::exp(- ratio*ratio);
   };


   // class implementing the variable transform u = tanh(m z / 4)
   // NOTE: has the same value of du/dz at z = 0 as Exp_grid
   class Tanh_grid : public Grid_1d
   {
      public:
         Tanh_grid(const index_vector& n_points,
                   const vector_d& z_limits,
                   const vector_d& par)
            : Grid_1d(n_points, z_limits, par)
         {
            if (par.size() != 1)
               throw std::logic_error("Tanh_grid: wrong number of parameters.");

            _m_over_4 = 0.25 * par.at(0);
            _initialize_base_grid(n_points, z_limits);
         }

         // transform u(z)
         double variable_transform(double z) const override
         {
            if (z == Grid_1d::infinity) {
               return 1.;
            } else {
               return std::tanh(_m_over_4 * z);
            }
         }

         // inverse transform z(u)
         double inverse_transform(double u) const override
         {
            if (u == 1.) {
               return Grid_1d::infinity;
            } else {
               return std::atanh(u) / _m_over_4;
            }
         }

         // Jacobian du/dz as a function of u.
         double jacobian(double u) const override
         {
            return _m_over_4 * (1. - u*u);
         }

         // Hessian d^2u/dz^2 as a function of u.
         double hessian(double u) const override
         {
            return -2. *_m_over_4 * _m_over_4 * u * (1. - u*u);
         }

      private:
         double _m_over_4;
   };

   // quantities defining the interpolation grid
   const index_vector n_points {20, 20};
   const double z1 = 2.0;
   const vector_d z_limits {0., z1, Grid_1d::infinity};

   // grid transformation parameter
   const double m_exp = 3.0;
   const double m_tanh = 0.5 * m_exp;

   // Bessel integrator with exponential grid
   Bessel_integrator<Exp_grid> bessel_int_exp(n_points, z_limits, {m_exp});

   // Bessel integrator with custom grid
   Bessel_integrator<Tanh_grid> bessel_int_tanh(n_points, z_limits, {m_tanh});

   // parameters of the integrand
   const double kappa = 1.5;

   cout << " Demonstration of BestLime (version " << bestlime_version
        << "):\n"
        << " Working with a user-provided variable transform\n\n";

   cout << " Compare grid transforms\n"
        << "    u = - exp(- m z/4) with m = "
        << bessel_int_exp.grid_params().at(0) << endl
        << "    u = tanh(m z/4)    with m = "
        << bessel_int_tanh.grid_params().at(0)
        << endl << endl;

   cout << " ";
   bessel_int_tanh.print_grid_info();
   cout << endl << endl;

   cout << " Relative accuracy of  int_0^infty dz J_0(q z) f(z)\n"
        << " with f(z) = z exp(- kappa^2 z^2) for kappa = " << kappa << endl
        << endl;

   cout << setw(28) << " " << "---- rel. accuracy ----\n";

   cout << setw(5) << "q" << "   "
        << setw(13) << "integral" << "  "
        << setw(13) << "exp grid" << "   "
        << setw(13) << "tanh grid\n";

   cout << std::setprecision(3);

   // discretize integrand on the different grids
   // note: template argument of of discretize() is deduced
   const grid_vector f_values_exp {bessel_int_exp.discretize(f_gauss, kappa)};
   const grid_vector f_values_tanh {bessel_int_tanh.discretize(f_gauss, kappa)};

   const vector_d q_values {0.01, 0.1, 1., 2., 5., 10.};

   for (const double& q : q_values) {
      const double int_exp = bessel_int_exp.int_J_nu_minus_1(f_values_exp, q);
      const double int_tanh = bessel_int_tanh.int_J_nu_minus_1(f_values_tanh, q);

      const double rel_acc_exp = std::abs(int_exp / f_gauss_trf(q, kappa) - 1.);
      const double rel_acc_tanh = std::abs(int_tanh / f_gauss_trf(q, kappa) - 1.);

      cout << setw(5) << q << "   "
           << setw(13) << f_gauss_trf(q, kappa) << "  "
           << setw(13) << rel_acc_exp << "  "
           << setw(13) << rel_acc_tanh << endl;
   }

   cout << endl;
} // main
/// \endcond
