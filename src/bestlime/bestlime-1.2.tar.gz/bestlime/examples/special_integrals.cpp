//------------------------------------------------------------------------------
/// \file special_integrals.cpp
/// \brief Code example: Use of the class Bessel_integrator_special.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator_special.hpp"
#include "bestlime/config.hpp"

#include <iostream>
#include <iomanip>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

using std::log;
using std::pow;


// Constants used in the computation of Hankel transforms of log^k(z^2).
static constexpr double b0      = 1.1229189671337703;
static constexpr double zeta3   = 1.2020569031595943;
static constexpr double zeta5   = 1.0369277551433699;
static constexpr double zeta7   = 1.0083492773819228;

//------------------------------------------------------------------------------
double factorial(int n)
{
   if (n < 0)
      throw std::invalid_argument("factorial(): n must be larger or equal 0.");

   if (n == 0)
      return 1;
   else
      return n * factorial(n-1);
}

//------------------------------------------------------------------------------
// Binomial coefficient.
double binomial_coeff(int n, int k)
{
   if (n < k)
      throw std::invalid_argument("binomial_coeff(): n cannot be smaller than k.");
   if (n < 0 || k < 0)
      throw std::invalid_argument("binomial_coeff(): n and k must be positive.");

   return factorial(n) / (factorial(n-k) * factorial(k));
}

//------------------------------------------------------------------------------
// z log^k (z^2 Q^2 / b0^2)
std::function<double(double, int, double)>  z_log_k_z2
   = [](double z, int k, double Q)
{
   // NOTE: value at Grid_1d::infinity is ignored by integrator
   return (z == 0. || z == Grid_1d::infinity) ?
      0.0 : z * pow(2. * log(z*Q/b0), k);
};

//------------------------------------------------------------------------------
/* int_0^inf dz J_0(q z) z_log_k_z2 for 1 <= k <= 8.
 * For reference see Appendix C in:
 * M. Ebert and F. Tackmann, arXiv:1611.08610
 */
double z_log_transform(double q, int k, double Q)
{
   if (k > 8)
      throw std::invalid_argument("z_log_transform(): k > 8 not implemented.");

   const vector_d R_2 {1., 0., 0., -4.*zeta3,
                       0., -48.*zeta5, 160.*zeta3*zeta3, -1440.*zeta7};

   double result = 0.;

   for (int j = 0; j < k; j++) {
      double term_j = std::pow(2.* log(q/Q), j);
      term_j *= 2. / (q*q);
      term_j *= k * binomial_coeff(k - 1, j);
      term_j *= R_2[static_cast<size_t>(k - j - 1)];

      if (j%2 == 0)
         term_j *= -1.;

      result += term_j;
   }

   return result;
}

//------------------------------------------------------------------------------
// Precision test for the z log^k (z^2 Q^2 / b0^2) integrands.
void test_log_trf(const std::vector<int> k_vals, const vector_d& q_vals,
                  Bessel_integrator_special<Log_pow_grid>& integrator,
                  const double Q)
{
   // Discretize the integrand.
   std::vector<grid_vector> f_grids;
   for (auto&& k : k_vals) {
      f_grids.push_back(integrator.template discretize(z_log_k_z2, k, Q));
   }

   // Table header.
   cout << " Relative accuracy of "
        << " int_0^inf dz  J_0(q z) z log^k (z^2 Q^2 / b0^2)\n"
        << " Q = " << Q
        << ", call: int_J_nu()\n ";
   integrator.print_grid_info();
   cout << endl << endl;

   cout << setw(6) << "q";
   for (auto&& k : k_vals) {
      cout << setw(15) << "k = " << k;
   }
   cout << endl;

   // Compute the result and print the error for each k.
   for (auto&& q : q_vals) {
      cout << setw(6) << q;

      for (size_t i = 0; i < k_vals.size(); i++) {
         const int k = k_vals[i];

         // Numerical integration.
         const double result = integrator.int_J_nu(f_grids[i], q);

         // Exact result.
         const double result_ex = z_log_transform(q, k, Q);

         cout << std::scientific << std::setprecision(3)
              << setw(16) << std::abs(1. - result/result_ex)
              << std::defaultfloat;
      }
      cout << endl;
   }
   cout << endl;
}

//------------------------------------------------------------------------------
int main()
{

   cout << " Demonstration of BestLime (version " << bestlime_version
        << "): formally divergent integrals\n\n";

   cout << " For details see section 6 of"
        << " M. Diehl and O. Grocholski, arXiv:2405.08616.\n"
        << " Implementation changes in version 1.2"
        << " have led to a different choice of\n"
        << " interpolation grids compared with that reference.\n\n";

   const double Q = 100.;

   // Values of q.
   const vector_d q_values {1e-2, 0.1, 1., 5., 10., 50., 90.};

   // Grid settings for logarithmic integrands
   // for 1 <= k <= 4
   const index_vector npts_1 {16, 32};
   const vector_d z_points_1 {0., 0.1, Grid_1d::infinity};
   const vector_d grid_params_1 {0.25, 1e-7, 0.1};

   // for 5 <= k <= 8
   const index_vector npts_2 {32, 48};
   const vector_d z_points_2 {0., 1e-3, Grid_1d::infinity};
   const vector_d grid_params_2 {0.15, 1e-9, 0.1};

   // Initialize special Bessel integrators and test integration call
   double nu = 0.;
   Bessel_integrator_special<Log_pow_grid>
      bessel_k4(npts_1, z_points_1, grid_params_1, nu);
   test_log_trf({1, 2, 3, 4}, q_values, bessel_k4, Q);

   Bessel_integrator_special<Log_pow_grid>
      bessel_k8(npts_2, z_points_2, grid_params_2, nu);
   test_log_trf({5, 6, 7, 8}, q_values, bessel_k8, Q);

   //---------------------------------------------------------------------------
   // Test int dz J_1(q z) (1+z)^2 / z
   // using weighted integration call with f(z) = (1+z)

   // NOTE: value at Grid_1d::infinity is ignored by integrator
   std::function<double(double)> fct = [](double z) {
      return (z == Grid_1d::infinity) ? 0.0 : (1. + z);
   };

   const index_vector npts_3 {20, 25};
   const vector_d z_points_3 {0., 1., Grid_1d::infinity};
   const vector_d grid_params_3 {0.5, 1.};  // {p, z_0}

   nu = 1.;
   Bessel_integrator_special<Inv_power_law_grid>
      bessel_nu1(npts_3, z_points_3, grid_params_3, nu);

   // Discretize integrand
   const grid_vector f_grid {bessel_nu1.discretize(fct)};

   // Table header.
   cout << " Relative accuracy of "
        << " int_0^inf dz  J_1(q z) (1+z)^2 / z\n"
        << " call: weighted_int_J_nu()\n ";
   bessel_nu1.print_grid_info();
   cout << endl << endl;

   for (auto&& q : q_values) {
      cout << setw(6) << std::defaultfloat << q;

      // Numerical integration
      const double result = bessel_nu1.weighted_int_J_nu(f_grid, q);

      // Exact result is (1+q)^2 / q^2
      double result_ex = (1.+ q) / q;
      result_ex *= result_ex;

      cout << std::scientific << std::setprecision(3)
            << setw(16) << std::abs(1. - result/result_ex);
      cout << endl;
   }
   cout << endl;

   return 0;
} // int main()
/// \endcond
