//------------------------------------------------------------------------------
/// \file benchmarks.cpp
/// \brief Code example: Benchmark the integration precision
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/Vector_types.hpp"
#include "bestlime/config.hpp"

#include <gsl/gsl_sf_bessel.h>
#include <gsl/gsl_sf_hyperg.h>
#include <gsl/gsl_errno.h>

#include <iostream>
#include <iomanip>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

using funct_t = std::function<double(double, double, const vector_d&)>;

//------------------------------------------------------------------------------
inline void update_error(double& error_var, double new_error)
{
   if (new_error > error_var)
      error_var = new_error;
}

//------------------------------------------------------------------------------
// determines the largest relative error of 'int dz func(z, nu) J_nu(q z)'
// for a range of nu and q values
//------------------------------------------------------------------------------
template<class Grid_type>
double max_error(
   funct_t& func, const funct_t& result, const vector_d& func_params,
   const index_vector& n_points, const vector_d& z_limits,
   const vector_d& grid_params,
   const vector_d& nu_values, const vector_d& q_values)
{
   double max_err = 0.;

   for (double nu : nu_values) {
      // integrator with argument nu+1, integration call with nu-1
      // => integral with J_nu
      Bessel_integrator<Grid_type>
         bes_nu_p1 {n_points, z_limits, grid_params, nu + 1.};

      // specify template parameters here,
      // since template argument deduction does not work for last argument
      const grid_vector f_values {bes_nu_p1.template discretize<double,
         const vector_d&>(func, nu, func_params)};

      if (nu <= 2.) {
         for (double q : q_values) {
            const double int_nu_m1 = bes_nu_p1.int_J_nu_minus_1(f_values, q);
            const double err_nu_m1
               = std::abs(int_nu_m1 / result(q, nu, func_params) - 1.);

            update_error(max_err, err_nu_m1);
         }
      }

      if (nu >= 1.) {
         Bessel_integrator<Grid_type>
            bes_nu {n_points, z_limits, grid_params, nu};

         for (double q : q_values) {
            const double int_nu = bes_nu.int_J_nu(f_values, q);
            const double err_nu
               = std::abs(int_nu / result(q, nu, func_params) - 1.);

            update_error(max_err, err_nu);
         }
      }

      if (nu >= 2.) {
         Bessel_integrator<Grid_type>
            bes_nu_m1 {n_points, z_limits, grid_params, nu - 1.};

         for (double q : q_values) {
            const double int_nu_p1 = bes_nu_m1.int_J_nu_plus_1(f_values, q);
            const double err_nu_p1
               = std::abs(int_nu_p1 / result(q, nu, func_params) - 1.);

            update_error(max_err, err_nu_p1);
         }
      }
   }

   return max_err;
}

//------------------------------------------------------------------------------
// int_0^infty dz  z^(-nu) J_nu(qz)
double int_inv_pow_nu(double q, double nu)
{
   return 0.5 * std::pow(0.5 * q, nu - 1.)
      * std::tgamma(0.5) / std::tgamma(0.5 + nu);
}

// int_0^zb dz  z^(-nu + 1) J_nu(qz)
double int_inv_pow_nu_m1(double q, double nu, double zb)
{
   double result = 0.5 * std::pow(0.5 * q, nu - 2.) / std::tgamma(nu);

   if (zb == Grid_1d::infinity) {
      return result;
   } else {
      return result
         - std::pow(zb, 1. - nu) * gsl_sf_bessel_Jnu(nu - 1., q * zb) / q;
   }
}

//------------------------------------------------------------------------------
// Determines the largest relative error of int dz z^(-nu) J_nu(q z)'
// for a range of nu and q values
//------------------------------------------------------------------------------
template<class Grid_type>
double max_error_inv_pow_nu(
   const index_vector& n_points, const vector_d& z_limits,
   const vector_d& grid_params,
   const vector_d& nu_values, const vector_d& q_values)
{
   double max_err = 0.;

   for (double nu : nu_values) {
      if (nu == 0.)
         continue;

      // integrator with argument nu+1, integration call with nu-1
      // => integral with J_nu
      Bessel_integrator<Grid_type>
         bes_nu_p1 {n_points, z_limits, grid_params, nu + 1.};

      const grid_vector z_values {bes_nu_p1.z_values()};

      // integrand function (1+z)^(-nu) to be weighted with [(1+z)/z]^(nu)
      // => integrand z^(-nu) J_nu(q z)
      grid_vector f_values(z_values.size());
      for (index_t i = 0; i < z_values.size(); ++i) {
         const double z = z_values[i];
         f_values[i] = std::pow(1. + z, - nu);
      }

      if (nu <= 2.) {
         for (double q : q_values) {
            const double int_nu_m1
               = bes_nu_p1.weighted_int_J_nu_minus_1(f_values, q);
            const double err_nu_m1
               = std::abs(int_nu_m1 / int_inv_pow_nu(q, nu) - 1.);

            update_error(max_err, err_nu_m1);
         }
      }

      if (nu >= 1.) {
         Bessel_integrator<Grid_type>
            bes_nu {n_points, z_limits, grid_params, nu};

         for (double q : q_values) {
            const double int_nu = bes_nu.weighted_int_J_nu(f_values, q);
            const double err_nu
               = std::abs(int_nu / int_inv_pow_nu(q, nu) - 1.);

            update_error(max_err, err_nu);
         }
      }
   } // loop over nu_values

   return max_err;
}

//------------------------------------------------------------------------------
// Determines the largest relative error of int dz z^(-nu+1) J_nu(q z)'
// for a range of nu and q values
//------------------------------------------------------------------------------
template<class Grid_type>
double max_error_inv_pow_nu_m1(
   const index_vector& n_points, const vector_d& z_limits,
   const vector_d& grid_params,
   const vector_d& nu_values, const vector_d& q_values)
{
   double max_err = 0.;

   const double zb = z_limits.back();

   for (double nu : nu_values) {
      if ((zb == Grid_1d::infinity) && (nu < 1.))
         continue;

      // integrator with argument nu+1, integration call with nu-1
      // => integral with J_nu
      Bessel_integrator<Grid_type>
         bes_nu_p1 {n_points, z_limits, grid_params, nu + 1.};

      const grid_vector z_values {bes_nu_p1.z_values()};

      // integrand function z * (1+z)^(-nu) to be weighted with [(1+z)/z]^(nu)
      // => integrand z^(-nu+1) J_nu(q z)
      grid_vector f_values(z_values.size());
      for (index_t i = 0; i < z_values.size(); ++i) {
         const double z = z_values[i];
         f_values[i] = z * std::pow(1. + z, - nu);
      }

      if (nu <= 2.) {
         for (double q : q_values) {
            const double int_nu_m1
               = bes_nu_p1.weighted_int_J_nu_minus_1(f_values, q);
            const double err_nu_m1
               = std::abs(int_nu_m1 / int_inv_pow_nu_m1(q, nu, zb) - 1.);

            update_error(max_err, err_nu_m1);
         }
      }

      if (nu >= 1.) {
         Bessel_integrator<Grid_type>
            bes_nu {n_points, z_limits, grid_params, nu};

         for (double q : q_values) {
            const double int_nu
               = bes_nu.weighted_int_J_nu(f_values, q);
            const double err_nu
               = std::abs(int_nu / int_inv_pow_nu_m1(q, nu, zb) - 1.);

            update_error(max_err, err_nu);
         }
      }

      // integrand function (1+z)^(-nu+1) to be weighted with [(1+z)/z]^(nu-1)
      // => same integrand z^(-nu+1) J_nu(q z)
      for (index_t i = 0; i < z_values.size(); ++i) {
         const double z = z_values[i];
         f_values[i] = std::pow(1. + z, - nu + 1.);
      }

      if (nu >= 2.) {
         Bessel_integrator<Grid_type>
            bes_nu_m1 {n_points, z_limits, grid_params, nu - 1.};

         for (double q : q_values) {
            const double int_nu_p1
               = bes_nu_m1.weighted_int_J_nu_plus_1(f_values, q);
            const double err_nu_p1
               = std::abs(int_nu_p1 / int_inv_pow_nu_m1(q, nu, zb) - 1.);

            update_error(max_err, err_nu_p1);
         }
      }
   } // loop over nu_values

   return max_err;
}

//------------------------------------------------------------------------------
double Gauss2F1(double a, double b, double c, double x)
{
   // make sure that GSL errors do not terminate the program
   gsl_set_error_handler_off();

   if (x >= 1.) {
      throw std::invalid_argument("Gauss2F1(): Last argument must be < 1.");
   }
   else if (x >= 0.) {
      return gsl_sf_hyperg_2F1(a, b, c, x);
   }
   else {
      const double var = (x > -10.) ? x / (x - 1.) : 1. -  1./(1. - x );

      if (a >= b) {
         return gsl_sf_hyperg_2F1(b, c - a, c, var) * pow((1. - x ), -b);
      }
      else {
         return gsl_sf_hyperg_2F1(a, c - b, c, var) * pow((1. - x ), -a);
      }
   }

   // restore the default GSL error handler
   gsl_set_error_handler(NULL);
}

//------------------------------------------------------------------------------
inline double pow_2(double x)
{
   return x*x;
}

//------------------------------------------------------------------------------
// Function objects for integrands and integrals
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// z^mu exp(- kappa z)
funct_t f_exp = [](double z, double, const vector_d& par)
{
   const double kappa = par.at(0);
   const double mu = par.at(1);

   if (z == Grid_1d::infinity)
      return 0.;

   return std::pow(z, mu) * std::exp(- z * kappa);
};

// int_0^infty dz  f_exp(z) J_nu(qz)
funct_t int_exp = [](double q, double nu, const vector_d& par)
{
   const double kappa = par.at(0);
   const double mu = par.at(1);

   const double sum = mu + nu + 1.;

   double result = Gauss2F1(0.5 * sum, 0.5 * sum + 0.5, 1. + nu,
                            - pow_2(q / kappa));
   result *= std::pow(0.5 * q, nu) * std::pow(kappa, - sum);
   result *= std::tgamma(sum) / std::tgamma(nu + 1.);

   return result;
};

// z^{mu + nu + 1} K_mu(kappa z)
funct_t f_K = [](double z, double nu, const vector_d& par)
{
   if (z == Grid_1d::infinity || z == 0.0)
      return 0.;

   const double kappa = par.at(0);
   const double mu = par.at(1);

   return std::pow(z, mu + nu + 1.) * gsl_sf_bessel_Knu(mu, kappa * z);
};

// int_0^inf dz  f_K(z) J_nu(qz)  for mu => 0
funct_t int_K = [](double q, double nu, const vector_d& par)
{
   const double kappa = par.at(0);
   const double mu = par.at(1);

   const double sum = mu + nu + 1.;

   return std::pow(2.*kappa, mu) * std::pow(2.*q, nu)
      / std::pow(kappa*kappa + q*q, sum) * std::tgamma(sum);
};

// Gaussian exp(- lambda^2 z^2)
funct_t f_gauss = [](double z, double, const vector_d& par)
{
   if (z == Grid_1d::infinity)
      return 0.;

   const double lambda = par.at(0);
   return exp(- pow_2(lambda * z));
};

// int_0^infty dz f_gauss(z) J_nu(qz)
// for large q behaves like 1/q
funct_t int_gauss = [](double q, double nu, const vector_d& par)
{
   constexpr double pi = 3.14159265358979323844;

   const double lambda = par.at(0);
   const double ratio = 0.125 * pow_2(q / lambda);

   // gsl_sf_bessel_Inu_scaled(nu, x) = exp(-x) * I_nu(x)
   return std::sqrt(pi) / (2.*lambda)
            * gsl_sf_bessel_Inu_scaled(0.5 * nu, ratio);
};

// Gaussian multiplied by the power z^(1 + nu)
funct_t f_gauss_pow = [](double z, double nu, const vector_d& par)
{
   if (z == Grid_1d::infinity)
      return 0.;

   const double lambda = par.at(0);
   return exp(- pow_2(lambda * z)) * std::pow(z, nu + 1.);
};

// int_0^infty dz  f_gauss_pow(z) J_nu(qz)
funct_t int_gauss_pow = [](double q, double nu, const vector_d& par)
{
   const double lambda = par.at(0);
   const double ratio = 0.5 * q / lambda;
   return exp(- pow_2(ratio)) * std::pow(ratio / lambda, nu + 1.) / q;
};

// z^{nu + 1} / (z^2 + b^2))^{mu + nu + 1}
funct_t f_K_inv = [](double z, double nu, const vector_d& par)
{
   if (z == Grid_1d::infinity)
      return 0.;

   const double b = par.at(0);
   const double mu = par.at(1);

   return std::pow(z, nu + 1.) / std::pow(z*z + b*b, mu + nu + 1.);
};

// int_0^inf dz  f_K_inv(z) J_nu(qz)  for mu => 0
funct_t int_K_inv = [](double q, double nu, const vector_d& par)
{
   const double b = par.at(0);
   const double mu = par.at(1);

   return std::pow(0.5 * q, mu + nu) / std::pow(b, mu)
      * gsl_sf_bessel_Knu(mu, q * b) / std::tgamma(mu + nu + 1.);
};

// unit function
funct_t f_unit = [](double, double, vector_d)
{
   return 1.;
};

// int_0^inf dz  J_nu(qz)
funct_t int_unit = [](double q, double, vector_d)
{
   return 1. / q;
};

// power law z^(nu + 1)
funct_t f_pow_nu_p1 = [](double z, double nu, vector_d)
{
   return std::pow(z, nu + 1.);
};

// int_0^zb dz  pow_nu_p1(z) J_nu(qz)
funct_t int_pow_nu_p1 = [](double q, double nu, const vector_d& par)
{
   const double zb = par.at(0);

   return std::pow(zb, nu + 1.)
      * gsl_sf_bessel_Jnu(nu + 1., q * zb) / q;
};

//------------------------------------------------------------------------------

int main(int, char**) {
   using std::scientific;
   using std::defaultfloat;

   // grids for integration from 0 to infinity
   index_vector n_points_a {20, 25};
   vector_d z_limits_a {0., 1., Grid_1d::infinity};

   index_vector n_points_b {45};
   vector_d z_limits_b {0., Grid_1d::infinity};

   index_vector n_points_c {30, 44};
   vector_d z_limits_c = z_limits_a;

   std::vector<index_vector> n_pts_options {n_points_a, n_points_b, n_points_c};
   std::vector<vector_d> z_lim_options {z_limits_a, z_limits_b, z_limits_c};


   const vector_d nu_values {0., 0.5, 1., 1.5, 2., 2.5, 3.};

   const vector_d nu_values_lo {0., 0.5, 1., 1.5, 2., 2.5};

   // omit nu = 0.5 for certain integrals
   const vector_d nu_values_omit {0., 1., 1.5, 2., 2.5, 3.};

   // for functions whose Bessel transform decreases strongly with q
   const vector_d q_values_lo {0.01, 0.1, 1., 2., 3., 5., 10.};

   const vector_d q_values_hi {0.01, 0.1, 1., 2., 3., 5., 10.,
                               15., 20., 25., 30.};


   cout << " Demonstration of BestLime (version " << bestlime_version
        << "): benchmark precision\n\n";

   cout << " This program computes the benchmarks reported in section 4.2 of\n"
        << "    M. Diehl and O. Grocholski\n"
        << "    Efficient computation of Fourier-Bessel transforms\n"
        << "    for transverse-momentum dependent parton distributions\n"
        << "    and other functions\n"
        << "    arXiv:2405.08616 [hep-ph]\n\n";

   cout << std::setprecision(2);

   for (size_t opt = 0; opt < n_pts_options.size(); ++opt) {
      const index_vector n_points = n_pts_options[opt];
      const vector_d z_limits = z_lim_options[opt];

      Bessel_integrator<Linear_grid> dummy_int {n_points, z_limits, {}};
      cout << " ";
      dummy_int.print_grid_info();
      cout << endl;

      // determine largest error for different functions
      cout << setw(35) << "function" << setw(15) << "rel.acc." << endl;
      double max_err = 0.;

      const double kappa = 1.5;
      double mu = 1.0;
      double m = 1.0 * kappa;
      double new_err =  max_error<Exp_sqrt_grid>(f_K, int_K, {kappa, mu},
                                                 n_points, z_limits, {m},
                                                 nu_values_lo, q_values_hi);
      cout << setw(35) << "z^(mu+nu+1) K_mu(kappa z)"
         << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      mu = 2.5;
      m = 1.5 * kappa;
      new_err =  max_error<Exp_sqrt_grid>(f_exp, int_exp, {kappa, mu},
                                          n_points, z_limits, {m},
                                          nu_values, q_values_hi);
      cout << setw(35) << "z^mu exp(-kappa z)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      const double lambda = 2.;
      m = 4.*lambda;
      new_err =  max_error<Exp_grid>(f_gauss, int_gauss, {lambda},
                                     n_points, z_limits, {m},
                                     nu_values_omit, q_values_hi);
      cout << setw(35) << "exp(-lambda^2 z^2)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      // with same parameters
      new_err =  max_error<Exp_grid>(f_gauss_pow, int_gauss_pow, {lambda},
                                     n_points, z_limits, {m},
                                     nu_values, q_values_lo);
      cout << setw(35) << "z^(1+nu) exp(-lambda^2 z^2)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      const double b = 1.2;
      mu = 2.5;
      double alpha = 1.0;
      const double z0 = 1.0;
      new_err = max_error<Inv_power_law_grid>(f_K_inv, int_K_inv, {b, mu},
                                              n_points, z_limits, {alpha, z0},
                                              nu_values, q_values_lo);
      cout << setw(35) << "z^(1+nu) / (b^2 + z^2)^(1+nu+mu)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      mu = 0.;
      alpha = 0.5;
      new_err = max_error<Inv_power_law_grid>(f_K_inv, int_K_inv, {b, mu},
                                              n_points, z_limits, {alpha, z0},
                                              nu_values, q_values_lo);
      cout << setw(35) << "[z / (b^2 + z^2)]^(1+nu)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      new_err = max_error<Inv_power_law_grid>(f_unit, int_unit, {},
                                              n_points, z_limits, {alpha, z0},
                                              nu_values_omit, q_values_hi);
      cout << setw(35) << "1"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      new_err = max_error_inv_pow_nu<Inv_power_law_grid>(
                  n_points, z_limits, {alpha, z0},
                  nu_values, q_values_hi);
      cout << setw(35) << "z^(-nu)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      new_err = max_error_inv_pow_nu_m1<Inv_power_law_grid>(
                  n_points, z_limits, {alpha, z0},
                  nu_values, q_values_hi);
      cout << setw(35) << "z^(-nu+1)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      cout << setw(35) << "largest relative error"
           << scientific << setw(15) << max_err << defaultfloat << endl
           << endl;
   } // end loop over grid options
   cout << endl;


   // special setting of fine grid for one function
   z_lim_options.at(2).at(1) = 0.1;

   for (size_t opt = 0; opt < n_pts_options.size(); ++opt) {
      const index_vector n_points = n_pts_options[opt];
      const vector_d z_limits = z_lim_options[opt];

      Bessel_integrator<Linear_grid> dummy_int {n_points, z_limits, {}};
      cout << " ";
      dummy_int.print_grid_info();
      cout << endl;

      cout << setw(35) << "function" << setw(15) << "rel.acc." << endl;

      const double kappa = 1.5;
      const double mu = 0.0;
      const double m = 1.5 * kappa;
      double new_err =  max_error<Exp_sqrt_grid>(f_K, int_K, {kappa, mu},
                                                 n_points, z_limits, {m},
                                                 nu_values_lo, q_values_hi);
      cout << setw(35) << "z^(nu+1) K_0(kappa z)"
           << scientific << setw(15) << new_err << defaultfloat << endl
           << endl;
   } // end loop over grid options
   cout << endl;


   // integration over a finite range
   const double zb = 10.;

   n_points_a = {24};
   z_limits_a = {0., zb};

   n_points_b = {34};
   z_limits_b = z_limits_a;

   n_pts_options = {n_points_a, n_points_b};
   z_lim_options = {z_limits_a, z_limits_b};

   const vector_d q_values_max {0.01, 0.1, 1., 2., 3., 5., 10.,
                                15., 20., 25., 30.,
                                0.001, 50., 100., 200., 300.};

   for (size_t opt = 0; opt < n_pts_options.size(); ++opt) {
      const index_vector n_points = n_pts_options[opt];
      const vector_d z_limits = z_lim_options[opt];

      Bessel_integrator<Linear_grid> dummy_int {n_points, z_limits, {}};
      cout << " ";
      dummy_int.print_grid_info();
      cout << endl;

      cout << setw(35) << "function" << setw(15) << "rel.acc." << endl;
      double max_err = 0.;

      const double alpha = 0.5;
      const double z0 = 1.0;

      double new_err = max_error_inv_pow_nu_m1<Inv_power_law_grid>(
                        n_points, z_limits, {alpha, z0},
                        nu_values, q_values_max);
      cout << setw(35) << "z^(-nu+1)"
           << scientific << setw(15) << new_err << defaultfloat << endl;

      new_err = max_error<Linear_grid>(f_pow_nu_p1, int_pow_nu_p1, {zb},
                                       n_points, z_limits, {},
                                       nu_values, q_values_max);
      update_error(max_err, new_err);

      cout << setw(35) << "z^(nu+1)"
           << scientific << setw(15) << new_err << defaultfloat << endl;
      update_error(max_err, new_err);

      cout << setw(35) << "largest relative error"
           << scientific << setw(15) << max_err << defaultfloat << endl
           << endl;
   } // end loop over grid options
} // main
/// \endcond
