//------------------------------------------------------------------------------
/// \file integration_weights.cpp
/// \brief Code example: Working with integration weights.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/config.hpp"

#include <gsl/gsl_sf_bessel.h>

#include <iostream>
#include <iomanip>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

using funct_t = std::function<double(double, const vector_d&)>;

//------------------------------------------------------------------------------

int main(int, char**) {

   // define function object for the integrand
   // z^{mu + 1} K_mu(kappa z)
   funct_t _f_K = [](double z, const vector_d& par)
   {
      if (z == Grid_1d::infinity || z == 0.0)
         return 0.;

      const double kappa = par.at(0);
      const double mu = par.at(1);

      return std::pow(z, mu + 1.) * gsl_sf_bessel_Knu(mu, kappa * z);
   };

   // int_0^inf dz  f_K(z) J_0(q z)  for mu => 0
   funct_t _int_K = [](double q, const vector_d& par)
   {
      const double kappa = par.at(0);
      const double mu = par.at(1);

      return std::pow(2.*kappa, mu)
         / std::pow(kappa*kappa + q*q, mu + 1.) * std::tgamma(mu + 1.);
   };

   // quantities defining the interpolation grid in z
   const index_vector n_points_z {20, 25};
   const vector_d z_limits {0., 0.05, Grid_1d::infinity};
   const double m = 2.5;

   // Bessel integrator for nu = 1
   Bessel_integrator<Exp_sqrt_grid> bessel_int(n_points_z, z_limits, {m});

   // grid for q values
   const index_vector n_points_q {10};
   const vector_d q_limits {0.1, 100.};

   Log_grid q_grid {n_points_q, q_limits, {}};

   cout << " Demonstration of BestLime (version " << bestlime_version
        << "): using integration weights\n\n";

   cout << " Compute q int_0^infty dz J_0(q z) f(z)"
        << " with f(z) = z^{mu+1} K_mu(kappa z)\n"
        << endl;

   // integration weights for one q value
   const double single_q = 150.;
   const grid_vector
      single_weights {bessel_int.weights_J_nu_minus_1(single_q)};

   // assemble integration weights for all q on `q_grid` into a matrix
   const index_t q_pts = q_grid.size();
   const index_t z_pts = bessel_int.z_values().size();
   grid_matrix int_weights(q_pts, z_pts);

   for (index_t i = 0; i < q_pts; ++i) {
      const double q = q_grid[i];
      int_weights.row(i) = q * bessel_int.weights_J_nu_minus_1(q);
   }

   // parameters for the integrand: pairs of (kappa, mu)
   const std::vector<vector_d> par_values {{1.5, 0.}, {1.8, 1.}, {1.3, 0.5}};

   cout << setw(6)  << "q"
        << setw(13) << "integral"
        << setw(13) << "rel acc"
        << endl;

   cout << std::setprecision(3);

   for (const vector_d& params : par_values) {
      cout << "\n kappa = " << params[0] << "  mu = " << params[1] << endl;

      const grid_vector f_grid
         {bessel_int.discretize<const vector_d&>(_f_K, params)};

      // compute the integrals for all q values of `q_grid`
      // as a single matrix multiplication
      const grid_vector int_values {int_weights * f_grid};

      for (index_t i = 0; i < q_pts; ++i) {
         const double q = q_grid[i];
         const double rel_acc
            = std::abs(1. - int_values[i] / (q * _int_K(q, params)));

         cout << setw(6)  << q
              << setw(13) << int_values(i)
              << setw(13) << rel_acc
              << endl;
      }

      // scalar product of the vectors `f_grid` and `single_weights`
      const double single_int = f_grid.dot(single_weights);
      const double single_rel_acc
         = std::abs(1. - single_int / _int_K(single_q, params));

      cout << setw(6)  << single_q
           << setw(13) << single_int
           << setw(13) << single_rel_acc
           << endl;
   }

   cout << endl;
} // end of main()
/// \endcond
