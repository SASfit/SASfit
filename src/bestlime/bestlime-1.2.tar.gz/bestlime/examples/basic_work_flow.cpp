//------------------------------------------------------------------------------
/// \file basic_work_flow.cpp
/// \brief Code example: Demonstrating a basic work flow.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/config.hpp"

#include <gsl/gsl_sf_hyperg.h>

#include <iostream>
#include <iomanip>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

// function is defined at end of this file
double Gauss2F1(double a, double b, double c, double x);

//------------------------------------------------------------------------------

int main(int, char**) {

   // define function object for the integrand
   std::function<double(double, double, double)>
      pow_exp = [](double z, double mu, double kappa)
   {
      if (z == Grid_1d::infinity)
         return 0.;
      else
         return std::pow(z, mu) * std::exp(- z * kappa);
   };

   // int_0^infty pow_exp(z) J_nu (qz)
   std::function<double(double, double, double, double)>
      pow_exp_trf = [](double q, double nu, double mu, double kappa)
   {
      const double sum = mu + nu + 1.;
      const double ratio = q / kappa;

      double result = Gauss2F1(0.5 * sum, 0.5 * sum + 0.5, 1. + nu,
                               - ratio*ratio);
      result *= std::pow(0.5 * q, nu) * std::pow(kappa, - sum);
      result *= std::tgamma(sum) / std::tgamma(nu + 1.);

      return result;
   };

   // quantities defining the interpolation grid
   // See Vector_types.hpp for the definitions of 'index_vector' and 'vector_d'.
   const index_vector n_points {20, 24};
   const double z1 = 0.3;
   const vector_d z_limits {0., z1, Grid_1d::infinity};

   // grid transformation parameter
   const double m = 1.2;

   // Bessel integrator for nu = 1
   Bessel_integrator<Exp_sqrt_grid> bessel_int(n_points, z_limits, {m});

   // parameters of the integrand
   const double mu = 1.07;
   const vector_d kappa_values {0.3, 0.6, 0.9};

   cout << " Demonstration of BestLime (version " << bestlime_version
        << "): a basic work flow\n\n";

   cout << " ";
   bessel_int.print_grid_info();
   cout << "\n"
        << " transformation parameter: m = " << bessel_int.grid_params().at(0)
        << endl << endl;

   cout << " Relative accuracy of  int_0^infty dz J_0(q z) f(z)\n"
        << "                  and  int_0^infty dz J_1(q z) f(z) / z\n"
        << " with f(z) = z^mu exp(-kappa z) for mu = " << mu << endl
        << endl;

   cout << setw(10) << " "
        << setw(5) << "kappa" << "   "
        << setw(13) << "rel acc J_0" << "   "
        << setw(13) << "rel acc J_1\n";

   cout << std::setprecision(3);

   // Discretize pow_exp(z, mu, kappa) for the different kappa values.
   // This uses the type 'grid_vector' introduced in Vector_types.hpp.
   // NOTE: The template argument <double, double> of discretize() is deduced.
   std::vector<grid_vector> f_values;
   for (const double& kappa : kappa_values) {
      f_values.emplace_back(bessel_int.discretize(pow_exp, mu, kappa));
   }

   // More pedestrian way to discretize a function.  For demonstration purposes
   // it uses 'vector_d' objects at the intermediate stage.
   std::vector<grid_vector> f_over_z_values;
   const vector_d z_values {convert_to_vector_d(bessel_int.z_values())};

   for (const double& kappa : kappa_values) {
      vector_d f_at_kappa;

      for (size_t i = 0; i < z_values.size(); ++i) {
         const double z = z_values.at(i);

         // use that pow_exp(z, mu, kappa) / z = pow_exp(z, mu-1, kappa)
         f_at_kappa.push_back(pow_exp(z, mu - 1. ,kappa));
      }

      f_over_z_values.push_back(convert_to_grid_vector(f_at_kappa));
   } // end loop over kappa values

   const vector_d q_values {0.01, 0.1, 1., 10., 20., 40.};

   // Computing several integrals at one q is more efficient than changing q
   // Therefore the outer loop is over q and the inner loop over kappa.
   for (const double& q : q_values) {
      cout << " q = " << q << endl;

      // compute integrals over several discretized functions
      const vector_d int_J0_vals {bessel_int.int_J_nu_minus_1(f_values, q)};

      for (size_t i = 0; i < kappa_values.size(); ++i) {
         // compute integrals over individual discretized functions
         const double int_J1_val = bessel_int.int_J_nu(f_over_z_values[i], q);

         const double kappa = kappa_values[i];
         const double rel_acc_J0
            = std::abs(int_J0_vals[i] / pow_exp_trf(q, 0., mu, kappa) - 1.);
         const double rel_acc_J1
            = std::abs(int_J1_val / pow_exp_trf(q, 1., mu - 1., kappa) - 1.);

         cout << setw(10) << " "
              << setw(5) << kappa << "   "
              << setw(13) << rel_acc_J0 << "  "
              << setw(13) << rel_acc_J1 << endl;
      }
   }

   cout << endl;
} // end of main()

//------------------------------------------------------------------------------

double Gauss2F1(double a, double b, double c, double x)
{
    if (x >= 0. && x < 1.) {
      return gsl_sf_hyperg_2F1(a, b, c, x);
    }
    else if (x < 0.)
    {
      if (a >= b) {
         return gsl_sf_hyperg_2F1(c - a, b, c, 1. - 1. / (1. - x ) ) /
            pow((1. - x ), b);
      }
      else {
         return gsl_sf_hyperg_2F1(a, c - b, c, 1. - 1. / (1. - x ) ) /
            pow((1. - x ), a);
      }
    }
    else throw std::invalid_argument("Gauss2F1(): Argument must not be larger than 1.");
}
/// \endcond
