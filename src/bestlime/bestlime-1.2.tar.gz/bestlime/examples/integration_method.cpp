//------------------------------------------------------------------------------
/// \file integration_method.cpp
/// \brief Code example: Printing details of the integration method.
//
// Author: Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------
/// \cond NO_DOXYGEN

#include "bestlime/Bessel_integrator.hpp"
#include "bestlime/config.hpp"

#include <iostream>
#include <iomanip>

using namespace bestlime;

using std::cout;
using std::endl;
using std::setw;

//------------------------------------------------------------------------------

int main(int, char**) {

   // quantities defining the interpolation grid
   const index_vector n_points {20, 16};
   const double z1 = 2.0;
   const vector_d z_limits {0., z1, Grid_1d::infinity};

   // grid transformation parameters
   double p = 0.5;
   const double z0 = 1.;

   // Bessel integrator with standard settings
   Bessel_integrator<Inv_power_law_grid> bessel_w_quad(n_points, z_limits,
                                                       {p, z0});

   // and with quadrature disabled
   const double nu = 1.;
   Bessel_integrator<Inv_power_law_grid> bessel_no_quad(n_points, z_limits,
                                                        {p, z0}, nu, false);

   cout << " Demonstration of BestLime (version " << bestlime_version
        << "):\n"
        << " Printing details of the integration method\n\n";

   cout << " compute int_0^infty dz J_0(q z) = 1/q\n\n";

   cout << " using an inverse power law grid (p = "
        << bessel_w_quad.grid_params().at(0)
        << " and z0 = "
        << bessel_w_quad.grid_params().at(1)
        << ")\n";

   cout << " ";
   bessel_w_quad.print_grid_info();
   cout << endl << endl;

   cout << std::setprecision(4);

   // constant integration function
   const index_t N_pts = bessel_w_quad.z_values().size();
   const grid_vector f_values {grid_vector::Constant(N_pts, 1.)};

   const vector_d q_values {0.05, 8.};

   for (const double& q : q_values) {
      const double int_exact = 1./q;

      cout << "with standard settings: ";
      bessel_w_quad.print_info(q);

      const double int_w_quad = bessel_w_quad.int_J_nu_minus_1(f_values, q);
      const double rel_acc_w_quad = std::abs(int_w_quad / int_exact- 1.);
      cout << "|\n" << "relative accuracy = " << rel_acc_w_quad
           << endl << endl;

      cout << "with quadrature disabled: ";
      bessel_no_quad.print_info(q);

      const double int_no_quad = bessel_no_quad.int_J_nu_minus_1(f_values, q);
      const double rel_acc_no_quad = std::abs(int_no_quad/ int_exact - 1.);
      cout << "|\n" << "relative accuracy = " << rel_acc_no_quad
           << endl << endl;
   }

   cout << "---------------------------------------------------------\n"
        << "detailed output from integrator with quadrature disabled:\n\n";

   const int verbose = 1;  // for C++ code output set verbose = 2

   for (const double& q : q_values) {
      bessel_no_quad.int_J_nu_minus_1(f_values, q, verbose);
   }

} // main
/// \endcond
