<!-- To view this file in a formatted version with hyperlinks, point your browser to doc/html/index.html -->

[TOC]

Overview
=========

`BestLime` is a `C++` library for computing Fourier-Bessel transforms with
Levin's integration method.


Features
---------

`BestLime` provides methods for computing the integral of a function `f(z)`
times `J(nu, z q)`, where `J(nu, x)` is a Bessel function of the first kind. The
values of the function `f(z)` are required on an interpolation grid that is
independent of `q` and can be selected by the user.  The order `nu` of the
Bessel function can be positive or zero, the lower limit of the `z` integration
can be zero or finite, and the upper limit can be finite or infinity.

The integration algorithm is described in Ref [1], with the main ingredients
being an integration method by Levin (Ref [2]) and Chebyshev interpolation (Refs
[3-5]).  By design, the algorithm is _not_ adaptive, which provides high
efficiency when the function `f(z)` is expensive to compute.  In turn, the
accuracy of the results depends on an appropriate choice of interpolation grid.
Details are given in the documentation of the class
`bestlime::Bessel_integrator` and in Ref [1].


Getting Started
----------------

### Requirements ###

To install and use `BestLime`, you need

 * a C++14 compiler
 * CMake (at least 3.16)
 * the GNU Scientific Library (at least GSL 2.0)


### Installation ###

See the [Installation Instructions] for details on how to configure, build, and
install `BestLime`.


### Documentation ###

To learn how to use `BestLime`, you can

 * browse the documentation of the class `bestlime::Bessel_integrator`, which is
   the main user interface of the library,

 * browse and adapt the code examples in the subdirectory `examples` of the
   main source tree (also accessible via the [File List]),

 * consult the detailed information in the [Namespace Reference] and the
   [Class Reference].

Please follow the [Guidelines for Academic Use] below when using `BestLime`.


Included Packages                                                    {#included}
-----------------

Linear algebra operations are performed using the [Eigen] library.  The present
distribution includes the headers of Eigen version 3.4.0 for dense matrix
operations.  Eigen is released under the [Mozilla Public License][MPL FAQ] (and
some of the parts that are included here under the Apache license).  See the
files [COPYING.MPL2] and [COPYING.APACHE] in the subdirectory
`include/bestlime/Eigen` of the main source tree.


Feedback and Getting Help
--------------------------

To contact us, please write to: <chilipdf@desy.de>

Before asking for help, please consult the available documentation and make sure
you have followed the instructions.

We appreciate any feedback including bug reports, feature suggestions, and
compliments.

 * For **bug reports**, please provide a minimal example that reproduces the bug
   or suggest a concrete bug fix. Otherwise, please give sufficient details on
   the observed and expected behavior and include all program output.

 * To **suggest a new feature**, please describe your concrete use case and its
   requirements.


Authors
--------

Markus Diehl and Oskar Grocholski,
Deutsches Elektronen-Synchrotron [DESY]


Guidelines For Academic Use                                        {#guidelines}
============================

`BestLime` is being developed as part of a scientific research effort. Proper
academic recognition is essential for its continued development.


Citation Policy
----------------

Please follow standard academic practice for references when using `BestLime`.
In particular:

 1. The main `BestLime` reference [1] should always be cited when using
    `BestLime` or any part of it in the context of academic work. This includes
    in particular publications containing results that were obtained with the
    help of `BestLime`.

 2. The original literature [2-5] on which `BestLime` is based should be cited
    according to its relevance for a particular result, applying the same
    threshold criteria as if you had used the results of that literature
    directly.

For your convenience, some references are collected in the file
[doc/bestlime.bib][bibtex].


Modifying BestLime
-----------------

 1. We kindly ask that you report any suspected bugs and proposed fixes back to
    us.

 2. We encourage you to use `BestLime` in your own projects, to modify it to
your needs, and to develop your own code.

 3. If you prefer to distribute your derived code, you may do so under the
    `BestLime` license terms (GPLv3 with supplements, see the file [LICENSE.md]
    for details). Note that under the GPLv3, code that only links to `BestLime`
    is considered a derived work and is subject to the same terms.


References
-----------

Main `BestLime` reference:

[1] M. Diehl and O. Grocholski,
    _Efficient computation of Fourier-Bessel transforms
    for transverse-momentum dependent parton distributions
    and other functions_,
    Eur.Phys.J.C 84 (2024) 858,
    [arXiv:2405.08616 [hep-ph]][Ref BestLime]

Reference for the original integration method:

[2] D. Levin,
    _Fast integration of rapidly oscillatory functions_,
    Journal of Computational and Applied Mathematics 67 (1996) 95
    [[doi:10.1016/0377-0427(94)00118-9]][Ref Levin]

References for ChiliPDF and for Chebyshev interpolation:

[3] M. Diehl, R. Nagar, F. J. Tackmann,
    _ChiliPDF: Chebyshev interpolation library for PDFs_,
    Eur.Phys.J.C 82 (2022) 3, 257,
    [arXiv:2112.09703 [hep-ph]][Ref ChiliPDF]

[4] M. Diehl, R. Nagar, P. Ploessl, F. J. Tackmann,
    _Evolution and interpolation of double parton distributions using Chebyshev grids_,
    Eur.Phys.J.C 83 (2023) 6, 536,
    [arXiv:2305.04845 [hep-ph]][Ref ChiliDPD]

[5] L. N. Trefethen,
    _Approximation Theory and Approximation Practice_,
   Society for Industrial and Applied Mathematics (2012)
   [[webpage]][Ref Trefethen]

The lower-level classes of `BestLime` have been adapted from the ChiliPDF
library, which is under development.  Ref. [3] derives or re-derives several
results for Chebyshev interpolation that are used in the ChiliPDF project.  Ref.
[4] discusses and benchmarks the variable transformations for interpolation that
are also used in `BestLime`.  A wealth of mathematical background on Chebyshev
interpolation can be found in the book [5].

[links]: #----------------------------------------------------------------------

[Installation Instructions]: bestlime/INSTALL.md
[Namespace Reference]:       namespaces.html
[Class Reference]:           annotated.html
[File List]:                 files.html
[LICENSE.md]:                bestlime/LICENSE.md
[COPYING.MPL2]:              ../../include/bestlime/Eigen/COPYING.MPL2
[COPYING.APACHE]:            ../../include/bestlime/Eigen/COPYING.APACHE
[bibtex]:                    ../../doc/bestlime.bib

[Guidelines For Academic Use]: \ref guidelines

[Eigen]:             https://eigen.tuxfamily.org
[MPL FAQ]:           https://www.mozilla.org/en-US/MPL/2.0/FAQ
[DESY]:              https://www.desy.de/index_eng.html
[Ref BestLime]:      https://arxiv.org/abs/2405.08616
[Ref Levin]:         https://doi.org/10.1016/0377-0427(94)00118-9
[Ref ChiliPDF]:      https://arxiv.org/abs/2112.09703
[Ref ChiliDPD]:      https://arxiv.org/abs/2305.04845
[Ref Trefethen]:     https://people.maths.ox.ac.uk/trefethen/ATAP
