<!-- To view this file in a formatted version with hyperlinks, point your browser to doc/html/index.html -->

License
========

See [Included Packages] in the README.md file for the license of the `Eigen`
library, which included in this distribution.


### BestLime License Terms ###

`BestLime`: A `C++` library for computing Fourier-Bessel transforms with Levin's integration method.

Copyright &copy; 2024  ChiliPDF Collaboration (DESY)

`BestLime` is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

`BestLime` is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
`BestLime`.  If not, see <http://www.gnu.org/licenses/>.

`BestLime` has been developed as part of a scientific research effort. Proper
academic recognition is necessary for its continued development. Therefore, the
following supplemental academic attribution terms are added as additional
requirements under section 7 of the GNU General Public License, version 3
("GPLv3"):

1. Any misrepresentation of the origin of this Program, or any part of it, is
   prohibited. A modified version must be clearly marked as being derived from
   the original version. In case the modifications change the results of the
   Program in a nontrivial way, a short description of the differences must be
   provided in a prominent place.

2. All author attributions, including scientific references, in the Program, or
   any covered work, must be preserved.

3. All notices of authorship, including scientific references, displayed by the
   Program, or any covered work, must be preserved or reproduced equivalently in
   the corresponding notices displayed by works containing it.

4. The names of authors or contributors of the Program may not be used to
   endorse or promote derived works without specific prior written permission.


(Everyone is permitted to copy and distribute verbatim copies of these
supplemental terms, but changing them is not allowed.)


### Explanation of the License Terms ###

You may freely use `BestLime` in your own research. This includes modifying it,
linking your own programs to it, or including parts of `BestLime` in your own
programs. These use cases constitute a "modified version" or a "derived work".

The publication of scientific results that made use of `BestLime` (the original
version or a privately modified version or a derived work) or its output does
not constitute a form of propagation (distribution) and therefore is not subject
to the license terms. (In general, a software license cannot tell you how to use
a program or its output, only to what extent you are allowed to modify and/or
redistribute it.)

Nevertheless, when you use `BestLime` in academic research, you should of course
follow standard academic practice for including references, see the
[Guidelines for Academic Use] in the README.md file for more details.

Sharing your modified version or derived work with others does constitute a
propagation (distribution) and is subject to the license terms. You may
redistribute derived work under the above license terms (GPLv3 plus supplemental
academic attribution terms). The GPLv3 requires (among other things) that you
must license the _entire_ derived work, as a whole, under the GPLv3 (or a
compatible license) _including_ the above supplemental terms (see in particular
sections 4 and 5 of the GPLv3). For this purpose, you should include a file
equivalent to this one in your own work, including the above supplemental terms
in unmodified form.


[links]: #----------------------------------------------------------------------

[Included Packages]:           \ref included
[Guidelines For Academic Use]: \ref guidelines
