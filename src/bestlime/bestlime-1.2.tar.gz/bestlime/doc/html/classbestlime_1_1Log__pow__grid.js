var classbestlime_1_1Log__pow__grid =
[
    [ "Log_pow_grid", "classbestlime_1_1Log__pow__grid.html#a66e8ce97c9262b73c683b69d22c9f8f6", null ],
    [ "Log_pow_grid", "classbestlime_1_1Log__pow__grid.html#aed2132b8a5ba960222f3c612ee9c95af", null ],
    [ "variable_transform", "classbestlime_1_1Log__pow__grid.html#a3fd39edebd2b49632be0577211e6820a", null ],
    [ "inverse_transform", "classbestlime_1_1Log__pow__grid.html#a05b7fe5ea45801488332bb237de041e9", null ],
    [ "jacobian", "classbestlime_1_1Log__pow__grid.html#aa366236e56534749966cb3a9ccb12c1e", null ],
    [ "hessian", "classbestlime_1_1Log__pow__grid.html#a9c95206f605925df6874ef7c41c1bd5b", null ]
];