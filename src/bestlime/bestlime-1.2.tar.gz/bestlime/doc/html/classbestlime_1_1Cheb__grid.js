var classbestlime_1_1Cheb__grid =
[
    [ "Cheb_grid", "classbestlime_1_1Cheb__grid.html#a6c62e1173f05b364b130e671b56e6a18", null ],
    [ "operator[]", "classbestlime_1_1Cheb__grid.html#aa7f0b6a940d8375ccf7ff173f31d290e", null ],
    [ "size", "classbestlime_1_1Cheb__grid.html#aecea331aed98122e648c5417bc78863e", null ],
    [ "sin2_grid", "classbestlime_1_1Cheb__grid.html#af53ddc7bde6d7ffd86dc2e9342bc1477", null ],
    [ "clenshaw_weights", "classbestlime_1_1Cheb__grid.html#a0469dc6f7d03536ba5f7763f4ba2dd1d", null ],
    [ "diff_matrix", "classbestlime_1_1Cheb__grid.html#a2983879607eeeb1876ce0282ff45fa00", null ],
    [ "diff_matrix_squared", "classbestlime_1_1Cheb__grid.html#af1c2723c27d3f07e7435b1869e9d731a", null ],
    [ "cheb_matrix", "classbestlime_1_1Cheb__grid.html#a7b21b84494b0051e5edbe06ba73f8f5d", null ],
    [ "lin_transf_grid", "classbestlime_1_1Cheb__grid.html#a3aef76c5a7275322ba226432e217ee01", null ],
    [ "print", "classbestlime_1_1Cheb__grid.html#a83af3eb6a344e288593c82cdce670632", null ]
];