var classbestlime_1_1Power__law__grid =
[
    [ "Power_law_grid", "classbestlime_1_1Power__law__grid.html#af9eff2acfce4519b4f21a695d04197d5", null ],
    [ "Power_law_grid", "classbestlime_1_1Power__law__grid.html#a20cecde2c6fbe44906431b0c8fa6a9b0", null ],
    [ "variable_transform", "classbestlime_1_1Power__law__grid.html#ae0288abd7c7cd2791f1dcadd4d4ea9ef", null ],
    [ "inverse_transform", "classbestlime_1_1Power__law__grid.html#a3595bd60c6198d836f83cf474d7b5d76", null ],
    [ "jacobian", "classbestlime_1_1Power__law__grid.html#a51661b1343718f7d9c7b4676ec7cc025", null ],
    [ "hessian", "classbestlime_1_1Power__law__grid.html#ad13490829642d62b446c8cbfcdb8a654", null ]
];