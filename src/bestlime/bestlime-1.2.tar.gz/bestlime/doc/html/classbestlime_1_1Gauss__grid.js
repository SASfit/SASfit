var classbestlime_1_1Gauss__grid =
[
    [ "Gauss_grid", "classbestlime_1_1Gauss__grid.html#a809d586255d734f1d0d0f02946c42261", null ],
    [ "Gauss_grid", "classbestlime_1_1Gauss__grid.html#a54422246acd8158a6849125cd2611ca8", null ],
    [ "variable_transform", "classbestlime_1_1Gauss__grid.html#a699cd45e039b86c67e5497edd16965e8", null ],
    [ "inverse_transform", "classbestlime_1_1Gauss__grid.html#a01ae93b567be02560f928e927baba1a6", null ],
    [ "jacobian", "classbestlime_1_1Gauss__grid.html#a1dcd7a85b0b110028e5088b50b4aeae9", null ],
    [ "hessian", "classbestlime_1_1Gauss__grid.html#a3457eed431c3c42fc9762fe99a908d59", null ]
];