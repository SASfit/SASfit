var files_dup =
[
    [ "basic_work_flow.cpp", "basic__work__flow_8cpp.html", null ],
    [ "benchmarks.cpp", "benchmarks_8cpp.html", null ],
    [ "Bessel_integrator.hpp", "Bessel__integrator_8hpp.html", [
      [ "Bessel_integrator", "classbestlime_1_1Bessel__integrator.html", "classbestlime_1_1Bessel__integrator" ]
    ] ],
    [ "Bessel_integrator_impl.hpp", "Bessel__integrator__impl_8hpp.html", [
      [ "Bessel_integrator_impl", "classbestlime_1_1Bessel__integrator__impl.html", "classbestlime_1_1Bessel__integrator__impl" ]
    ] ],
    [ "Bessel_integrator_special.hpp", "Bessel__integrator__special_8hpp.html", [
      [ "Bessel_integrator_special", "classbestlime_1_1Bessel__integrator__special.html", "classbestlime_1_1Bessel__integrator__special" ]
    ] ],
    [ "Bessel_integrator_special_impl.hpp", "Bessel__integrator__special__impl_8hpp.html", [
      [ "Bessel_integrator_special_impl", "classbestlime_1_1Bessel__integrator__special__impl.html", "classbestlime_1_1Bessel__integrator__special__impl" ]
    ] ],
    [ "Cheb_grid.hpp", "Cheb__grid_8hpp.html", [
      [ "Cheb_grid", "classbestlime_1_1Cheb__grid.html", "classbestlime_1_1Cheb__grid" ]
    ] ],
    [ "Composite_grid.hpp", "Composite__grid_8hpp.html", [
      [ "Subint_info", "classbestlime_1_1Subint__info.html", "classbestlime_1_1Subint__info" ],
      [ "Composite_grid", "classbestlime_1_1Composite__grid.html", "classbestlime_1_1Composite__grid" ]
    ] ],
    [ "config.hpp", "config_8hpp.html", "config_8hpp" ],
    [ "custom_transform.cpp", "custom__transform_8cpp.html", null ],
    [ "Eigen_core.hpp", "Eigen__core_8hpp.html", null ],
    [ "Eigen_solvers.hpp", "Eigen__solvers_8hpp.html", null ],
    [ "Grid_1d.hpp", "Grid__1d_8hpp.html", "Grid__1d_8hpp" ],
    [ "Grid_types.hpp", "Grid__types_8hpp.html", [
      [ "Linear_grid", "classbestlime_1_1Linear__grid.html", "classbestlime_1_1Linear__grid" ],
      [ "Log_grid", "classbestlime_1_1Log__grid.html", "classbestlime_1_1Log__grid" ],
      [ "Power_law_grid", "classbestlime_1_1Power__law__grid.html", "classbestlime_1_1Power__law__grid" ],
      [ "Inv_power_law_grid", "classbestlime_1_1Inv__power__law__grid.html", "classbestlime_1_1Inv__power__law__grid" ],
      [ "Log_pow_grid", "classbestlime_1_1Log__pow__grid.html", "classbestlime_1_1Log__pow__grid" ],
      [ "Exp_grid", "classbestlime_1_1Exp__grid.html", "classbestlime_1_1Exp__grid" ],
      [ "Exp_sqrt_grid", "classbestlime_1_1Exp__sqrt__grid.html", "classbestlime_1_1Exp__sqrt__grid" ],
      [ "Gauss_grid", "classbestlime_1_1Gauss__grid.html", "classbestlime_1_1Gauss__grid" ]
    ] ],
    [ "integration_method.cpp", "integration__method_8cpp.html", null ],
    [ "integration_weights.cpp", "integration__weights_8cpp.html", null ],
    [ "Linear_solver.hpp", "Linear__solver_8hpp.html", [
      [ "Linear_solver", "classbestlime_1_1Linear__solver.html", "classbestlime_1_1Linear__solver" ]
    ] ],
    [ "special_integrals.cpp", "special__integrals_8cpp.html", null ],
    [ "timing.cpp", "timing_8cpp.html", null ],
    [ "Vector_types.hpp", "Vector__types_8hpp.html", "Vector__types_8hpp" ]
];