var annotated_dup =
[
    [ "bestlime", "namespacebestlime.html", [
      [ "Bessel_integrator", "classbestlime_1_1Bessel__integrator.html", "classbestlime_1_1Bessel__integrator" ],
      [ "Bessel_integrator_impl", "classbestlime_1_1Bessel__integrator__impl.html", "classbestlime_1_1Bessel__integrator__impl" ],
      [ "Bessel_integrator_special", "classbestlime_1_1Bessel__integrator__special.html", "classbestlime_1_1Bessel__integrator__special" ],
      [ "Bessel_integrator_special_impl", "classbestlime_1_1Bessel__integrator__special__impl.html", "classbestlime_1_1Bessel__integrator__special__impl" ],
      [ "Cheb_grid", "classbestlime_1_1Cheb__grid.html", "classbestlime_1_1Cheb__grid" ],
      [ "Subint_info", "classbestlime_1_1Subint__info.html", "classbestlime_1_1Subint__info" ],
      [ "Composite_grid", "classbestlime_1_1Composite__grid.html", "classbestlime_1_1Composite__grid" ],
      [ "Grid_1d", "classbestlime_1_1Grid__1d.html", "classbestlime_1_1Grid__1d" ],
      [ "Linear_grid", "classbestlime_1_1Linear__grid.html", "classbestlime_1_1Linear__grid" ],
      [ "Log_grid", "classbestlime_1_1Log__grid.html", "classbestlime_1_1Log__grid" ],
      [ "Power_law_grid", "classbestlime_1_1Power__law__grid.html", "classbestlime_1_1Power__law__grid" ],
      [ "Inv_power_law_grid", "classbestlime_1_1Inv__power__law__grid.html", "classbestlime_1_1Inv__power__law__grid" ],
      [ "Log_pow_grid", "classbestlime_1_1Log__pow__grid.html", "classbestlime_1_1Log__pow__grid" ],
      [ "Exp_grid", "classbestlime_1_1Exp__grid.html", "classbestlime_1_1Exp__grid" ],
      [ "Exp_sqrt_grid", "classbestlime_1_1Exp__sqrt__grid.html", "classbestlime_1_1Exp__sqrt__grid" ],
      [ "Gauss_grid", "classbestlime_1_1Gauss__grid.html", "classbestlime_1_1Gauss__grid" ],
      [ "Linear_solver", "classbestlime_1_1Linear__solver.html", "classbestlime_1_1Linear__solver" ]
    ] ]
];