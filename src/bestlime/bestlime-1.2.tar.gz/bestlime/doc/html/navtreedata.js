/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "BestLime", "index.html", [
    [ "Overview", "index.html#autotoc_md0", [
      [ "Features", "index.html#autotoc_md1", null ],
      [ "Getting Started", "index.html#autotoc_md2", [
        [ "Requirements", "index.html#autotoc_md3", null ],
        [ "Installation", "index.html#autotoc_md4", null ],
        [ "Documentation", "index.html#autotoc_md5", null ]
      ] ],
      [ "Included Packages", "index.html#included", null ],
      [ "Feedback and Getting Help", "index.html#autotoc_md6", null ],
      [ "Authors", "index.html#autotoc_md7", null ]
    ] ],
    [ "Guidelines For Academic Use", "index.html#guidelines", [
      [ "Citation Policy", "index.html#autotoc_md8", null ],
      [ "Modifying BestLime", "index.html#autotoc_md9", null ],
      [ "References", "index.html#autotoc_md10", null ]
    ] ],
    [ "INSTALL", "md_bestlime_INSTALL.html", [
      [ "Quick Start", "md_bestlime_INSTALL.html#autotoc_md11", null ],
      [ "Detailed Instructions", "md_bestlime_INSTALL.html#autotoc_md12", [
        [ "Requirements", "md_bestlime_INSTALL.html#requirements", [
          [ "Build Toolchain", "md_bestlime_INSTALL.html#autotoc_md13", [
            [ "CMake", "md_bestlime_INSTALL.html#autotoc_md14", null ],
            [ "C++14", "md_bestlime_INSTALL.html#autotoc_md15", null ]
          ] ],
          [ "External Packages", "md_bestlime_INSTALL.html#autotoc_md16", [
            [ "GSL", "md_bestlime_INSTALL.html#autotoc_md17", null ]
          ] ],
          [ "Included Packages", "md_bestlime_INSTALL.html#autotoc_md18", null ]
        ] ],
        [ "Configuration with CMake", "md_bestlime_INSTALL.html#cmake", [
          [ "Using CMake", "md_bestlime_INSTALL.html#using_cmake", null ],
          [ "Configuration Options", "md_bestlime_INSTALL.html#autotoc_md19", null ]
        ] ],
        [ "Building", "md_bestlime_INSTALL.html#autotoc_md20", null ],
        [ "Installing", "md_bestlime_INSTALL.html#installing", null ]
      ] ]
    ] ],
    [ "LICENSE", "md_bestlime_LICENSE.html", [
      [ "License", "md_bestlime_LICENSE.html#autotoc_md21", null ]
    ] ],
    [ "HISTORY", "md_bestlime_HISTORY.html", [
      [ "Version History", "md_bestlime_HISTORY.html#autotoc_md24", null ]
    ] ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Bessel__integrator_8hpp.html",
"classbestlime_1_1Log__pow__grid.html#aed2132b8a5ba960222f3c612ee9c95af"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';