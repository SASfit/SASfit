var classbestlime_1_1Linear__solver =
[
    [ "Linear_solver", "classbestlime_1_1Linear__solver.html#a5dd988cb2b610a73b011e18eacdb5ba0", null ],
    [ "Linear_solver", "classbestlime_1_1Linear__solver.html#a6f29f6708b615ab5a3a60abc8cca97f0", null ],
    [ "solve", "classbestlime_1_1Linear__solver.html#a77cab1d8a806098454edbd4d7d8b863d", null ],
    [ "dimension", "classbestlime_1_1Linear__solver.html#ae808f3ea5dae6b9ea5c8ce6240665aaf", null ],
    [ "r_LU_max", "classbestlime_1_1Linear__solver.html#abefd22d709a2bcf18982c0179f7e8c0b", null ],
    [ "r_SV_max", "classbestlime_1_1Linear__solver.html#af2d0b6a843c0b59be86bdc59f7828eed", null ],
    [ "LU_ratio", "classbestlime_1_1Linear__solver.html#a7ce0e5a9283f26ffa9cc2d98fffd9f57", null ],
    [ "SV_is_used", "classbestlime_1_1Linear__solver.html#a0bafe751aace10cd9d70a9822a53a843", null ],
    [ "small_SV_ratios", "classbestlime_1_1Linear__solver.html#a4bc09fb2c2810e7f3379abbd0a408bd2", null ],
    [ "diagonal", "classbestlime_1_1Linear__solver.html#af236a4690ac5efbaf3d2f23fe867b951", null ]
];