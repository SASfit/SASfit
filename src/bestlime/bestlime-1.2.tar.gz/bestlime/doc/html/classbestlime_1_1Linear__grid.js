var classbestlime_1_1Linear__grid =
[
    [ "Linear_grid", "classbestlime_1_1Linear__grid.html#a14f8af862a6662c4222b4408e9e9459d", null ],
    [ "Linear_grid", "classbestlime_1_1Linear__grid.html#a2b053abbd5c7aa9eba76b30a4416c5a8", null ],
    [ "variable_transform", "classbestlime_1_1Linear__grid.html#a57f8d27c9d394ad5371ebedbdd87efb8", null ],
    [ "inverse_transform", "classbestlime_1_1Linear__grid.html#a00e915f2aba567826e9fa5b7c3d9929c", null ],
    [ "jacobian", "classbestlime_1_1Linear__grid.html#ab2e79741f89d02939058afdb928fe7d8", null ],
    [ "hessian", "classbestlime_1_1Linear__grid.html#a212aa37412a2d4104a0c195a83e1abef", null ]
];