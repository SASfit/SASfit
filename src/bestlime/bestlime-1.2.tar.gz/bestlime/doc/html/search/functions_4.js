var searchData=
[
  ['exp_5fgrid_179',['Exp_grid',['../classbestlime_1_1Exp__grid.html#a3ecebba4ebb1edf4c29fe7f2ffd82959',1,'bestlime::Exp_grid::Exp_grid(const index_vector &amp;n_pts, const vector_d &amp;interv_limits, double m)'],['../classbestlime_1_1Exp__grid.html#ab49ceb42d42c29472ae16ebae13b0bad',1,'bestlime::Exp_grid::Exp_grid(const index_vector &amp;n_pts, const vector_d &amp;interv_limits, const vector_d &amp;parameters)']]],
  ['exp_5fsqrt_5fgrid_180',['Exp_sqrt_grid',['../classbestlime_1_1Exp__sqrt__grid.html#a7185909815688b561d862ebb383c6d28',1,'bestlime::Exp_sqrt_grid::Exp_sqrt_grid(const index_vector &amp;n_pts, const vector_d &amp;interv_limits, double m)'],['../classbestlime_1_1Exp__sqrt__grid.html#a0d71f8014571c6762cbec3fd4d38fc56',1,'bestlime::Exp_sqrt_grid::Exp_sqrt_grid(const index_vector &amp;n_pts, const vector_d &amp;interv_limits, const vector_d &amp;parameters)']]]
];
