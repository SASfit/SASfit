var searchData=
[
  ['power_5flaw_5fgrid_132',['Power_law_grid',['../classbestlime_1_1Power__law__grid.html',1,'bestlime']]]
];
