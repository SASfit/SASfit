var searchData=
[
  ['quadrature_5fis_5fused_219',['quadrature_is_used',['../classbestlime_1_1Bessel__integrator.html#ac19ffda098679f22f340da605d42fc15',1,'bestlime::Bessel_integrator::quadrature_is_used()'],['../classbestlime_1_1Bessel__integrator__special.html#a2053164c3c034fb9045a0a7a87925f16',1,'bestlime::Bessel_integrator_special::quadrature_is_used()']]]
];
