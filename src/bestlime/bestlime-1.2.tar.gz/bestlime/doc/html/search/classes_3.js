var searchData=
[
  ['gauss_5fgrid_125',['Gauss_grid',['../classbestlime_1_1Gauss__grid.html',1,'bestlime']]],
  ['grid_5f1d_126',['Grid_1d',['../classbestlime_1_1Grid__1d.html',1,'bestlime']]]
];
