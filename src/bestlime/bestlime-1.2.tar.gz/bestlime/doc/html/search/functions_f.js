var searchData=
[
  ['r_5flu_5fmax_220',['r_LU_max',['../classbestlime_1_1Linear__solver.html#abefd22d709a2bcf18982c0179f7e8c0b',1,'bestlime::Linear_solver']]],
  ['r_5fsv_5fmax_221',['r_SV_max',['../classbestlime_1_1Linear__solver.html#af2d0b6a843c0b59be86bdc59f7828eed',1,'bestlime::Linear_solver']]]
];
