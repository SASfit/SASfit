var searchData=
[
  ['inv_5fpower_5flaw_5fgrid_127',['Inv_power_law_grid',['../classbestlime_1_1Inv__power__law__grid.html',1,'bestlime']]]
];
