var indexSectionsWithContent =
{
  0: "_bcdefghijlnopqrstvwz",
  1: "bcegilps",
  2: "b",
  3: "bcegilstv",
  4: "_bcdefghijlnopqrsvwz",
  5: "_bi",
  6: "gisv",
  7: "hil"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Pages"
};

