var classbestlime_1_1Log__grid =
[
    [ "Log_grid", "classbestlime_1_1Log__grid.html#a040b7a42e9fcfff7235bfbe92cb5dc0d", null ],
    [ "Log_grid", "classbestlime_1_1Log__grid.html#a5ecae4a52b048b5adc9ffc6d7a9260db", null ],
    [ "variable_transform", "classbestlime_1_1Log__grid.html#a2305874fbac1d15d4da48fc0691f635a", null ],
    [ "inverse_transform", "classbestlime_1_1Log__grid.html#a7d24112e25521b032802dbe366dfc4eb", null ],
    [ "jacobian", "classbestlime_1_1Log__grid.html#a59cea230d46656fe8430d79223456750", null ],
    [ "hessian", "classbestlime_1_1Log__grid.html#aa292a14c5bb7b0bfda740c04c7ca5a0c", null ]
];