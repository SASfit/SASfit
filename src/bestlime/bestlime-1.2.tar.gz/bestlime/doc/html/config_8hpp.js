var config_8hpp =
[
    [ "bestlime_CXX_COMPILER_IS_GNU", "config_8hpp.html#a007466d07bcffcd1d15ce7b5bd03fcba", null ],
    [ "bestlime_version", "config_8hpp.html#aa5f64cb1613f0f8fdb86d3de45130c5d", null ]
];