//------------------------------------------------------------------------------
/// \file  Composite_grid.cpp
/// \brief Implementation of classes Subint_info and Composite_grid.
//
// Author(s): Riccardo Nagar
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Composite_grid.hpp"

#include <cassert>
#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <utility>

namespace bestlime
{

//------------------------------------------------------------------------------
// Subint_info class definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Subint_info::Subint_info(const index_vector& n_points,
                         const vector_d& interval_limits)
   : _n_points{n_points},
     _int_lim_indices{_make_int_lim_indices(n_points)},
     _grid_size{_int_lim_indices.back() + 1},
     _interval_limits{interval_limits}
{
   // checks that there is at least one subinterval
   if (n_points.empty()) {
       throw std::logic_error("Subint_info: There must be at least one subinterval.");
   }

   // checks that each subinterval has at least 3 points
   for (const index_t npts_element : n_points) {
      if (npts_element < 3)
         throw std::logic_error("Subint_info: Each subinterval must have at least 3 points.");
   }

   // checks whether number of intervals and number of separation points
   // are consistent
   if (interval_limits.size() != n_points.size() + 1) {
      throw std::logic_error("Subint_info: The numbers of intervals and of interval limits do not match.");
   }

   // checks that interval limits are strictly increasing
   for (size_t i = 1; i < interval_limits.size(); ++i) {
      if (interval_limits[i-1] >= interval_limits[i]) {
         throw std::logic_error("Subint_info: interval limits must be strictly increasing.");
      }
   }
}

//------------------------------------------------------------------------------
void Subint_info::print() const
{
   std::cout << " total points:           " << grid_size() << std::endl;
   std::cout << " points per subinterval: ";
   for (const index_t& npts : _n_points) {
      std::cout << npts << "\t";
   }
   std::cout << std::endl;
   std::cout << " interval limits:        ";
   for (const double& limit : _interval_limits) {
      std::cout << limit  << "\t";
   }
   std::cout << std::endl;
}

//------------------------------------------------------------------------------
// Subint_info: Private member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
index_vector Subint_info::_make_int_lim_indices(const index_vector& npts) const
{
   const size_t n = npts.size() + 1;
   index_vector indices(n);
   indices[0] = 0;
   for (size_t i = 1; i < n; ++i) {
      indices[i] = indices[i - 1] + npts[i - 1] - 1;
   }
   return indices;
}


//------------------------------------------------------------------------------
// Composite_grid class definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Composite_grid::Composite_grid(const index_vector& n_pts,
                               const vector_d& int_lims)
   : _info{Subint_info(n_pts, int_lims)},
     _basic_grids{_make_basic_grids()},
     _grid{_make_global_grid()}
{}

//------------------------------------------------------------------------------
Composite_grid::Composite_grid(const Subint_info& info)
   : _info(info),
     _basic_grids{_make_basic_grids()},
     _grid{_make_global_grid()}
{}

//------------------------------------------------------------------------------
Composite_grid::Composite_grid(const Subint_info& info,
                               const Composite_grid& input_grid)
   : _info{info},
     _basic_grids{_make_basic_grids(input_grid)},
     _grid{_make_global_grid()}
{}

//------------------------------------------------------------------------------
const Cheb_grid& Composite_grid::basic_grid(size_t k) const
{
   assert(k < _info.n_intervals());
   return _basic_grids.at(_info.n_points(k));
}

//------------------------------------------------------------------------------
bool Composite_grid::index_in_subinterval(index_t index,
                                          size_t subinterval) const
{
   assert(subinterval < _info.n_intervals());

   const index_t subint_start = _info.int_lim_indices(subinterval);
   const index_t subint_end = _info.int_lim_indices(subinterval + 1);

   return (subint_start <= index && index <= subint_end);
}

//------------------------------------------------------------------------------
grid_vector Composite_grid::clenshaw_weights() const
{
   grid_vector weights(grid_vector::Zero(_grid.size()));

   for (size_t k = 0; k < _info.n_intervals(); ++k) {
      weights.segment(_info.int_lim_indices(k), _info.n_points(k))
         += clenshaw_weights(k);
   }

   return weights;
}

//------------------------------------------------------------------------------
grid_vector Composite_grid::clenshaw_weights(size_t k) const
{
   assert(k < _info.n_intervals());

   const double factor
      = 0.5 * (_info.interval_limits(k+1) - _info.interval_limits(k));

   return factor * _basic_grids.at(_info.n_points(k)).clenshaw_weights();
}

//------------------------------------------------------------------------------
void Composite_grid::print() const
{
   const grid_vector c_weights = clenshaw_weights();

   std::cout << "Point        Value       CC weight" << std::endl;
   for (index_t i = 0; i < _grid.size(); ++i) {
      std::cout << std::setw(5) << i << "\t"
                << std::setw(10) << _grid[i] << "\t"
                << std::setw(10) << c_weights[i] << std::endl;
   }
}

//------------------------------------------------------------------------------
// Composite_grid: Private member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
std::map<index_t, Cheb_grid> Composite_grid::_make_basic_grids() const
{
   std::map<index_t, Cheb_grid> basic_grids;
   for (size_t i = 0; i < _info.n_intervals(); ++i) {
      const index_t npts = _info.n_points(i);

      // add Cheb grid to basic_grids if it is not already present
      if (basic_grids.count(npts) == 0) {
         // polynomial order of the Cheb grid = number of points - 1
         basic_grids.insert(std::make_pair(npts, Cheb_grid(npts - 1)));
      }
   }
   return basic_grids;
}

//------------------------------------------------------------------------------
std::map<index_t, Cheb_grid> Composite_grid::_make_basic_grids(
   const Composite_grid& input_grid) const
{
   std::map<index_t, Cheb_grid> basic_grids;
   for (size_t i = 0; i < _info.n_intervals(); ++i) {
      const index_t npts = _info.n_points(i);

      // add Cheb grid to basic_grids if it is not already present
      if (basic_grids.count(npts) == 0) {
         // copy existing or create new grid
         const Cheb_grid new_grid =
            (input_grid.basic_grid_map().count(npts) == 1) ?
            input_grid.basic_grid_map().at(npts) : Cheb_grid(npts - 1);
         basic_grids.insert(std::make_pair(npts, new_grid));
      }
   }
   return basic_grids;
}

//------------------------------------------------------------------------------
grid_vector Composite_grid::_make_global_grid() const
{
   grid_vector grid(_info.grid_size());

   grid_vector subgrid;
   for (size_t k = 0; k < _info.n_intervals(); ++k) {
      subgrid = _basic_grids.at(_info.n_points(k)).lin_transf_grid(
         _info.interval_limits(k), _info.interval_limits(k+1));

      // append subgrid to global grid
      grid.segment(_info.int_lim_indices(k), _info.n_points(k))
         = subgrid;
   }

   return grid;
}

} // namespace bestlime
