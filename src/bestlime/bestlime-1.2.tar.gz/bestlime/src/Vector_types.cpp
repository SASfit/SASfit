//------------------------------------------------------------------------------
/// \file  Vector_types.cpp
/// \brief Implementation of conversion functions in Vector_types.hpp.
//
// Author(s): Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Vector_types.hpp"

namespace bestlime
{

//------------------------------------------------------------------------------
grid_vector convert_to_grid_vector(const vector_d& vec)
{
   return Eigen::Map<const Eigen::VectorXd>(vec.data(),
      static_cast<index_t>(vec.size()));
}

//------------------------------------------------------------------------------
vector_d convert_to_vector_d(const Eigen::Ref<const grid_vector>& vec)
{
   vector_d result;
   result.reserve(static_cast<size_t>(vec.size()));

   for (const double& element : vec) {
      result.push_back(element);
   }

   return result;
}

} // namespace bestlime
