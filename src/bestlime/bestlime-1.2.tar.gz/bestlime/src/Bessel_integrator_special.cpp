//------------------------------------------------------------------------------
/// \file  Bessel_integrator_special.cpp
/// \brief Template instantiations of class Bessel_integrator_special.
//
// Author(s): Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Bessel_integrator_special.hpp"

namespace bestlime
{

template class Bessel_integrator_special<Linear_grid>;
template class Bessel_integrator_special<Power_law_grid>;
template class Bessel_integrator_special<Inv_power_law_grid>;
template class Bessel_integrator_special<Log_pow_grid>;
template class Bessel_integrator_special<Exp_grid>;
template class Bessel_integrator_special<Exp_sqrt_grid>;
template class Bessel_integrator_special<Gauss_grid>;

} // namespace bestlime
