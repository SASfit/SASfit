//------------------------------------------------------------------------------
/// \file  Bessel_integrator_impl.cpp
/// \brief Implementation of class Bessel_integrator_impl.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Bessel_integrator_impl.hpp"
#include "bestlime/Grid_1d.hpp"

#include <cmath>
#include <cassert>
#include <exception>
#include <algorithm>
#include <iostream>
#include <iomanip>

#include <gsl/gsl_sf_bessel.h>

namespace bestlime
{

//------------------------------------------------------------------------------
// Public member functions
//------------------------------------------------------------------------------
Bessel_integrator_impl::Bessel_integrator_impl(const Grid_1d& grid, double nu,
                                               bool use_quadrature,
                                               double r_LU_max, double r_SV_max)
   : _nu{nu}, _gridref{grid}, _use_quadrature{use_quadrature},
     _r_LU_max{r_LU_max}, _r_SV_max{r_SV_max}, _z_values{grid.values()}
{
   if (nu < 1.)
      throw std::invalid_argument("Bessel_integrator_impl: value of nu must be greater than or equal to 1.");

   if (grid.front() < 0.)
      throw std::invalid_argument("Bessel_integrator_impl: values on the physical grid must not be negative.");

   if (_r_LU_max < 0. || _r_LU_max > 1.)
      throw std::invalid_argument("Bessel_integrator_impl: r_LU_max is outside its allowed range.");

   if (_r_SV_max <= 0. || _r_SV_max >= 1.)
      throw std::invalid_argument("Bessel_integrator_impl: r_SV_max is outside its allowed range.");

   _first_bessel_zero = gsl_sf_bessel_zero_Jnu(nu, 1);

   // derived vectors
   _r_values.resize(_z_values.size());
   std::transform(_z_values.begin(), _z_values.end(), _r_values.begin(),
                  [this](double z) { return _z_1pz(z); });

   _weights_nu.resize(_z_values.size());
   std::transform(_r_values.begin(), _r_values.end(), _weights_nu.begin(),
                  [this](double r) { return pow(r, _nu); });

   if (nu != 1.) {                   // not needed for nu=1
      _weights_nu_m1.resize(_z_values.size());
      std::transform(_r_values.begin(), _r_values.end(), _weights_nu_m1.begin(),
                     [this](double r) { return pow(r, _nu - 1.); });
   }

   // number of subgrids
   const size_t n_subgrids = grid.info().n_intervals();

   // vectors with values of the weighted Bessel functions at intervals limits
   _omega_1.resize(n_subgrids + 1);
   _omega_2.resize(n_subgrids + 1);

   // compute and store _w_diff_matrices and initial _B_matrices
   _make_matrices();

   // compute and store Clenshaw-Curtis weights
   _make_clenshaw_weights();

   _lin_eq_solver.resize(n_subgrids);

   // set number of columns in weight matrix used for quadrature;
   // rows remain empty
   _integration_weights.resize(n_subgrids);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::print_info(double q)
{
   _update_q(q);

   _print_basic_info();

   for (size_t i = 0; i < grid().info().n_intervals(); i++) {
      std::cout << "|" << std::endl;
      std::cout << "| ";
      _print_subgrid_info(i);
      std::cout << "| ";
      _print_method_info(i);
   }
}

//------------------------------------------------------------------------------
// Private member functions
//------------------------------------------------------------------------------

void Bessel_integrator_impl::_check_fgrid(const grid_vector& f_grid) const
{
   if (f_grid.size() != _z_values.size()) {
      throw std::invalid_argument("Bessel_integrator_impl: incorrect size of a function grid in integration call.");
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_int_direct(
   const grid_vector& f_grid, double q, int mode, bool weighted, int verbose)
{
   _check_fgrid(f_grid);
   _update_q(q);

   return _integral(_make_F_vec(f_grid, mode, weighted), verbose);
}

//------------------------------------------------------------------------------
vector_d Bessel_integrator_impl::_int_direct(
   const std::vector<grid_vector>& f_grids, double q, int mode, bool weighted)
{
   vector_d result;
   result.reserve(f_grids.size());

   if (f_grids.size() < static_cast<size_t>(_z_values.size())) {
      _update_q(q);

      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back(_integral(_make_F_vec(f_grid, mode, weighted)));
      }
   } else {
      // use q-dependent integration weights
      const grid_vector weights {_direct_int_weights(q, mode, weighted)};

      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back(f_grid.dot(weights));
      }
   }

   return result;
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_int_by_parts(
   const grid_vector& f_grid, double q, bool weighted, int verbose)
{
   _check_fgrid(f_grid);
   _update_q(q);

   constexpr int mode = -1;
   return (_upper_bdry_factor(weighted) * f_grid.reverse()[0]
           - _lower_bdry_factor(weighted) * f_grid[0]
           - _integral(_make_F_vec(f_grid, mode, weighted), verbose)) / q;
}

//------------------------------------------------------------------------------
vector_d Bessel_integrator_impl::_int_by_parts(
   const std::vector<grid_vector>& f_grids, double q, bool weighted)
{
   vector_d result;
   result.reserve(f_grids.size());

   if (f_grids.size() < static_cast<size_t>(_z_values.size())) {
      _update_q(q);

      const double upper_bdry_fact = _upper_bdry_factor(weighted);
      const double lower_bdry_fact = _lower_bdry_factor(weighted);

      constexpr int mode = -1;
      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back((upper_bdry_fact * f_grid.reverse()[0]
                           - lower_bdry_fact * f_grid[0]
                           - _integral(_make_F_vec(f_grid, mode, weighted))) / q);
      }
   } else {
      // use q-dependent integration weights
      const grid_vector weights {_int_by_parts_weights(q, weighted)};

      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back(f_grid.dot(weights));
      }
   }

   return result;
}

//------------------------------------------------------------------------------
grid_vector Bessel_integrator_impl::_direct_int_weights(
   double q, int mode, bool weighted)
{
   const index_t N_tot = _z_values.size();
   grid_vector result(N_tot);

   _update_q(q);

   for (index_t i = 0; i < N_tot; i++) {
      result[i] = _integral(_make_F_basis_vec(i, mode, weighted));
   }

   return result;
}

//------------------------------------------------------------------------------
grid_vector Bessel_integrator_impl::_int_by_parts_weights(
   double q, bool weighted)
{
   const index_t N_tot = _z_values.size();
   grid_vector result(N_tot);

   _update_q(q);

   constexpr int mode = -1;
   for (index_t i = 0; i < N_tot; i++) {
      result[i] = - _integral(_make_F_basis_vec(i, mode, weighted));
   }

   // boundary terms
   result.reverse()[0] += _upper_bdry_factor(weighted);
   result[0]           -= _lower_bdry_factor(weighted);

   return result * (1./q);
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_upper_bdry_factor(bool weighted) const
{
   return (weighted) ? _omega_1.back() * _r_values.reverse()[0] :
                       _omega_1.back() * _weights_nu.reverse()[0];
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_lower_bdry_factor(bool weighted) const
{
   return (weighted) ? _omega_1.front() * _r_values[0] :
                       _omega_1.front() * _weights_nu[0];
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_integral(
   const std::vector<grid_vector>& F_vec, int verbose) const
{
   const size_t n_subgrids = grid().info().n_intervals();

   double result = 0.;

   for (size_t i = 0; i < n_subgrids; i++) {
      // number of points in this subgrid
      const index_t N = grid().info().n_points(i);

      if (_integration_weights[i].size() == 0) {
         // if quadrature is not set-up use Levin method
         grid_vector P = _lin_eq_solver[i].solve(F_vec[i]);

         const double lower_1 = P[0] * _omega_1[i];
         const double upper_1 = P[N - 1] * _omega_1[i+1];

         const double lower_2 = P[N]
            * _r_values[grid().info().int_lim_indices(i)] * _omega_2[i];
         const double upper_2 = P[2*N - 1]
            * _r_values[grid().info().int_lim_indices(i+1)] * _omega_2[i+1];

         result -= lower_1 + lower_2;
         result += upper_1 + upper_2;

         if (verbose == 1)
            _print_levin_info(i, F_vec[i], P);
         else if (verbose == 2)
            _print_levin_code(i, F_vec[i], P);
      }
      else {
         // use Clenshaw-Curtis quadrature
         result += F_vec[i].dot(_integration_weights[i]);
      }

   } // loop over subgrids

   return result;
}

//------------------------------------------------------------------------------
std::vector<grid_vector> Bessel_integrator_impl::_make_F_vec(
   const grid_vector& f_grid, int mode, bool weighted) const
{
   const size_t n_subgrids = grid().info().n_intervals();

   std::vector<grid_vector> result;
   result.reserve(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      const index_t offset = grid().info().int_lim_indices(i);

      // values of f on subgrid
      grid_vector f_subgrid = f_grid.segment(offset, N);

      // rescale with weights using Eigen's component-wise multiplication
      if (weighted == false) {
         if (mode != -1) {
            f_subgrid = _weights_nu.segment(offset, N).array()
                        * f_subgrid.array();
      } else if (_nu != 1.) {               // weight factor is unity for nu=1
            f_subgrid = _weights_nu_m1.segment(offset, N).array()
                        * f_subgrid.array();
         }
      }

      result.emplace_back(grid_vector::Zero(2*N));

      if (mode == 0) {
         // integral with J_{nu}
         result.back().head(N) = f_subgrid;
      }
      else if (mode == 1) {
         // integral with J_{nu+1}
         result.back().tail(N) = f_subgrid;
      }
      else if (mode == -1) {
         // integral with J_{nu-1}
         result.back().head(N) = _ibp_diff_matrices[i] * f_subgrid;
      }
   }

   return result;
}

//------------------------------------------------------------------------------
std::vector<grid_vector> Bessel_integrator_impl::_make_F_basis_vec(
   index_t grid_point, int mode, bool weighted) const
{
   const size_t n_subgrids = grid().info().n_intervals();

   std::vector<grid_vector> result;
   result.reserve(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      result.emplace_back(grid_vector::Zero(2*N));

      if (grid().base_grid().index_in_subinterval(grid_point, i)) {
         // value of basis function at the specified grid point
         double value = 1.;

         // rescale value
         if (weighted == false) {
            if (mode != -1) {
               value *= _weights_nu[grid_point];
         } else if (_nu != 1.) {               // weight factor is unity for nu=1
               value *= _weights_nu_m1[grid_point];
            }
         }

         const index_t index_on_subgrid
            = grid_point -  grid().info().int_lim_indices(i);

         if (mode == 0) {
            // integral with J_{nu}
            result.back()[index_on_subgrid] = value;
         }
         else if (mode == 1) {
            // integral with J_{nu+1}
            result.back()[N + index_on_subgrid] = value;
         }
         else if (mode == -1) {
            // integral with J_{nu-1}
            result.back().head(N)
               = value * _ibp_diff_matrices[i].col(index_on_subgrid);
         }
      }
   }

   return result;
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_update_q(double q)
{
   if (q <= 0.)
      throw std::invalid_argument("Bessel_integrator_impls::compute_integral(): q must be positive.");

   if (q != _q)
   {
      _q = q;

      _update_omega(q);

      for (size_t i = 0; i < grid().info().n_intervals(); i++) {
         // Levin method will be used when _integration_weights[i] is empty
         _integration_weights[i].resize(0);
         assert(_integration_weights[i].size() == 0);

         if (_use_quadrature &&
            q * grid().info().interval_limits(i+1) <=  _first_bessel_zero)
         {
            _setup_quadrature(i, q);
         }
         else
         {
            _update_solver(i, q);
         }
      }
   }
}

//------------------------------------------------------------------------------
// compute initial matrices
void Bessel_integrator_impl::_make_matrices()
{
   const size_t n_subgrids = grid().info().n_intervals();

   _ibp_diff_matrices.resize(n_subgrids);
   _B_matrices.resize(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      const index_t offset = grid().info().int_lim_indices(i);

      const grid_matrix diff_matrix = grid().diff_matrix(i);

      // multiply rows of differentiation matrix with r(z) = z/(1+z)
      grid_matrix r_diff_matrix(N, N);
      for (index_t j = 0; j < N; j++) {
         r_diff_matrix.row(j) = _r_values[offset + j] * diff_matrix.row(j);
      }

      // vector of 1/(1+z) values on subgrid
      grid_vector inv(N);
      for (index_t j = 0; j < N; j++) {
         inv[j] = _1_1pz(_z_values[offset + j]);
      }

      _ibp_diff_matrices[i] = r_diff_matrix;
      // additional contribution in diagonal elements
      for (index_t j = 0; j < N; j++) {
         _ibp_diff_matrices[i](j, j) -= inv[j] * (_nu + (_nu - 1.) * inv[j]);
      }

      // off-diagonal blocks will be set in update_solver()
      _B_matrices[i].resize(2*N, 2*N);
      _B_matrices[i] << diff_matrix,             grid_matrix::Zero(N, N),
                        grid_matrix::Zero(N, N), r_diff_matrix;

      // diagonal entries
      for (index_t j = 0; j < N; j++) {
         _B_matrices[i](j, j)         += _nu * inv[j];
         _B_matrices[i](j + N, j + N) -= inv[j] * (_nu + 1.
                                                   + (_nu - 1.) * inv[j]);
      }
   }
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_make_clenshaw_weights()
{
   const size_t n_subgrids = grid().info().n_intervals();

   _clenshaw_weights.reserve(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      if (grid().info().interval_limits(i+1) == Grid_1d::infinity)
         break;

      // weights for integration over u
      grid_vector weights {grid().base_grid().clenshaw_weights(i)};

      const index_t N = weights.size();
      const index_t offset = grid().info().int_lim_indices(i);

      // multiply weights with dz / du
      for (index_t k = 0; k < N; ++k) {
         const double u = grid().base_grid()[offset + k];
         weights[k] /= grid().jacobian(u);
      }

      _clenshaw_weights.emplace_back(weights);
   }
}

//------------------------------------------------------------------------------
// update B matrix and linear solver
void Bessel_integrator_impl::_update_solver(size_t subint, double q)
{
   const index_t N = grid().info().n_points(subint);
   const index_t offset = grid().info().int_lim_indices(subint);

   // off-diagonal entries from matrix A
   for (index_t j = 0; j < N; j++) {
      _B_matrices[subint](j, j + N) = q * _r_values[offset + j];
      _B_matrices[subint](j + N, j) = - q;
   }

   _lin_eq_solver[subint] = Linear_solver(_B_matrices[subint],
                                          _r_LU_max, _r_SV_max);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_update_omega(double q)
{
   const index_vector int_lim_indices{grid().info().int_lim_indices()};

   for (size_t i = 0; i < int_lim_indices.size(); i++) {
      const index_t index = int_lim_indices[i];
      _omega_1[i] = _weighted_bessel_nu(index, q);
      _omega_2[i] = _weighted_bessel_nu_p1(index, q);
   }
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_setup_quadrature(size_t subint, double q)
{
   assert(_clenshaw_weights[subint].size() == grid().info().n_points(subint));

   const index_t N = grid().info().n_points(subint);
   const index_t offset = grid().info().int_lim_indices(subint);

   // vector of Clenshaw-Curtis weights times weighted Bessel functions
   _integration_weights[subint].resize(2*N);

   for (index_t i = 0; i < N; i++) {
      _integration_weights[subint][i]
         = _weighted_bessel_nu(offset + i, q) * _clenshaw_weights[subint][i];
   }
   for (index_t i = 0; i < N; i++) {
      _integration_weights[subint][N + i]
         = _weighted_bessel_nu_p1(offset + i, q) * _clenshaw_weights[subint][i];
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_weighted_bessel_nu(index_t i, double q) const
{
   const double z = _z_values[i];

   if (z == 0.) {
      // lim_{z->0} z^{-nu} J_nu(q z) = (q/2) / Gamma(nu + 1)
      return pow(0.5 * q, _nu) / tgamma(_nu + 1.);
   }
   else if (z == Grid_1d::infinity) {
      return 0.;
   }
   else {
      return gsl_sf_bessel_Jnu(_nu, z*q) / _weights_nu[i];
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_weighted_bessel_nu_p1(index_t i, double q) const
{
   const double z = _z_values[i];

   if (z == 0. || z == Grid_1d::infinity) {
      return 0.;
   }
   else {
      return gsl_sf_bessel_Jnu(_nu + 1., z*q) / _weights_nu[i];
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_z_1pz(double z) const
{
   return (z == Grid_1d::infinity) ? 1. : z / (1. + z);
}

//------------------------------------------------------------------------------
double Bessel_integrator_impl::_1_1pz(double z) const
{
   return (z == Grid_1d::infinity) ? 0. : 1. / (1. + z);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_print_basic_info() const
{
   const auto old_prec = std::cout.precision();

   std::cout << "q = " << _q
             << ",  nu = " << _nu << "  (j_nu = "
             << std::setprecision(3) << _first_bessel_zero << ")"
             << std::endl;

   std::cout.precision(old_prec);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_print_subgrid_info(size_t subint) const
{
   std::cout << "subinterval " << subint
             << "  (z = " << grid().info().interval_limits(subint) << " ... ";

   const double z_up = grid().info().interval_limits(subint+1);
   if (z_up == Grid_1d::infinity) {
      std::cout << "infinity)";
   } else {
      std::cout << z_up << ")";
   }

   std::cout << std::endl;
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_print_method_info(size_t subint) const
{
   using std::cout;
   using std::endl;
   using std::setw;

   const int digits = 4;
   const int width = digits + 5;
   const auto old_prec = cout.precision();
   cout.precision(digits);

   std::string method;
   if (_integration_weights[subint].size() == 0) {
      if (_lin_eq_solver[subint].SV_is_used())
         method = "SV";
      else
         method = "LU";
   }
   else {
      method = "CC";
   }
   cout << "using " << method;

   if (method != "CC") {
      cout << "    LU_ratio: " << setw(width)
        << _lin_eq_solver[subint].LU_ratio();

      if (_lin_eq_solver[subint].small_SV_ratios().size() != 0) {
         cout << "    small_SV_ratios: ";
         for (auto& ratio : _lin_eq_solver[subint].small_SV_ratios()) {
            cout << setw(width) << ratio << "  ";
         }
      }
   }

   cout << endl;
   cout.precision(old_prec);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_print_levin_info(size_t subint,
   const vector_arg& F, const vector_arg& P) const
{
   using std::cout;
   using std::endl;
   using std::setw;

   cout << "# ";
   _print_basic_info();
   cout << "# ";
   _print_subgrid_info(subint);
   cout << "# ";
   _print_method_info(subint);
   cout << "#" << endl;

   const int digits = 4;
   const int width = digits + 8;
   const auto old_prec = cout.precision();
   cout.precision(digits);

   cout << "#" << setw(width-1) << "z" << setw(width)
        << "u" << setw(width)
        << "f_1" << setw(width) << "f_2" << setw(width)
        << "h_1" << setw(width) << "h_3" << endl;

   // iterator for u values on the grid
   const auto offset = static_cast<long>(grid().info().int_lim_indices(subint));
   auto u_it = grid().base_grid().values().begin() + offset;

   const index_t N = grid().info().n_points(subint);

   for (index_t k = 0; k < N; k++, u_it++) {
      const double u = *u_it;
      cout << setw(width)
         << grid().inverse_transform(u) << setw(width)
         << u << setw(width)
         << F[k] << setw(width)
         << F[N + k] << setw(width)
         << P[k] << setw(width)
         << P[N + k]
         << endl;
   }
   cout << endl;

   cout.precision(old_prec);
}

//------------------------------------------------------------------------------
void Bessel_integrator_impl::_print_levin_code(size_t subint,
   const vector_arg& F, const vector_arg& P) const
{
   using std::cout;
   using std::endl;
   using std::setw;

   cout << "// ";
   _print_basic_info();
   cout << "// ";
   _print_subgrid_info(subint);
   cout << "// ";
   _print_method_info(subint);
   cout << "//" << endl;

   const auto old_prec = cout.precision();
   cout.precision(16);

   cout << "// grid construction parameters:\n";

   cout << "const Grid_1d::grid_parameters par = {";
   for (size_t i = 0; i < grid().parameters().size() - 1; ++i) {
      cout << grid().parameters()[i] << ", ";
   }
   cout << grid().parameters().back() << "};\n";

   cout << "const vector_d z_limits = {";
   for (size_t i = 0; i < grid().info().interval_limits().size() - 1; ++i) {
      cout << grid().info().interval_limits()[i] << ", ";
   }
   const double z_end = grid().back();
   if (z_end == Grid_1d::infinity) {
      cout << "Grid_1d::infinity};\n";
   } else {
      cout << grid().back() << "};\n";
   }

   cout << "const index_vector n_points = {";
   for (size_t i = 0; i < grid().info().n_points().size() - 1; ++i) {
      cout << grid().info().n_points()[i] << ", ";
   }
   cout << grid().info().n_points().back() << "};\n\n";

   // discretized functions
   const index_t N = grid().info().n_points(subint);

   cout << "const grid_vector f1_grid = {";
   for (index_t i = 0; i < N - 1; ++i) {
      cout << F[i] << ", ";
   }
   cout << F[N - 1] << "};\n\n";

   cout << "const grid_vector f2_grid = {";
   for (index_t i = N; i < 2*N - 1; ++i) {
      cout << F[i] << ", ";
   }
   cout << F[2*N - 1] << "};\n\n";

   cout << "const grid_vector h1_grid = {";
   for (index_t i = 0; i < N - 1; ++i) {
      cout << P[i] << ", ";
   }
   cout << P[N - 1] << "};\n\n";

   cout << "const grid_vector h2_grid = {";
   for (index_t i = N; i < 2*N - 1; ++i) {
      cout << P[i] << ", ";
   }
   cout << P[2*N - 1] << "};\n\n";

   cout.precision(old_prec);
}

} // namespace bestlime
