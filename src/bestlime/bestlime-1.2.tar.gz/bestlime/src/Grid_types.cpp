//------------------------------------------------------------------------------
/// \file  Grid_types.cpp
/// \brief Constructors of classed derived from Grid_1d.
//
// Author(s): Riccardo Nagar and Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Grid_types.hpp"

#include <stdexcept>
#include <iostream>
#include <iomanip>

namespace bestlime
{

//------------------------------------------------------------------------------
// Linear_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Linear_grid::Linear_grid(const index_vector& n_pts,
                         const vector_d& interv_limits)
   : Grid_1d(n_pts, interv_limits, vector_d())
{
   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Log_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Log_grid::Log_grid(const index_vector& n_pts,
                   const vector_d& interv_limits)
   : Grid_1d(n_pts, interv_limits, vector_d())
{
   // Check interval limits
   if (interv_limits.front() <= 0. || interv_limits.back() == infinity)
      throw std::logic_error("Log_grid: Interval limits are inconsistent with allowed range 0 < z < infinity.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Power_law_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Power_law_grid::Power_law_grid(const index_vector& n_pts,
                               const vector_d& interv_limits,
                               const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits, parameters)
{
   if (parameters.size() != 1)
      throw std::logic_error("Power_law_grid: wrong number of parameters.");

   _p = parameters[0];
   _inv_p = 1. / _p;

   if (_p <= 0.0)
      throw std::logic_error("Power_law_grid: Power p must be positive.");

   // Check interval limits
   if (interv_limits.front() <= 0. || interv_limits.back() == infinity)
      throw std::logic_error("Power_law_grid: Interval limits are inconsistent with allowed range 0 < z < infinity.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Inv_power_law_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Inv_power_law_grid::Inv_power_law_grid(const index_vector& n_pts,
                                       const vector_d& interv_limits,
                                       const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits, parameters)
{
   if (parameters.size() != 2)
      throw std::logic_error("Inv_power_law_grid: wrong number of parameters.");

   _p  = parameters[0];
   _z0 = parameters[1];
   _inv_p = 1. / _p;

   if (_p <= 0.0)
      throw std::logic_error("Inv_power_law_grid: Power p must be positive.");

   // Check lower interval limit
   if (interv_limits.front() <= -_z0)
      throw std::logic_error("Inv_power_law_grid: Lower interval limit must be larger than -z0.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Log_pow_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Log_pow_grid::Log_pow_grid(const index_vector& n_pts,
                           const vector_d& interv_limits,
                           const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits, parameters)
{
   if (parameters.size() != 3)
      throw std::logic_error("Log_pow_grid: wrong number of parameters.");

   _p    = parameters[0];
   _z_lo = parameters[1];
   _z_hi = parameters[2];

   if (_p <= 0.0)
      throw std::logic_error("Log_pow_grid: Parameter p must be positive.");

   _1_p = 1. / _p;

   // Checks that z_lo < z_hi.
   if (_z_lo >= _z_hi)
      throw std::logic_error("Log_pow_grid: Parameter z_hi must be larger than z_lo.");

   // Checks that all z > - z_lo
   if (interv_limits.front() <= -_z_lo)
      throw std::logic_error("Log_pow_grid: Lower interval limit must be larger than -z_lo.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Exp_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Exp_grid::Exp_grid(const index_vector& n_pts,
                   const vector_d& interv_limits,
                   const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits,parameters)
{
   if (parameters.size() != 1)
      throw std::logic_error("Exp_grid: wrong number of parameters.");

   _m_over_4 = 0.25 * parameters[0];

   if (_m_over_4 <= 0.0)
      throw std::logic_error("Exp_grid: Parameter m must be positive.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Exp_sqrt_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Exp_sqrt_grid::Exp_sqrt_grid(const index_vector& n_pts,
                             const vector_d& interv_limits,
                             const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits, parameters)
{
   if (parameters.size() != 1)
      throw std::logic_error("Exp_sqrt_grid: wrong number of parameters.");

   _m_over_2 = 0.5 * parameters[0];
   _m_over_4 = 0.5 * _m_over_2;

   if (_m_over_2 <= 0.0)
      throw std::logic_error("Exp_sqrt_grid: Parameter m must be positive.");

   // Checks that all z > - 2/m
   if (interv_limits.front() <= - 1./_m_over_2)
      throw std::logic_error("Exp_sqrt_grid: Lower interval limit must be larger than -2/m.");

   _initialize_base_grid(n_pts, interv_limits);
}

//------------------------------------------------------------------------------
// Gauss_grid constructor
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
Gauss_grid::Gauss_grid(const index_vector& n_pts,
                       const vector_d& interv_limits,
                       const vector_d& parameters)
   : Grid_1d(n_pts, interv_limits, parameters)
{
   if (parameters.size() != 1)
      throw std::logic_error("Gauss_grid: wrong number of parameters.");

   _m = parameters[0];
   _m_over_2 = 0.5 * _m;

   if (_m <= 0.0)
      throw std::logic_error("Gauss_grid: Parameter m must be positive.");

   // Checks that all z > - 1/(2*m)
   if (interv_limits.front()*interv_limits.front() <= - 0.5/_m)
      throw std::logic_error("Gauss_grid: Lower interval limit must be larger than -1/(2m).");

   _initialize_base_grid(n_pts, interv_limits);
}

} // namespace bestlime
