//------------------------------------------------------------------------------
/// \file  Linear_solver.cpp
/// \brief Implementation of class Linear_solver.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Linear_solver.hpp"

#include <functional>
#include <exception>
#include <stdexcept>

/// \cond NO_DOXYGEN
namespace bestlime
{

//------------------------------------------------------------------------------
// Public member functions
//------------------------------------------------------------------------------
Linear_solver::Linear_solver(const Eigen::Ref<const grid_matrix>& A,
                             double r_LU_max,
                             double r_SV_max)
   : _dim{A.cols()}, _r_LU_max{r_LU_max}, _r_SV_max{r_SV_max}
{
   if (_dim == 0)
      throw std::invalid_argument("Linear_solver: matrix of size zero is not allowed.");
   if (A.rows() != A.cols())
      throw std::invalid_argument("Linear_solver: matrix A must be square.");

   if (r_LU_max < 0. || r_LU_max > 1.)
      throw std::invalid_argument("Linear_solver: r_LU_max is outside its allowed range.");
   if (r_SV_max <= 0. || r_SV_max >= 1.)
      throw std::invalid_argument("Linear_solver: r_SV_max is outside its allowed range.");

   _lu_dec.compute(A);
   _ratio_LU = _compute_ratio_LU();
   _use_SV = (_ratio_LU <= r_LU_max);

   if (_use_SV) {
      // LU decomposition is no longer needed
      _lu_dec = Eigen::PartialPivLU<grid_matrix>();

      _sv_dec.compute(A, Eigen::ComputeThinU | Eigen::ComputeThinV);
      _sv_dec.setThreshold(r_SV_max);
   }
}

//------------------------------------------------------------------------------
grid_vector Linear_solver::solve(const Eigen::Ref<const grid_vector>& b) const
{
   if (b.size() != _dim)
      throw std::invalid_argument("Linear_solver::solve(): incorrect size of the vector.");

   if (_use_SV) {
      return _sv_dec.solve(b);
   } else {
      return _lu_dec.solve(b);
   }
}

//------------------------------------------------------------------------------
vector_d Linear_solver::small_SV_ratios() const
{
   vector_d result(0);

   if (_use_SV == false)
      return result;            // return empty vector

   const double S_max = _sv_dec.singularValues().maxCoeff();

   if (S_max == 0.)
      // all singular values are zero
      return vector_d(static_cast<size_t>(_dim), 0.);

   const grid_vector ratios {_sv_dec.singularValues() / S_max};

   for (double r_ii : ratios) {
      if (r_ii < _r_SV_max)
         result.push_back(r_ii);
   }

   return result;
}

//------------------------------------------------------------------------------
vector_d Linear_solver::diagonal() const
{
   if (_use_SV) {
      return convert_to_vector_d(_sv_dec.singularValues());
   } else {
      return convert_to_vector_d(_lu_dec.matrixLU().diagonal());
   }
}

//------------------------------------------------------------------------------
// Private member functions
//------------------------------------------------------------------------------
double Linear_solver::_compute_ratio_LU() const
{
   // array of values |U_ii|
   const Eigen::ArrayXd U_abs {_lu_dec.matrixLU().diagonal().array().abs()};

   const double U_min = U_abs.minCoeff();

   if (U_min == 0.)
      return 0.;
   else
      return U_min / U_abs.maxCoeff();
}

} // namespace bestlime
/// \endcond
