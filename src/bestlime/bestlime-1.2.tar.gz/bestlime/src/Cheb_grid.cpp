//------------------------------------------------------------------------------
/// \file  Cheb_grid.cpp
/// \brief Implementation of class Cheb_grid.
//
// Author(s): Riccardo Nagar
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Cheb_grid.hpp"

#include <cmath>
#include <cassert>
#include <iostream>

namespace bestlime
{

//------------------------------------------------------------------------------
Cheb_grid::Cheb_grid(index_t N)
   : _n{N},
     _sin_pi2N_grid{_make_sin_pi2N_grid()},
     _sin2_grid{_make_sin2_grid()},
     _clenshaw_weights{_make_clenshaw_weights()}
{
   assert(N > 1);
}

//------------------------------------------------------------------------------
grid_matrix Cheb_grid::diff_matrix() const
{
   grid_matrix result(_n + 1, _n + 1);

   double sign_i = 1.;
   for (index_t i = 0; i <= _n; ++i) {
      double sign_j = 1.;
      for (index_t j = 0; j <= _n; ++j) {
         if (i == j) {
            if (i == 0) {
               result(i, i) = (2.*static_cast<double>(_n*_n) + 1.) / 6.;
            } else if (i == _n) {
               result(i, i) = - (2.*static_cast<double>(_n*_n) + 1.) / 6.;
            } else {
               result(i, i) = - 0.5 * _cos_pi2N(2*i) / _sin2_grid[i];
            }
         } else {
            result(i, j) = sign_i * sign_j / _grid_diff(i, j);
         }

         if ((j == 0 || j == _n) && (i != j)) {
            result(i, j) *= 0.5;       // first and last row, except diagonals
         }

         if ((i == 0 || i == _n) && (i != j)) {
            result(i, j) *= 2.0;
         }

         sign_j *= -1.;
      }
      sign_i *= -1.;
   }

   return result;
}

//------------------------------------------------------------------------------
// NOTE: The analytic expressions implemented here have been obtained by
// applying the method described in section 2 of
//       M. Diehl, R. Nagar, F. J. Tackmann,
//       ChiliPDF: Chebyshev interpolation library for PDFs
//       arXiv:2112.09703
// to the second instead of the first derivative.
//------------------------------------------------------------------------------
grid_matrix Cheb_grid::diff_matrix_squared() const
{
   grid_matrix result(_n + 1, _n + 1);

   const double n2 = static_cast<double>(_n*_n);

   double sign_i = 1.;
   for (index_t i = 0; i <= _n; ++i) {
      double sign_j = 1.;
      for (index_t j = 0; j <= _n; ++j) {
         if (i == j) {
            if (i == 0 || i == _n) {
               result(i, i) = (n2*n2 - 1.) / 15.;
            } else {
               result(i, i)
                  = - ((n2 - 1.)/3. + 1. / _sin2_grid[i]) / _sin2_grid[i];
            }
         } else {
            const double t_ij = _grid_diff(i, j);
            if (i == 0) {
               result(i, j) =   (2./3.) * (1. + 2.*n2 - 6. / t_ij) / t_ij;
            } else if (i == _n) {
               result(i, j) = - (2./3.) * (1. + 2.*n2 + 6. / t_ij) / t_ij;
            } else {
               result(i, j) = - (3.*_sin2_grid[i] + _sin2_grid[j] + t_ij*t_ij)
                  / (2.*_sin2_grid[i] * t_ij*t_ij);
            }
            result(i, j) *= sign_i * sign_j;
         }

         if ((j == 0 || j == _n) && (i != j)) {
            result(i, j) *= 0.5;       // first and last row, except diagonals
         }

         sign_j *= -1.;
      }
      sign_i *= -1.;
   }

   return result;
}

//------------------------------------------------------------------------------
grid_matrix Cheb_grid::cheb_matrix() const
{
   grid_matrix result(_n + 1, _n + 1);

   for (index_t i = 0; i <= _n; ++i) {
      for (index_t j = i; j <= _n; ++j) {
         result(i, j) = _cos_pi2N(2*i*j);
         if (i == 0 || i == _n)      // first and last row
            result(i, j) *= 0.5;
         if (j == 0 || j == _n)      // first and last column
            result(i, j) *= 0.5;
         result(j, i) = result(i, j);
      }
   }

   return result;
}

//------------------------------------------------------------------------------
grid_vector Cheb_grid::lin_transf_grid(double a, double b) const
{
   grid_vector result(_n + 1);
   const double diff = a - b;
   const double avg = 0.5 * (a + b);

   index_t i = 0;
   // regions close to interval end points:
   for ( ; 2*i <= _n/2; ++i) {
      const double delta = diff * _sin_pi2N_grid[i]*_sin_pi2N_grid[i];
      result[i] = a - delta;           // (1 - cos(z)) / 2 = sin^2 (z/2)
      result[_n - i] = b + delta;      // (1 + cos(pi-z)) / 2 = sin^2 (z/2)
   }
   // central region:
   for ( ; 2*i <= _n; ++i) {
      const double delta = 0.5 * diff * _cos_pi2N(2*i);
      result[i] = avg + delta;
      result[_n - i] = avg - delta;
   }

   return result;
}

//------------------------------------------------------------------------------
void Cheb_grid::print() const
{
   for (index_t i = 0; i <= _n; ++i) {
      std::cout << (*this)[i] << std::endl;
   }
}

//------------------------------------------------------------------------------
// Private member functions.
//------------------------------------------------------------------------------
// Evaluates grid with values sin(i pi /(2N)).
//
grid_vector Cheb_grid::_make_sin_pi2N_grid() const
{
   constexpr double pi_2 = 1.5707963267948966;
   constexpr double sqrt1_2 = 0.70710678118654752;

   grid_vector result(_n + 1);
   const double pi_2N
      = pi_2 / static_cast<double>(_n);     // pi/(2 N)

   result[0] = 0.0;
   result[_n] = 1.0;

   index_t i = 1;
   double i_d = 1.;
   for ( ; 2*i < _n; ++i, i_d += 1.) {
      result[i] = sin(i_d * pi_2N);
      result[_n - i] = cos(i_d * pi_2N); // sin((pi - z)/2) = cos(z/2)
   }

   // only for even N
   if (2*i == _n)
      result[i] = sqrt1_2;

   return result;
}

//------------------------------------------------------------------------------
// Evaluates grid with values sin^2 (i pi /N).
//
grid_vector Cheb_grid::_make_sin2_grid() const
{
   grid_vector result(_n + 1);

   for (index_t i = 0; i <= _n; ++i) {
      const double sin = _sin_pi2N(2*i);
      result[i] = sin * sin;
   }

   return result;
}

//------------------------------------------------------------------------------
// Evaluates Clenshaw-Curtis weights for grid on [-1,1].
//
grid_vector Cheb_grid::_make_clenshaw_weights() const
{
   grid_vector weights(_n + 1);
   const double N_d = static_cast<double>(_n);

   index_t i = 0;
   for ( ; 2*i <= _n; ++i) {
      double weight = 0.5;                      // first term in sum over j
      double j_d = 2.;
      for (index_t j = 2; j < _n; j += 2, j_d += 2.) {
         weight += _cos_pi2N(2*i*j) / (1. - j_d * j_d);
      }
      if (_n % 2 == 0)                          // last term in sum for even N
         weight += 0.5 * _cos_pi2N(2*i*_n) / (1. - N_d * N_d);

      if (i == 0)
         weight *= 0.5;            // factor 1/2 for weight at end point
      weight *= 4. / N_d;
      weights[i] = weight;

      // use symmetry of weights w.r.t. reflection around N/2
      weights[_n - i] = weight;
   }

   return weights;
}

//------------------------------------------------------------------------------
// Evaluates cos(k pi/(2N)).
//
double Cheb_grid::_cos_pi2N(index_t k) const
{
   const index_t j = k % (4*_n);        // 0 <= j < 4*N

   if (j <= _n) {                      // first quadrant
      return _sin_pi2N_grid[_n - j];   // cos(z) = sin(pi/2 - z)
   }
   else if (j <= 2*_n) {               // second quadrant
      return -_sin_pi2N_grid[j - _n];
   }
   else if (j <= 3*_n) {               // third quadrant
      return -_sin_pi2N_grid[3*_n-j];
   }
   else {                              // fourth quadrant
      return _sin_pi2N_grid[j - 3*_n];
   }
}

//------------------------------------------------------------------------------
// Evaluates sin(k pi/(2N)).
//
double Cheb_grid::_sin_pi2N(index_t k) const
{
   const index_t j = k % (4*_n);        // 0 <= j < 4*N

   if (j <= _n) {                      // first quadrant
      return _sin_pi2N_grid[j];
   }
   else if (j <= 2*_n) {               // second quadrant
      return _sin_pi2N_grid[2*_n - j];
   }
   else if (j <= 3*_n) {               // third quadrant
      return -_sin_pi2N_grid[j - 2*_n];
   }
   else {                              // fourth quadrant
      return -_sin_pi2N_grid[4*_n - j];
   }
}

//------------------------------------------------------------------------------
// Evaluates difference  cos(i pi/N) - cos(j pi/N)  of grid values
// using  cos x - cos y = - 2 sin((x+y)/2) sin((x-y)/2).
//
double Cheb_grid::_grid_diff(index_t i, index_t j) const
{
   return (i > j) ? -2.0 * _sin_pi2N(i + j) * _sin_pi2N(i - j)
                   : 2.0 * _sin_pi2N(i + j) * _sin_pi2N(j - i);
}

} // namespace bestlime
