//------------------------------------------------------------------------------
/// \file  Bessel_integrator_special_impl.cpp
/// \brief Implementation of class Bessel_integrator_special_impl.
//
// Author(s): Oskar Grocholski, Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Bessel_integrator_special_impl.hpp"
#include "bestlime/Grid_1d.hpp"

#include <cmath>
#include <cassert>
#include <exception>
#include <algorithm>
#include <iostream>
#include <iomanip>

#include <gsl/gsl_sf_bessel.h>

namespace bestlime
{

//------------------------------------------------------------------------------
// Public member functions
//------------------------------------------------------------------------------
Bessel_integrator_special_impl::Bessel_integrator_special_impl(
   const Grid_1d& grid, double nu,
   bool use_quadrature, double r_LU_max, double r_SV_max)
   : _nu{nu}, _integrator{grid, nu + 2.0, use_quadrature, r_LU_max, r_SV_max}
{
   if (nu < 0.)
      throw std::invalid_argument("Bessel_integrator_special_impl: value of nu must not be negative.");

   if ((grid.front() != 0.0) || (grid.back() != Grid_1d::infinity))
      throw std::invalid_argument("Bessel_integrator_special_impl: interpolation grid must go from 0.0 to Grid_1d::infinity.");

   // weights are not used if nu = 0.
   if (_nu != 0.) {
      _weights_nu.resize(z_values().size());
      std::transform(z_values().begin(), z_values().end(), _weights_nu.begin(),
                     [this](double z)
                        { return pow(_integrator._z_1pz(z), _nu); }
                     );
   }

   _make_M_matrices();
}

//------------------------------------------------------------------------------
grid_vector Bessel_integrator_special_impl::weights_J_nu(
   double q, bool weighted)
{
   const index_t N = z_values().size();
   grid_vector result(N);

   _integrator._update_q(q);

   for (index_t i = 0; i < N-1; i++) {
      result[i] = _integrator._integral(_make_F_basis_vec(i, weighted));
   }

   // last column of matrix M is zero, see _make_M_matrices()
   result[N-1] = 0.;

   return result * (1. / (q*q));
}

//------------------------------------------------------------------------------
// Private member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

void Bessel_integrator_special_impl::_check_fgrid(
   const grid_vector& f_grid) const
{
   if (f_grid.size() != z_values().size()) {
      throw std::invalid_argument("Bessel_integrator_special_impl: incorrect size of a function grid in integration call.");
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_special_impl::_integrate(
   const grid_vector& f_grid, double q, bool weighted, int verbose)
{
   _check_fgrid(f_grid);
   _integrator._update_q(q);

   return _integrator._integral(_make_F_vec(f_grid, weighted), verbose) / (q*q);
}


//------------------------------------------------------------------------------
vector_d Bessel_integrator_special_impl::_integrate(
   const std::vector<grid_vector>& f_grids, double q, bool weighted)
{
   vector_d result;
   result.reserve(f_grids.size());

   const index_t N = z_values().size();

   if (f_grids.size() < static_cast<size_t>(N)) {
      const double q2 = q*q;
      _integrator._update_q(q);

      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back(
            _integrator._integral(_make_F_vec(f_grid, weighted)) / q2);
      }
   } else {
      // use q-dependent integration weights
      // omit the value at z=infinity in the weights and f_grid vectors
      const index_t N_red = N-1;
      const grid_vector weights {weights_J_nu(q, weighted).head(N_red)};

      for (const grid_vector& f_grid : f_grids) {
         _check_fgrid(f_grid);
         result.push_back(f_grid.head(N_red).dot(weights));
      }
   }

   return result;
}

//------------------------------------------------------------------------------
std::vector<grid_vector> Bessel_integrator_special_impl::_make_F_vec(
   const grid_vector& f_grid, bool weighted) const
{
   const size_t n_subgrids = grid().info().n_intervals();

   std::vector<grid_vector> result;
   result.reserve(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      const index_t offset = grid().info().int_lim_indices(i);

      // values of f on subgrid
      grid_vector f_subgrid = f_grid.segment(offset, N);

      // replace the function value at z = infinity
      // This guarantees correct result of later multiplication by zero
      // if the original value is not finite.
      if (i == n_subgrids - 1) {
         f_subgrid.reverse()[0] = 0.;
      }

      // rescale with weights using Eigen's component-wise multiplication
      if ((_nu != 0.) && (weighted == false)) {
         f_subgrid = _weights_nu.segment(offset, N).array() * f_subgrid.array();
      }

      result.emplace_back(grid_vector::Zero(2*N));

      // matrix multiplication f_1 = M * f
      result.back().head(N) = _M_matrices[i] * f_subgrid;
   }

   return result;
}

//------------------------------------------------------------------------------
std::vector<grid_vector> Bessel_integrator_special_impl::_make_F_basis_vec(
   index_t grid_point, bool weighted) const
{
   const size_t n_subgrids = grid().info().n_intervals();

   std::vector<grid_vector> result;
   result.reserve(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      result.emplace_back(grid_vector::Zero(2*N));

      if (grid().base_grid().index_in_subinterval(grid_point, i)) {
         // value of basis function at the specified grid point
         double value = 1.;

         // rescale value
         if ((_nu != 0.) && (weighted == false)) {
            value *= _weights_nu[grid_point];
         }

         const index_t index_on_subgrid
            = grid_point -  grid().info().int_lim_indices(i);

         result.back().head(N) = value * _M_matrices[i].col(index_on_subgrid);
      }
   }

   return result;
}

//------------------------------------------------------------------------------
void Bessel_integrator_special_impl::_make_M_matrices()
{
   const size_t n_subgrids = grid().info().n_intervals();
   const grid_vector z_values = grid().values();

   _M_matrices.resize(n_subgrids);

   for (size_t i = 0; i < n_subgrids; i++) {
      const index_t N = grid().info().n_points(i);
      const index_t offset = grid().info().int_lim_indices(i);

      std::pair<grid_matrix, grid_matrix> DD = grid().diff_matrices(i);

      for (index_t j = 0; j < N; j++) {
         const double z = z_values[offset + j];

         if (z == Grid_1d::infinity) {
            DD.first.row(j) *= 0.;
            DD.second.row(j) *= 0.;
         } else {
            DD.first.row(j) *= (z * _D1_coeff(z));
            DD.second.row(j) *= (z*z);
         }
      }

      _M_matrices[i] = DD.first + DD.second;

      // Add the diagonal part.
      for (index_t j = 0; j < N; j++) {
         _M_matrices[i](j, j) += _D0_coeff(z_values[offset + j]);
      }

      // Multiply columns with 1 / (1+z)^2.
      // Equivalent to rescaling the integrand by this factor.
      for (index_t j = 0; j < N; j++) {
         const double inv_1pz = _integrator._1_1pz(z_values[offset + j]);
         _M_matrices[i].col(j) *= (inv_1pz * inv_1pz);
      }
   }
}

//------------------------------------------------------------------------------
double Bessel_integrator_special_impl::_D1_coeff(double z) const
{
   return 1. - 2.*_nu - 2.*(_nu + 2.) * _integrator._1_1pz(z);
}

//------------------------------------------------------------------------------
double Bessel_integrator_special_impl::_D0_coeff(double z) const
{
   const double r = _integrator._1_1pz(z);

   return _nu*_nu - 1. + (2.*_nu + 1.) * (_nu + 2.) * r
          + (_nu + 1.) * (_nu + 2.) * r * r;
}

} // namespace bestlime
