//------------------------------------------------------------------------------
/// \file  Bessel_integrator.cpp
/// \brief Template instantiations of class Bessel_integrator.
//
// Author(s): Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Bessel_integrator.hpp"

namespace bestlime
{

template class Bessel_integrator<Linear_grid>;
template class Bessel_integrator<Power_law_grid>;
template class Bessel_integrator<Inv_power_law_grid>;
template class Bessel_integrator<Log_pow_grid>;
template class Bessel_integrator<Exp_grid>;
template class Bessel_integrator<Exp_sqrt_grid>;
template class Bessel_integrator<Gauss_grid>;


} // namespace bestlime
