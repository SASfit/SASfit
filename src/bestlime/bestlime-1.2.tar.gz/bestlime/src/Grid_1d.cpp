//------------------------------------------------------------------------------
/// \file  Grid_1d.cpp
/// \brief Definitions of class Grid_1d.
//
// Author(s): Riccardo Nagar and Markus Diehl
//
// Copyright (C) 2024  ChiliPDF Collaboration
//
// This file is part of BestLime. BestLime is distributed under the terms of the
// GNU General Public License version 3 supplemented with academic attribution
// terms. See the LICENSE.md file that comes with this distribution for details.
//
// BestLime is being developed as part of a scientific research effort.
// Please follow the guidelines for academic use in the README.md file.
//------------------------------------------------------------------------------

#include "bestlime/Grid_1d.hpp"

#include <cmath>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <typeinfo>

/// \cond NO_DOXYGEN
namespace bestlime
{

//------------------------------------------------------------------------------
// Grid_1d public member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
double Grid_1d::operator[](index_t i) const
{
   // return original interval limit if i corresponds to one of their indices,
   // to avoid rounding errors in inverse_transform(transform(...))
   for (size_t j = 0; j < info().int_lim_indices().size(); ++j) {
      if (i == info().int_lim_indices(j))
         return info().interval_limits(j);
   }

   return inverse_transform(_base_grid[i]);
}

//------------------------------------------------------------------------------
void Grid_1d::print_info() const
{
   std::cout << " total points:           " << info().grid_size() << std::endl;
   std::cout << " points per subinterval: ";
   for (const index_t& npts : info().n_points()) {
      std::cout << npts << "\t";
   }
   std::cout << std::endl;
   std::cout << " interval limits:        ";
   for (const double& limit : info().interval_limits()) {
      if (limit == Grid_1d::infinity) {
         std::cout << "infinity" << "\t";
      } else {
         std::cout << limit << "\t";
      }
   }
   std::cout << std::endl;
}

//------------------------------------------------------------------------------
void Grid_1d::print_grid() const
{
   std::cout << std::setprecision(3);

   std::cout << " test = 1 - u(z(u)) / u\n\n";

   std::cout << "         z           u       du/dz         test\n";

   for (index_t i = 0; i < size(); ++i) {
      const double z = (*this)[i];
      const double u = base_grid()[i];
      std::cout << std::setw(10) << z << "  "
                << std::setw(10) << u << "  "
                << std::setw(10) << jacobian(u) << "  "
                << std::setw(11)
                << 1.0 - variable_transform(inverse_transform(u)) / u
                << std::endl;
   }

   std::cout << std::endl;
}

//------------------------------------------------------------------------------
grid_matrix Grid_1d::diff_matrix(size_t k) const
{
   if (k >= info().n_intervals())
      throw std::invalid_argument("Grid_1d::diff_matrix(): invalid subinterval number.");

   grid_matrix result{base_grid().basic_grid(k).diff_matrix()};

   // negative factor from the linear transformation from basic Chebyshev
   // grids to grids in u
   const double scaling_fact = 2. / (base_grid().info().interval_limits(k)
                                   - base_grid().info().interval_limits(k+1));

   const index_t offset = info().int_lim_indices(k);

   // multiply rows with scaling factor and Jacobian du/dz
   for (index_t i = 0; i < info().n_points(k); ++i) {
      result.row(i) *= (scaling_fact * jacobian(base_grid()[offset + i]));
   }

   return result;
}

//------------------------------------------------------------------------------
std::pair<grid_matrix, grid_matrix> Grid_1d::diff_matrices(size_t k) const
{
   if (k >= info().n_intervals())
      throw std::invalid_argument("Grid_1d::diff_matrix_2(): invalid subinterval number.");

   grid_matrix first_deriv{base_grid().basic_grid(k).diff_matrix()};
   grid_matrix second_deriv_1{first_deriv};
   grid_matrix second_deriv_2{base_grid().basic_grid(k).diff_matrix_squared()};

   // negative factor from the linear transformation from basic Chebyshev
   // grids to grids in u
   const double scaling_fact = 2. / (base_grid().info().interval_limits(k)
                                   - base_grid().info().interval_limits(k+1));

   const index_t offset = info().int_lim_indices(k);

   grid_matrix result_1;

   // multiply rows with scaling factor and Hessian or Jacobian
   for (index_t i = 0; i < info().n_points(k); ++i) {
      const double u = base_grid()[offset + i];
      const double jac_fact = scaling_fact * jacobian(u);

      first_deriv.row(i) *= jac_fact;
      second_deriv_1.row(i) *= (scaling_fact * hessian(u));
      second_deriv_2.row(i) *= (jac_fact * jac_fact);
   }

   return {first_deriv, second_deriv_1 + second_deriv_2};
}

//------------------------------------------------------------------------------
// Grid_1d protected member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
void Grid_1d::_initialize_base_grid(const index_vector& n_pts,
                                    const vector_d& interv_limits_in_z)
{
   // transform interval limits
   vector_d transformed_limits(interv_limits_in_z.size());
   for (size_t i = 0; i < interv_limits_in_z.size(); ++i) {
      transformed_limits[i] = variable_transform(interv_limits_in_z[i]);
   }

   _base_grid = Composite_grid(n_pts, transformed_limits);
}

//------------------------------------------------------------------------------
// Grid_1d private member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
grid_vector Grid_1d::_grid_values(const Composite_grid& base_grid,
                                  const Subint_info& orig_info) const
{
   grid_vector result(base_grid.size());

   for (index_t i = 0; i < base_grid.size(); ++i) {
      result[i] = inverse_transform(base_grid[i]);
   }

   // see comment in definition of operator[]
   for (size_t j = 0; j < orig_info.int_lim_indices().size(); ++j) {
      result[orig_info.int_lim_indices(j)] = orig_info.interval_limits(j);
   }

   return result;
}

//------------------------------------------------------------------------------
void Grid_1d::_check_limits_ascending(const vector_d& limits) const
{
   if (limits.size() < 2)
      throw std::logic_error("Grid_1d: Vector of interval limits must have at least 2 elements.");

   for (size_t i = 1; i < limits.size(); ++i) {
      if (limits.at(i-1) >= limits.at(i))
         throw std::logic_error("Grid_1d: Interval_limits must be strictly ascending.");
   }
}

//------------------------------------------------------------------------------
// Grid_1d non-member functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
bool operator==(const Grid_1d& lhs, const Grid_1d& rhs)
{
   return (lhs.parameters() == rhs.parameters())
          && (lhs.info() == rhs.info())
          && (typeid(lhs) == typeid(rhs));
}

//------------------------------------------------------------------------------
std::ostream& operator<<(std::ostream& ostream, const Grid_1d& grid)
{
   ostream << std::string( "[");

   for (const double& limit : grid.info().interval_limits()) {
      if (limit == Grid_1d::infinity) {
         ostream << "infinity";
      } else {
         ostream << limit;
      }
      if (limit != grid.back())
         ostream << std::string(", ");
   }
   ostream << std::string("]_(");

   size_t i = 0;
   for ( ; i < grid.info().n_points().size() - 1; ++i) {
      ostream << grid.info().n_points(i) << std::string(", ");
   }
   ostream << grid.info().n_points(i) << std::string(")");

   return ostream;
}

} // namespace bestlime
/// \endcond
