<!-- To view this file in a formatted version with hyperlinks, point your browser to doc/html/index.html -->

[TOC]

Quick Start
============

The following is needed to install and run `BestLime`:

 * a C++14 compiler
 * [CMake][CMake manual] (>= 3.16)
 * the [GNU Scientific Library][GSL documentation] (GSL >= 2.0)

(See [Requirements] below for more details.)

To start, create a `build` directory at the root of the `BestLime` source
tree and call CMake from there:

    $> mkdir build && cd build
    build$> cmake ..

_Watch the CMake output_ for any warnings or errors about missing dependencies.
The output also specifies the current directory foreseen for installation (see
[Installing]).

Once CMake has found everything you need, you can build the `BestLime` library
and the example programs by typing

    build$> make bestlime
    build$> make examples

To install the library and header files on your system, type

    build$> make install

If something does not work, or if you wish to change settings such as the
installation directory, please consult the following detailed instructions.


Detailed Instructions
======================

Requirements                                                     {#requirements}
-------------

BestLime _requires_ the following tools and external packages:

 Name         | Required | Recommended | Comments
--------------|:--------:|:-----------:|----------------------------------------
 CMake        | >= 3.16  |   >= 3.22   | Build system
 C++ compiler | C++14    |   C++14     | Supported: GCC >= 8 and Clang >= 3.9
 GSL          | >= 2.0   |   2.71      | GNU Scientific Library

 * The **required version** (2nd column) is enforced (if known). Lower versions
   do not work (or are unlikely to work) and are not supported.

 * The **recommended version** (3rd column) is not enforced but should be used
   by default if available. It is actively supported and tested. Lower versions
   should still work but are no longer actively supported.

### Build Toolchain ###

#### CMake ####

BestLime uses CMake for its build system, as discussed below under
[Configuration with CMake].

 * On Linux, CMake is part of the standard tool chain. On Debian/Ubuntu, the
   relevant package is called `cmake`. (The `ccmake` and `cmake-gui` frontends
   are provided by the `cmake-curses-gui` and `cmake-qt-gui` packages.)

 * On Mac, a binary distribution can be downloaded from the [CMake homepage].
   Homebrew and MacPorts packages are also available (your mileage may vary).

#### C++14 ####

BestLime requires a C++ compiler that conforms to the C++14 standard. The
supported and tested compilers are:

 * GCC 8 or later
 * Clang 3.9 or later

Other C++14-conformant compilers should also work but have not been tested.  You
may possibly get a large number of warning messages with these.  If the warnings
are from the Eigen library, you may wish to turn them off by editing the files
Eigen_core.hpp or Eigen_solvers.hpp accordingly.

Note that on Mac, AppleClang version numbers differ from the mainstream Clang
versions they are derived from. The minimum version for AppleClang is 8.0, which
comes with XCode version 8.0.

### External Packages ###

#### GSL ####

The Gnu Scientific Library is a core requirement. Any recent version (>= 2.0)
suffices. Note that both the library _and_ development headers are needed.

 * On Linux, GSL is a standard package on all distributions. On Debian/Ubuntu,
   the relevant package is called `libgsl-dev`.

 * On Mac, GSL is easy to install directly from source. There are also Homebrew
   and MacPorts packages available (your mileage may vary).

### Included Packages ###

Linear algebra operations are performed using the [Eigen] library.  The present
distribution includes the headers of Eigen version 3.4.0 for dense matrix
operations.  These are automatically included when `BestLime` is built and do not
require any user intervention.


Configuration with CMake                                                {#cmake}
-------------------------

### Using CMake ###                                               {#using_cmake}

CMake performs out-of-source builds, i.e., it uses a separate build directory
that contains all configurations and build outputs, leaving the source tree
untouched. You can also have several independent build directories for different
configurations.

To start a fresh build, simply start from an empty build directory. CMake is
called from the build directory providing the path to the root of the source
tree:

    build$> cmake [<options>] <path-to-bestlime-source>

Both relative and absolute paths are allowed. One usually creates a `build/`
directory at the root of the source tree, so one can simply do `cmake ..`
(and which is assumed in the following).

CMake has a persistent configuration cache, which allows turning options on/off
or changing configuration variables without having to start from scratch every
time. The build system is smart enough to rebuild things as necessary when the
configuration has changed. CMake outputs a variety of useful information. To see
its output again, simply rerun `cmake`.

To set a CMake variable from the command line, do

    build$> cmake -D<variable>=<value> ..

To unset a variable use `-U<variable>`. After the first run of `cmake`, usually
tab completion is available for the possible variables and their values.

There are also various dedicated GUIs or CMake-aware IDEs that allow you to
interactively view and edit the CMake configuration, e.g.,

    build$> cmake-gui ..
    build$> ccmake ..

CMake has many more advanced features, which are extensively documented in the
[CMake manual].


### Configuration Options ###

CMake has various global variables, which steer its behavior (see the
[CMake manual] for more details). The most relevant ones are:

 CMake `<variable>`   | `<value>`       | Default         | Meaning
----------------------|-----------------|-----------------|---------------------
 `CMAKE_CXX_COMPILER` | `<c++-command>` | automatic       | The C++ compiler to use.
 `CMAKE_BUILD_TYPE`   | `<build-type>`  | `Release`       | The build configuration to use.
 `BUILD_SHARED_LIBS`  | `<boolean>`     | `ON`            | Whether to build shared or static libraries.

 * `CMAKE_CXX_COMPILER`
   Contains the command to call the C++ compiler. By default, it is initialized
   by CMake to the system's default compiler (for which CMake also recognizes
   the CXX environment variable). To use a different C++ compiler, the variable
   can be set explicitly. It can only be set on the first `cmake` run and cannot
   be changed afterwards.

 * `CMAKE_BUILD_TYPE`
   Contains the build configuration, which determines which optimization and
   debug flags are used. The recognized values are `Release`, `RelWithDebInfo`,
   `Debug`, and `MinSizeRel`. Other values are ignored. If empty, the default
   value `Release` is used.

 * `BUILD_SHARED_LIBS`
   Shared libraries will be built if this variable is `ON`, and static ones if
   it is `OFF`.

To select a GSL version installed in a non-standard directory `/dir` on your
system, type

    build$> cmake .. -DGSL_ROOT_DIR=/dir

This can only be done on the first `cmake` run, because the configured GSL
directory paths are not changed in subsequent runs.  The GSL library file to be
selected must reside in `/dir/lib` and its header files in `/dir/lib/gsl`.


Building
---------

Type

    build$> make bestlime

to build the main library, which will be written to `build/lib`.  Additionally,
the command

    build$> make examples

builds all example programs and writes them to `build/bin`.  The code of the
examples can be found in the subdirectory `examples` of the source tree and illustrates how `BestLime` is used in practice.


Installing                                                         {#installing}
-----------

Type

    build$> make install

to install the library and header files on your system.  The root directory of
the installation is stored in the variable `CMAKE_INSTALL_PREFIX`, whose value
may be changed as described in [Using CMake].

If `CMAKE_INSTALL_PREFIX` has the value `prefix`, then the library is installed
in the directory `prefix/lib`, and the header files in the directory
`prefix/include/bestlime`.  Any of these directories will be created during
installation if it does not already exist.

By default, CMake does not provide an `uninstall` target.  For removing an
installation, a shell script is provided instead.  To uninstall the library and
headers, type

    build@> uninstall

This will remove all `BestLime` library files `prefix/lib/libbestlime.*`,
as well as the subdirectory `prefix/include/bestlime` with all its contents.


[links]: #----------------------------------------------------------------------

[CMake manual]:              https://cmake.org/cmake/help/latest/
[CMake homepage]:            https://cmake.org/

[GSL documentation]:         https://www.gnu.org/software/gsl/doc/html/
[Eigen]:                     https://eigen.tuxfamily.org/

[Requirements]:              \ref requirements
[Installing]:                \ref installing
[Configuration with CMake]:  \ref cmake
[Using CMake]:               \ref using_cmake
