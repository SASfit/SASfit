<!-- To view this file in a formatted version with hyperlinks, point your browser to doc/html/index.html -->

[TOC]

Version History
===============

### 1.2 ###

 * Add functions to compute integration weights for a given value of `q`, see
   `bestlime::Bessel_integrator::weights_J_nu()`.
 * Use these weights to speed up integration calls that take several functions
   as argument.  See the documentation of the class
   `bestlime::Bessel_integrator` for details.
 * Changes in the implementation of the class
   `bestlime::Bessel_integrator_special`.
   These allow for higher integration precision in our benchmark examples,
   after small adjustments to the interpolation grids.

### 1.1 ###

 * Add integration calls that take a collection of several discretized functions
   as argument.
 * Add a method to handle integrands that increase as `z` goes to infinity.
   See the class `bestlime::Bessel_integrator_special` for details.
 * Add a grid transformation suitable for functions depending on powers of
   `log(z)`, see the class `bestlime::Log_pow_grid`.
 * Update example programs to match the published version of Ref [1] in the
   [Guidelines for Academic Use].


### 1.0 ###

 * Initial release


[links]: #----------------------------------------------------------------------

[Guidelines For Academic Use]: \ref guidelines
