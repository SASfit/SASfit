Alternative implementations
===========================

This directory contains alternative implementations of different
polylogarithms from the literature and public codes.  Original non-C
implementations have been translated directly to C.  References are
given in the respective codes.
